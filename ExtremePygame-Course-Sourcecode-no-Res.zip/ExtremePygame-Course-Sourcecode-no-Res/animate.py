import pygame as pg

pg.init()
screen = pg.display.set_mode((640, 480))
clock = pg.time.Clock()

# Load your full spritesheet image
# Replace "spritesheet.png" with your file path
sprite_sheet_image = pg.image.load("spritesheet.png").convert_alpha() 

player = Player((16, 16), sprite_sheet_image)
all_sprites = pg.sprite.Group(player)

running = True
while running:
    # Calculate delta time in seconds
    dt = clock.tick(60) / 1000.0 

    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False

    keys = pg.key.get_pressed()
    # Check if any movement keys are pressed to set the 'moving' state
    is_moving = keys[pg.K_LEFT] or keys[pg.K_RIGHT] 
    
    player.handle_input(keys)
    all_sprites.update(dt, is_moving)

    screen.fill((255, 255, 255)) # Fill with white background
    all_sprites.draw(screen)
    pg.display.flip()

pg.quit()
