import pygame
import collections

# Constants
WIDTH, HEIGHT = 600, 600
ROWS, COLS = 30, 30
CELL_SIZE = WIDTH // COLS

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
CYAN = (0, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("BFS Pathfinding Visualization")

def get_neighbors(row, col):
    neighbors = []
    # Up, Down, Left, Right
    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        r, c = row + dr, col + dc
        if 0 <= r < ROWS and 0 <= c < COLS:
            neighbors.append((r, c))
    return neighbors

def bfs(start, end):
    queue = collections.deque([start])
    visited = {start: None} # node: parent

    while queue:
        current = queue.popleft()

        if current == end:
            break

        for neighbor in get_neighbors(current[0], current[1]):
            if neighbor not in visited:
                visited[neighbor] = current
                queue.append(neighbor)
                
                # Visualizing the search
                draw_grid()
                pygame.draw.rect(screen, CYAN, (neighbor[1]*CELL_SIZE, neighbor[0]*CELL_SIZE, CELL_SIZE, CELL_SIZE))
                pygame.display.flip()
                pygame.time.delay(195) # Slow down for visualization

    # Reconstruct Path
    path = []
    curr = end
    while curr:
        path.append(curr)
        curr = visited.get(curr)
    return path[::-1]

def draw_grid():
    screen.fill(BLACK)
    for r in range(ROWS):
        for c in range(COLS):
            rect = pygame.Rect(c*CELL_SIZE, r*CELL_SIZE, CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(screen, (50, 50, 50), rect, 1)

def main():
    start = (5, 5)
    end = (25, 25)
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    path = bfs(start, end)
                    # Draw final path
                    for node in path:
                        pygame.draw.rect(screen, WHITE, (node[1]*CELL_SIZE, node[0]*CELL_SIZE, CELL_SIZE, CELL_SIZE))
                        pygame.display.flip()

        draw_grid()
        # Draw start/end
        pygame.draw.rect(screen, GREEN, (start[1]*CELL_SIZE, start[0]*CELL_SIZE, CELL_SIZE, CELL_SIZE))
        pygame.draw.rect(screen, RED, (end[1]*CELL_SIZE, end[0]*CELL_SIZE, CELL_SIZE, CELL_SIZE))
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()

