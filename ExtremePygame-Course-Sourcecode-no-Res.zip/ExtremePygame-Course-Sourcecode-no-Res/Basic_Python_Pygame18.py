
import pygame

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Create the screen object
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Self Example")

class Player:
    """A class to represent the player character."""

    def __init__(self, x, y):
        """Initialize the player attributes."""
        # Use 'self' to store the player's position, color, and size for this instance
        self.x = x
        self.y = y
        self.color = (0, 128, 255) # Blue color
        self.radius = 20
        self.speed = 5

    def draw(self, surface):
        """Draw the player on the screen."""
        # Use 'self' to access the specific instance's properties
        pygame.draw.circle(surface, self.color, (self.x, self.y), self.radius)

    def move_right(self):
        """Move the player to the right."""
        # Use 'self' to update the specific instance's position
        if self.x + self.radius < SCREEN_WIDTH:
            self.x += self.speed

# Create an instance of the Player class
# The 'self' parameter is implicitly passed by Python during instantiation and method calls
player_one = Player(x=SCREEN_WIDTH // 2, y=SCREEN_HEIGHT // 2)

# Game loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                # Call the move method on the specific 'player_one' instance
                # 'player_one' is automatically passed as the 'self' argument
                player_one.move_right()

    # Fill the screen with white
    screen.fill((255, 255, 255))

    # Draw the player
    player_one.draw(screen)

    # Flip the display to show the new drawing
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

# Quit Pygame
pygame.quit()

