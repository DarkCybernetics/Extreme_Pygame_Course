import pygame
import sys

# --- Configuration ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# --- Player Class (Game Object) ---
class Player(pygame.sprite.Sprite):
    """
    Represents the player object in the game, inheriting from pygame.sprite.Sprite.
    """
    def __init__(self):
        super().__init__()  # Initialize the parent Sprite class
        self.image = pygame.Surface([50, 50])  # Create a surface for the player
        self.image.fill(RED)  # Fill the surface with red color
        self.rect = self.image.get_rect()  # Get the rectangle object for positioning
        self.change_x = 0
        self.change_y = 0

    def update(self):
        """
        Update the player's position each frame.
        """
        self.rect.x += self.change_x
        self.rect.y += self.change_y

    def set_speed(self, x, y):
        """
        Set the player's movement speed.
        """
        self.change_x = x
        self.change_y = y

# --- Game Class (Main Logic Handler) ---
class Game:
    """
    This class represents an instance of the game, managing the main loop, events, and objects.
    """
    def __init__(self):
        """ Initialize the game attributes and objects. """
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Pygame Class Example")
        self.clock = pygame.time.Clock()
        self.game_over = False

        # Create sprite groups and the player object
        self.all_sprites_list = pygame.sprite.Group()
        self.player = Player()
        self.all_sprites_list.add(self.player)

        # Set initial player position
        self.player.rect.x = SCREEN_WIDTH // 2
        self.player.rect.y = SCREEN_HEIGHT // 2

    def process_events(self):
        """ Process all user input events. """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.player.set_speed(-5, 0)
                elif event.key == pygame.K_RIGHT:
                    self.player.set_speed(5, 0)
                elif event.key == pygame.K_UP:
                    self.player.set_speed(0, -5)
                elif event.key == pygame.K_DOWN:
                    self.player.set_speed(0, 5)
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    self.player.set_speed(0, self.player.change_y)
                elif event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                    self.player.set_speed(self.player.change_x, 0)
        return False

    def run_logic(self):
        """ Update game state and object positions (e.g., handle collisions, move objects). """
        if not self.game_over:
            self.all_sprites_list.update()
            # In a real game, collision checks and other logic would go here

    def display_frame(self):
        """ Render all elements to the screen. """
        self.screen.fill(BLACK)  # Fill the background

        self.all_sprites_list.draw(self.screen)  # Draw all sprites

        pygame.display.flip()  # Update the display

    def main(self):
        """ The main game loop. """
        while not self.game_over:
            if self.process_events():
                self.game_over = True
            self.run_logic()
            self.display_frame()
            self.clock.tick(FPS)  # Cap the frame rate

        pygame.quit()
        sys.exit()

# --- Main Program Execution ---
if __name__ == "__main__":
    pygame.init()
    game = Game()
    game.main()
