
import pygame
import sys

# Initialize Pygame
pygame.init()

# --- Configuration ---
WIDTH, HEIGHT = 400, 300
FPS = 60
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)

# Set up the display
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Boolean keyboard events Pygame Example")

clock = pygame.time.Clock()

# --- Game Variables (Booleans) ---
running = True  # Controls the main game loop
game_over = False # Tracks if the game has ended

# Simple player object for demonstration
player_pos = pygame.Rect(50, HEIGHT // 2 - 10, 20, 20)
obstacle_pos = pygame.Rect(WIDTH - 50, HEIGHT // 2 - 10, 20, 20)

# --- Main Game Loop ---
while running:
    # 1. Event Handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False  # Set running to False to exit the loop
        if event.type == pygame.KEYDOWN:
            if game_over and event.key == pygame.K_r:
                # Reset game state if 'R' is pressed after game over
                game_over = False
                player_pos.center = (50, HEIGHT // 2)
                obstacle_pos.center = (WIDTH - 50, HEIGHT // 2)
            
    # 2. Game Logic
    if not game_over:
        # Move player with keys (demonstrating conditional movement)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            player_pos.y -= 3
        if keys[pygame.K_DOWN]:
            player_pos.y += 3
        
        # Check for collision and set the game_over boolean to True
        if player_pos.colliderect(obstacle_pos):
            game_over = True

    # 3. Drawing
    screen.fill(WHITE)

    if game_over:
        # Display "Game Over" message only if game_over is True
        font = pygame.font.Font(None, 50)
        text = font.render("Game Over! Press R", True, RED)
        text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        screen.blit(text, text_rect)
    else:
        # Draw game elements only if game_over is False
        pygame.draw.rect(screen, BLACK, player_pos)
        pygame.draw.rect(screen, RED, obstacle_pos)

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(FPS)

# Quit Pygame
pygame.quit()
sys.exit()
