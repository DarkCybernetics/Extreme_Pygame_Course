import pygame

# 1. Initialize Pygame
pygame.init()

# Define colors (R, G, B)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Set the width and height of the screen
size = [600, 400]
screen = pygame.display.set_mode(size)
pygame.display.set_caption("Pygame Operators Example")

# Initial position and speed of the rectangle
rect_x = 50
rect_y = 50
rect_speed = 5

# Game loop control
running = True
clock = pygame.time.Clock()

# -------- Main Program Loop -----------
while running:
    # --- Event Processing ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            # Example using 'not' operator: if not an arrow key, do something
            if not (event.key in [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN]):
                # print("Not an arrow key!") # Example output
                pass

    # --- Game Logic ---

    # Get the state of all keys
    keys = pygame.key.get_pressed()

    # Use comparison and logical 'and' operators to move the rectangle within boundaries
    if keys[pygame.K_LEFT] and rect_x > 0:
        rect_x -= rect_speed # Assignment operator
    if keys[pygame.K_RIGHT] and rect_x < size[0] - 50: # 50 is the width of the rectangle
        rect_x += rect_speed
    if keys[pygame.K_UP] and rect_y > 0:
        rect_y -= rect_speed
    if keys[pygame.K_DOWN] and rect_y < size[1] - 50: # 50 is the height of the rectangle
        rect_y += rect_speed

    # --- Drawing ---
    screen.fill(BLACK) # Fill background

    # Draw the moving rectangle
    pygame.draw.rect(screen, BLUE, [rect_x, rect_y, 50, 50])

    # --- Update the screen ---
    pygame.display.flip() # Update the full display Surface to the screen

    # --- Limit to 60 frames per second ---
    clock.tick(60)

# Quit the game
