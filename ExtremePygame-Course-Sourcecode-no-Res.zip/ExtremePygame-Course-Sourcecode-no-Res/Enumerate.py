import pygame

# Configuration
TILE_SIZE = 32
wall_img = pygame.image.load("wall.png")   # 32x32 image
floor_img = pygame.image.load("floor.png") # 32x32 image

def draw_world(screen, level_data):
    for row_index, row in enumerate(level_data):
        for col_index, cell in enumerate(row):
            # Calculate pixel position
            x = col_index * TILE_SIZE
            y = row_index * TILE_SIZE
            
            # Blit based on character
            if cell == "W":
                screen.blit(wall_img, (x, y))
            elif cell == ".":
                screen.blit(floor_img, (x, y))
                
def load_level(filename):
    with open(filename, 'r') as f:
        # Strip newlines and convert each line into a list of characters
        return [list(line.strip()) for line in f.readlines()]

level_data = load_level("map.txt")
