
import pygame

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Inheritance Example")

# 1. Base GameObject class, inheriting from pygame.sprite.Sprite
class GameObject(pygame.sprite.Sprite):
    def __init__(self, color, width, height, x, y):
        super().__init__()  # Initialize the pygame.sprite.Sprite base class
        self.image = pygame.Surface([width, height])
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def update(self):
        # Base update method (can be overridden by children)
        pass

# 2. Player class inherits from GameObject
class Player(GameObject):
    def __init__(self, x, y):
        # Initialize the parent class with specific attributes
        super().__init__(RED, 50, 50, x, y)
        self.speed = 5

    def update(self):
        # Override update to handle movement input
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < SCREEN_WIDTH:
            self.rect.x += self.speed
        if keys[pygame.K_UP] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN] and self.rect.bottom < SCREEN_HEIGHT:
            self.rect.y += self.speed

# Game loop
running = True
clock = pygame.time.Clock()

# Create player instance
player = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
# Use a sprite group to manage updates and drawing easily
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update all sprites
    all_sprites.update()

    # Drawing
    screen.fill(WHITE)
    all_sprites.draw(screen) # Draw all sprites in the group

    # Refresh screen
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
