import pygame
import math

# Initialize
pygame.init()
screen = pygame.display.set_mode((800, 600))
car_img = pygame.image.load("car.png").convert_alpha() # Load your car image
clock = pygame.time.Clock()

# Path and State
path = [(100, 100), (600, 100), (600, 500), (100, 500)]
target_idx = 0
pos = pygame.Vector2(path[0])
speed = 5
dest = 100,100
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: running = False

    # 1. Find target
    target = pygame.Vector2(path[target_idx])
    direction = target - pos
    
    # 2. Check if reached target
    if direction.length() < speed:
        target_idx = (target_idx + 1) % len(path) # Loop back to start
    else:
        # 3. Move toward target
        direction = direction.normalize()
        pos += direction * speed
        
        # 4. Rotate car (optional)
        angle = math.degrees(math.atan2(-direction.y, direction.x))
        rotated_car = pygame.transform.rotate(car_img, angle)
        rect = rotated_car.get_rect(center=(pos.x, pos.y))
 
    # Draw
    screen.fill((30, 30, 30))
    pygame.draw.lines(screen, (255, 255, 255), True, path, 2) # Draw the loop
    screen.blit(car_img, dest, area=None, special_flags=0)
   # screen.blit(rotated_car, rect.topleft)
    pygame.display.flip()
    clock.tick(60)
