import pygame
import random

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Load image and convert for optimization
        self.image = pygame.image.load('enemy.png').convert_alpha()
        self.rect = self.image.get_rect()
        
        # Set spawn location at top, with random x-coordinate
        self.rect.center = (random.randint(0, 800), -50)
        
        # Movement speed
        self.speedy = random.randint(1, 5)

    def update(self):
        self.rect.y += self.speedy
        # Remove if off screen
        if self.rect.top > 600:
            self.kill()

# Group to hold enemies
enemies = pygame.sprite.Group()

# Spawning a new enemy
new_enemy = Enemy()
enemies.add(new_enemy)
