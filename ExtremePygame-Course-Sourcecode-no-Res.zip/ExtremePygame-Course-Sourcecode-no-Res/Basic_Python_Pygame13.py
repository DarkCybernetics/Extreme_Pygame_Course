
import pygame

# 1. Define game object data using a dictionary
player_data = {
    "color": (0, 128, 255), # RGB color for blue
    "rect": pygame.Rect(50, 50, 40, 40), # Rect(x, y, width, height)
    "speed": 5
}

# 2. Pygame Initialization
pygame.init()
screen_width, screen_height = 600, 400
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Dictionary in Pygame Example")

clock = pygame.time.Clock()
running = True

# 3. Game Loop
while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        # Example of using a dictionary to map key presses to actions (or data)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Toggle player color when space is pressed
                if player_data["color"] == (0, 128, 255):
                    player_data["color"] = (255, 100, 0)
                else:
                    player_data["color"] = (0, 128, 255)

    # Game logic (update positions using dictionary values)
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player_data["rect"].x -= player_data["speed"]
    if keys[pygame.K_RIGHT]:
        player_data["rect"].x += player_data["speed"]
    if keys[pygame.K_UP]:
        player_data["rect"].y -= player_data["speed"]
    if keys[pygame.K_DOWN]:
        player_data["rect"].y += player_data["speed"]

    # Drawing
    screen.fill((255, 255, 255)) # Fill screen with white
    # Draw the player using the dictionary's rect and color data
    pygame.draw.rect(screen, player_data["color"], player_data["rect"])

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

# Quit Pygame
pygame.quit()

