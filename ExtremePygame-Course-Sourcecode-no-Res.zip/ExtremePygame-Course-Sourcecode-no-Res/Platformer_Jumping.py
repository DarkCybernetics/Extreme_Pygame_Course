import pygame

# Initialize Pygame
pygame.init()

# Screen dimensions
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Platformer Jump Example")

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GRAY = (64, 64, 64)

# Player variables
player_width = 40
player_height = 60
player_x = screen_width // 2 - player_width // 2
player_y = screen_height - player_height - 50 # Start above ground
player_vel_y = 0
jump_speed = -15 # Initial upward velocity (negative moves up in Pygame)
gravity = 0.8 # Downward acceleration

# Ground variables
ground_height = 50
ground_y = screen_height - ground_height

# Game loop
running = True
clock = pygame.time.Clock()

while running:
    # Set frame rate
    clock.tick(60)

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            # Check if space is pressed AND player is on the ground
            if event.key == pygame.K_SPACE and player_y >= ground_y - player_height:
                player_vel_y = jump_speed # Start jump

    # Apply gravity and update player position
    player_vel_y += gravity
    player_y += player_vel_y

    # Ground collision check
    if player_y >= ground_y - player_height:
        player_y = ground_y - player_height # Place player firmly on the ground
        player_vel_y = 0 # Stop vertical movement

    # Drawing
    screen.fill(WHITE) # Clear screen with white
    pygame.draw.rect(screen, GRAY, (0, ground_y, screen_width, ground_height)) # Draw ground
    pygame.draw.rect(screen, BLUE, (player_x, player_y, player_width, player_height)) # Draw player

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
