
import pygame
import sys

# 1. Initialize Pygame (uses int, bool)
pygame.init()

# 2. Define colors using tuples (int, int, int)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# 3. Set up the display (uses int, tuple, str)
screen_width = 640
screen_height = 480
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Pygame Data Types Example')

# 4. Set up game objects and variables (uses int, list, Rect, bool)
square_size = 50
# Create a Rect object for position and collision detection
square_rect = pygame.Rect(
    (screen_width - square_size) // 2, 
    (screen_height - square_size) // 2, 
    square_size, 
    square_size
)
# Define speed using a list to allow mutation
speed = [2, 2]
running = True

# 5. The main game loop
while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False # Change boolean to False to exit loop

    # Game logic (movement using list and int)
    square_rect = square_rect.move(speed)
    # Check boundaries and reverse direction
    if square_rect.left < 0 or square_rect.right > screen_width:
        speed[0] = -speed[0]
    if square_rect.top < 0 or square_rect.bottom > screen_height:
        speed[1] = -speed[1]

    # Drawing
    screen.fill(WHITE) # Fill background with white tuple
    pygame.draw.rect(screen, RED, square_rect) # Draw the square using the red tuple and Rect object

    # Update the display
    pygame.display.flip()

# 6. Quit Pygame (Cleanup)
pygame.quit()
sys.exit()

