import pygame
import sys
from pygame.locals import QUIT

# 1. Initialize Pygame
pygame.init()

# 2. Set up the display window and title
DISPLAYSURF = pygame.display.set_mode((800, 600))
pygame.display.set_caption('Hello World!')

# 3. The main game loop
while True:
    # 4. Handle events
    for event in pygame.event.get():
        if event.type == QUIT:
            # Quit Pygame and exit the system when the window is closed
            pygame.quit()
            sys.exit()

    # 5. Update the display
    pygame.display.update()
