import pygame
import sys

# Initialize Pygame and set up screen/fonts
pygame.init()
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Game Over Demo")
clock = pygame.time.Clock()
font = pygame.font.Font(None, 74)
smaller_font = pygame.font.Font(None, 36)

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Game state variable
game_state = "PLAYING"
player_health = 10 # Example health

# --- Game Functions ---

def show_game_over_screen():
    global game_state, player_health
    
    screen.fill(BLACK)
    
    # Render Game Over text
    game_over_text = font.render("GAME OVER", True, WHITE)
    game_over_rect = game_over_text.get_rect(center=(screen_width // 2, screen_height // 2 - 50))
    screen.blit(game_over_text, game_over_rect)

    # Render restart instruction
    restart_text = smaller_font.render("Press R to Restart or Q to Quit", True, WHITE)
    restart_rect = restart_text.get_rect(center=(screen_width // 2, screen_height // 2 + 50))
    screen.blit(restart_text, restart_rect)
    
    pygame.display.flip()

    waiting_for_input = True
    while waiting_for_input:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    # Reset game state and player health
                    game_state = "PLAYING"
                    player_health = 10 # Reset health
                    waiting_for_input = False # Exit game over loop
                    # Add code here to reset all game objects (player position, remove enemy bullets, etc.)
                if event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()

# --- Main Game Loop ---
running = True
while running:
    # Event handling in main loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if game_state == "PLAYING":
        # Check for collisions and update game logic
        # Example: if player hit by bullet
        if collision_detected:
            player_health -= 1
            if player_health <= 0:
                game_state = "GAMEOVER"
        
        # (Your game update and draw functions for playing state go here)
        screen.fill((0, 180, 210)) # Example background
        # ... draw player, enemies, bullets ...
        pygame.display.flip()
        
    elif game_state == "GAMEOVER":
        show_game_over_screen()
        
    clock.tick(60)

pygame.quit()
sys.exit()
