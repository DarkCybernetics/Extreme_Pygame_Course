import pygame

# Assume you have a function to get user input as a string
# (Implementation of get_user_input is beyond this snippet, but it returns a string)
def get_user_input(prompt):
    # ... code to handle keyboard input ...
    return "100" # Example string input for demonstration

# In your game loop:
user_score_string = get_user_input("Enter your score:")

try:
    # Convert the string input to an integer
    user_score = int(user_score_string)
    print(f"Score as integer: {user_score}")
    
    # Use the integer in game logic (e.g., check if score is high enough)
    if user_score > 50:
        print("High score!")

except ValueError:
    print("Invalid input. Please enter a number.")
