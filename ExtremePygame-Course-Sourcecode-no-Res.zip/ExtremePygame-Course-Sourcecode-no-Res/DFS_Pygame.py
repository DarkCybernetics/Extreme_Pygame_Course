import pygame
import random

# Initialize Pygame
pygame.init()
WIDTH, HEIGHT = 600, 600
GRID_SIZE = 20
CELL_SIZE = WIDTH // GRID_SIZE
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Initialize grid (0: empty, 1: wall)
grid = [[0 for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
visited = set()

def draw_grid():
    for y in range(GRID_SIZE):
        for x in range(GRID_SIZE):
            rect = pygame.Rect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            if (x, y) in visited:
                pygame.draw.rect(screen, GREEN, rect)
            elif grid[y][x] == 1:
                pygame.draw.rect(screen, BLACK, rect)
            else:
                pygame.draw.rect(screen, WHITE, rect)
            pygame.draw.rect(screen, (200, 200, 200), rect, 1)

def dfs(start, goal):
    stack = [start]
    visited.add(start)
    
    while stack:
        current = stack.pop()
        
        # Visualization: Draw current state
        draw_grid()
        pygame.draw.rect(screen, RED, (current[0] * CELL_SIZE, current[1] * CELL_SIZE, CELL_SIZE, CELL_SIZE))
        pygame.display.flip()
        clock.tick(10) # Adjust speed
        
        if current == goal:
            return True
        
        # Check neighbors (up, down, left, right)
        for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            next_node = (current[0] + dx, current[1] + dy)
            if 0 <= next_node[0] < GRID_SIZE and 0 <= next_node[1] < GRID_SIZE:
                if next_node not in visited and grid[next_node[1]][next_node[0]] == 0:
                    visited.add(next_node)
                    stack.append(next_node)
    return False

# Main Loop
start_node = (0, 0)
goal_node = (GRID_SIZE-1, GRID_SIZE-1)
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    screen.fill(WHITE)
    draw_grid()
    dfs(start_node, goal_node)
    
    pygame.display.flip()

pygame.quit()
