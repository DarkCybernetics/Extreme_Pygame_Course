import pygame
import math

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

class CurvedMissile(pygame.sprite.Sprite):# could be enemy AI?
    def __init__(self, start_pos, control_point, end_pos):
        super().__init__()
        self.image = pygame.Surface((10, 10))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        
        # Path points
        self.start = start_pos
        self.control = control_point
        self.end = end_pos
        self.t = 0 # Time variable, from 0 to 1
        self.speed = 0.02 # Speed of movement along curve

    def update(self):
        if self.t < 1:
            self.t += self.speed
            # Quadratic Bezier Curve Formula
            x = (1 - self.t)**2 * self.start[0] + \
                2 * (1 - self.t) * self.t * self.control[0] + \
                self.t**2 * self.end[0]
            y = (1 - self.t)**2 * self.start[1] + \
                2 * (1 - self.t) * self.t * self.control[1] + \
                self.t**2 * self.end[1]
            
            self.rect.center = (x, y)
        else:
            self.kill() # Remove missile when it reaches the end

# Sprite groups
all_sprites = pygame.sprite.Group()
missiles = pygame.sprite.Group()

# Game loop
running = True
player_pos = (400,550)

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # Create a new missile curving to the mouse click
            target = pygame.mouse.get_pos()
            # Control point acts as the "handle" that pulls the curve
            control = (player_pos[0] + 100, player_pos[1] - 300) 
            missile = CurvedMissile(player_pos, control, target)
            all_sprites.add(missile)
            missiles.add(missile)

    all_sprites.update()
    
    screen.fill((0, 0, 0))
    all_sprites.draw(screen)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
