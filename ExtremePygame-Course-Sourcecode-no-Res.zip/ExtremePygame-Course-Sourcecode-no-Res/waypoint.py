import pygame
import math

pygame.init()
screen = pygame.display.set_mode((600, 500))
clock = pygame.time.Clock()

# 1. Define waypoints
waypoints = [
    pygame.math.Vector2(100, 100),
    pygame.math.Vector2(500, 100),
    pygame.math.Vector2(500, 400),
    pygame.math.Vector2(100, 400)
]
current_waypoint_index = 0
object_pos = waypoints[0].copy()
speed = 3

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 2. Calculate direction to the next waypoint
    target_waypoint = waypoints[current_waypoint_index]
    direction_vector = target_waypoint - object_pos
    distance = direction_vector.length()

    # 3. Check if the object is close enough to the current waypoint
    if distance < speed:
        # Move to the next waypoint
        current_waypoint_index = (current_waypoint_index + 1) % len(waypoints)
    else:
        # Move towards the waypoint
        direction_vector.normalize_ip()
        object_pos += direction_vector * speed
    
    # Drawing
    screen.fill((0, 0, 0)) # Black background
    # Draw the track for visualization
    pygame.draw.lines(screen, (255, 255, 255), True, [(int(p.x), int(p.y)) for p in waypoints], 2)
    
    # Draw the object
    pygame.draw.circle(screen, (0, 128, 255), (int(object_pos.x), int(object_pos.y)), 10)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
