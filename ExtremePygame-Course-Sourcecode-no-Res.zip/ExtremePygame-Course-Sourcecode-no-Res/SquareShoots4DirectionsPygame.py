import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Moving Square Shooter")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Game variables
FPS = 60
clock = pygame.time.Clock()
player_speed = 5
bullet_speed = 7

# --- Player Class ---
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.size = 30
        self.image = pygame.Surface([self.size, self.size])
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        self.change_x = 0
        self.change_y = 0

    def update(self):
        # Move the player
        self.rect.x += self.change_x
        self.rect.y += self.change_y

        # Keep player on screen
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

    def handle_keys(self, key):
        # Set movement direction based on key presses
        if key == pygame.K_LEFT:
            self.change_x = -player_speed
        elif key == pygame.K_RIGHT:
            self.change_x = player_speed
        elif key == pygame.K_UP:
            self.change_y = -player_speed
        elif key == pygame.K_DOWN:
            self.change_y = player_speed
    
    def handle_key_release(self, key):
        # Stop movement when key is released
        if key == pygame.K_LEFT and self.change_x < 0:
            self.change_x = 0
        elif key == pygame.K_RIGHT and self.change_x > 0:
            self.change_x = 0
        elif key == pygame.K_UP and self.change_y < 0:
            self.change_y = 0
        elif key == pygame.K_DOWN and self.change_y > 0:
            self.change_y = 0

# --- Bullet Class ---
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction_vector):
        super().__init__()
        self.size = 10
        self.image = pygame.Surface([self.size, self.size])
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        # Store movement vector calculated only once upon creation
        self.change_x = direction_vector[0] * bullet_speed
        self.change_y = direction_vector[1] * bullet_speed

    def update(self):
        # Move the bullet
        self.rect.x += self.change_x
        self.rect.y += self.change_y
        
        # Remove bullet if it goes off screen to save resources
        if self.rect.right < 0 or self.rect.left > SCREEN_WIDTH or \
           self.rect.bottom < 0 or self.rect.top > SCREEN_HEIGHT:
            self.kill()

# Sprite groups
all_sprites = pygame.sprite.Group()
bullet_list = pygame.sprite.Group()

# Create player
player = Player()
all_sprites.add(player)

# Helper to define shoot directions
SHOOT_DIRECTIONS = {
    pygame.K_w: (0, -1),  # Up
    pygame.K_s: (0, 1),   # Down
    pygame.K_a: (-1, 0),  # Left
    pygame.K_d: (1, 0)    # Right
}

# --- Game Loop ---
running = True
while running:
    # 1. Event Handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            # Handle player movement keys (Arrow keys for movement)
            player.handle_keys(event.key)
            # Handle shooting keys (WASD for shooting directions)
            if event.key in SHOOT_DIRECTIONS:
                direction = SHOOT_DIRECTIONS[event.key]
                bullet = Bullet(player.rect.centerx, player.rect.centery, direction)
                all_sprites.add(bullet)
                bullet_list.add(bullet)
        elif event.type == pygame.KEYUP:
            player.handle_key_release(event.key)

    # 2. Game Logic / Update positions
    all_sprites.update()

    # 3. Drawing
    screen.fill(BLACK) # Clear screen by filling background

    # Draw all sprites
    all_sprites.draw(screen)

    # 4. Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(FPS)

pygame.quit()
sys.exit()
