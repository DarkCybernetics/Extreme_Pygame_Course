import pygame
import sys

# --- Constants ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
GRAVITY = 0.8
PLAYER_SPEED = 5
JUMP_HEIGHT = -15
FPS = 60

# --- Player Class (inherits from pygame.sprite.Sprite) ---
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([30, 50])
        self.image.fill((0, 128, 255)) # Blue color
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.change_x = 0
        self.change_y = 0

    def update(self):
        """Update the player's position and apply gravity."""
        self.calc_gravity()
        # Move left/right
        self.rect.x += self.change_x
        # Check for collisions horizontally (simplified)
        
        # Move up/down
        self.rect.y += self.change_y
        # Check for collisions vertically (simplified)
        if self.rect.y >= SCREEN_HEIGHT - self.rect.height and self.change_y >= 0:
            self.change_y = 0
            self.rect.y = SCREEN_HEIGHT - self.rect.height
            
    def calc_gravity(self):
        """Calculate effect of gravity."""
        if self.change_y == 0:
            self.change_y = 1
        else:
            self.change_y += GRAVITY

    def jump(self):
        """Called when user hits 'jump' button."""
        # Check if on the ground for a valid jump (simplified)
        if self.rect.y >= SCREEN_HEIGHT - self.rect.height:
            self.change_y = JUMP_HEIGHT

    def go_left(self):
        """Called when user hits 'left' button."""
        self.change_x = -PLAYER_SPEED

    def go_right(self):
        """Called when user hits 'right' button."""
        self.change_x = PLAYER_SPEED

    def stop(self):
        """Called when user lets off the keyboard."""
        self.change_x = 0

# --- Main Game Class ---
class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Pygame Platformer Example")
        self.clock = pygame.time.Clock()
        self.all_sprites = pygame.sprite.Group()
        self.player = Player(50, SCREEN_HEIGHT - 50)
        self.all_sprites.add(self.player)
        self.running = True

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        self.player.go_left()
                    elif event.key == pygame.K_RIGHT:
                        self.player.go_right()
                    elif event.key == pygame.K_UP:
                        self.player.jump()
                elif event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT and self.player.change_x < 0:
                        self.player.stop()
                    elif event.key == pygame.K_RIGHT and self.player.change_x > 0:
                        self.player.stop()

            # Update game logic
            self.all_sprites.update()

            # Draw
            self.screen.fill((14, 219, 248)) # Sky Blue background
            self.all_sprites.draw(self.screen)
            
            # Ground for visibility (not a real platform class)
            pygame.draw.rect(self.screen, (0, 100, 0), (0, SCREEN_HEIGHT - 10, SCREEN_WIDTH, 10))

            # Refresh screen
            pygame.display.flip()
            self.clock.tick(FPS)

        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = Game()
    game.run()
