
import pygame

# Initialize pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Set up the display
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Polymorphism Example")

# Base class for all game objects
class GameObject:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.width = 20
        self.height = 20

    def draw(self, surface):
        """Polymorphic draw method"""
        pygame.draw.rect(surface, self.color, [self.x, self.y, self.width, self.height])

    def update(self):
        """Polymorphic update method (can be overridden)"""
        pass

# Player subclass
class Player(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, BLUE)

    def update(self):
        # Example player movement (simplified)
        self.x += 1
        if self.x > SCREEN_WIDTH:
            self.x = 0

# Enemy subclass
class Enemy(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, RED)

    def update(self):
        # Example enemy movement (simplified)
        self.y += 0.5
        if self.y > SCREEN_HEIGHT:
            self.y = 0

# Create a list to hold all game objects (leveraging polymorphism)
all_objects = [Player(50, 100), Enemy(200, 50), Player(400, 250), Enemy(150, 300)]

# Game loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Clear the screen
    screen.fill(WHITE)

    # Use polymorphism: Iterate over all objects and call update/draw methods
    # The loop doesn't care if it's a Player or Enemy, just that it has the methods.
    for obj in all_objects:
        obj.update()
        obj.draw(screen)

    # Update the display
    pygame.display.flip()
    clock.tick(60) # Cap the frame rate

# Quit pygame
pygame.quit()

