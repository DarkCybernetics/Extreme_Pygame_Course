import pygame
import json
import os

# --- JSON Handling Functions ---

def load_game_data(filename="game_data.json"):
    """Loads game data from a JSON file. Creates a default file if none exists."""
    if os.path.exists(filename):
        with open(filename, 'r') as file:
            return json.load(file)
    else:
        # Default data if file not found
        default_data = {"player_x": 400, "player_y": 300, "high_score": 0}
        with open(filename, 'w') as file:
            json.dump(default_data, file, indent=4) # Create file with default data
        return default_data

def save_game_data(data, filename="game_data.json"):
    """Saves game data to a JSON file."""
    with open(filename, 'w') as file:
        json.dump(data, file, indent=4) # Use indent for human-readable format

# --- Pygame Setup ---

pygame.init()
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame JSON Example")
clock = pygame.time.Clock()

# --- Game Variables (Loaded from JSON) ---

game_data = load_game_data()
player_x = game_data["player_x"]
player_y = game_data["player_y"]
high_score = game_data["high_score"]

# --- Colors and Fonts ---

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
font = pygame.font.Font(None, 36)

# --- Game Loop ---

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            # Update data dictionary before saving
            game_data["player_x"] = player_x
            game_data["player_y"] = player_y
            # Example: update high score if current score is higher (not implemented here)
            save_game_data(game_data)
            running = False
        
        # Example interaction: move player with keys
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player_x -= 10
            if event.key == pygame.K_RIGHT:
                player_x += 10
            if event.key == pygame.K_UP:
                player_y -= 10
            if event.key == pygame.K_DOWN:
                player_y += 10

    # --- Drawing ---
    screen.fill(BLACK)
    
    # Draw player (simple circle)
    pygame.draw.circle(screen, WHITE, (player_x, player_y), 20)

    # Display high score
    score_text = font.render(f"High Score: {high_score}", True, WHITE)
    screen.blit(score_text, (10, 10))
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
