import pygame

# --- Constants ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
WHITE = (255, 255, 255)
RED = (255, 0, 0)
FPS = 30

# --- Initialization ---
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Drag and Drop Example")
clock = pygame.time.Clock()

# --- Object ---
item_rect = pygame.Rect(100, 100, 50, 50)
is_dragging = False
mouse_offset_x = 0
mouse_offset_y = 0

# --- Main Loop ---
running = True
while running:
    # - Events -
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                if item_rect.collidepoint(event.pos):
                    is_dragging = True
                    # Calculate offset to drag from point of click, not top-left corner
                    mouse_offset_x = item_rect.x - event.pos[0]
                    mouse_offset_y = item_rect.y - event.pos[1]
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:  # Left mouse button
                is_dragging = False
                # Add logic here to check where the item was dropped (e.g., in a specific slot)
        elif event.type == pygame.MOUSEMOTION:
            if is_dragging:
                # Move the item based on the mouse position and initial offset
                item_rect.x = event.pos[0] + mouse_offset_x
                item_rect.y = event.pos[1] + mouse_offset_y

    # - Drawing -
    screen.fill(WHITE)
    pygame.draw.rect(screen, RED, item_rect)
    pygame.display.flip()

    # - FPS -
    clock.tick(FPS)

# Quit Pygame
pygame.quit()
