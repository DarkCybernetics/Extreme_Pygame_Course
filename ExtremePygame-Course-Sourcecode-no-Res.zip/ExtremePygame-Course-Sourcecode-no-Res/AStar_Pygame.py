import pygame
import heapq

# --- Constants ---
WIDTH, HEIGHT = 600, 600
TILE_SIZE = 30
GRID_WIDTH = WIDTH // TILE_SIZE
GRID_HEIGHT = HEIGHT // TILE_SIZE

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
RED = (255, 0, 0)    # Wall
GREEN = (0, 255, 0)  # Start
BLUE = (0, 0, 255)   # End
YELLOW = (255, 255, 0) # Path

# --- A* Algorithm ---
class Node:
    def __init__(self, x, y, walkable=True):
        self.x = x
        self.y = y
        self.walkable = walkable
        self.g = float('inf') # Cost from start
        self.h = 0            # Heuristic (distance to goal)
        self.f = float('inf') # Total cost (g + h)
        self.parent = None

    def __lt__(self, other):
        return self.f < other.f

def heuristic(a, b):
    # Manhattan distance
    return abs(a.x - b.x) + abs(a.y - b.y)

def get_neighbors(node, grid):
    neighbors = []
    for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
        nx, ny = node.x + dx, node.y + dy
        if 0 <= nx < GRID_WIDTH and 0 <= ny < GRID_HEIGHT:
            neighbor = grid[ny][nx]
            if neighbor.walkable:
                neighbors.append(neighbor)
    return neighbors

def astar(start_node, end_node, grid):
    open_list = []
    heapq.heappush(open_list, start_node)
    start_node.g = 0
    start_node.f = heuristic(start_node, end_node)
    
    visited = set()

    while open_list:
        current = heapq.heappop(open_list)

        if current == end_node:
            path = []
            while current:
                path.append(current)
                current = current.parent
            return path[::-1]

        visited.add(current)

        for neighbor in get_neighbors(current, grid):
            if neighbor in visited:
                continue
            
            new_g = current.g + 1
            if new_g < neighbor.g:
                neighbor.parent = current
                neighbor.g = new_g
                neighbor.h = heuristic(neighbor, end_node)
                neighbor.f = neighbor.g + neighbor.h
                if neighbor not in open_list:
                    heapq.heappush(open_list, neighbor)
    return None

# --- Pygame Setup ---
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Initialize Grid
grid = [[Node(x, y) for x in range(GRID_WIDTH)] for y in range(GRID_HEIGHT)]
start_point = None
end_point = None

def draw_grid():
    for y in range(GRID_HEIGHT):
        for x in range(GRID_WIDTH):
            node = grid[y][x]
            rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
            color = WHITE
            if not node.walkable: color = BLACK
            elif node == start_point: color = GREEN
            elif node == end_point: color = BLUE
            
            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, GRAY, rect, 1)

# --- Main Loop ---
running = True
path = []
while running:
    screen.fill(WHITE)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        # Mouse Input
        if pygame.mouse.get_pressed()[0]: # Left Click - Start/End/Walls
            pos = pygame.mouse.get_pos()
            x, y = pos[0] // TILE_SIZE, pos[1] // TILE_SIZE
            if start_point is None:
                start_point = grid[y][x]
            elif end_point is None and grid[y][x] != start_point:
                end_point = grid[y][x]
            elif grid[y][x] != start_point and grid[y][x] != end_point:
                grid[y][x].walkable = False
        
        elif pygame.mouse.get_pressed()[2]: # Right Click - Clear/Reset
            start_point = None
            end_point = None
            path = []
            for row in grid:
                for node in row:
                    node.walkable = True
                    node.g = float('inf')
                    node.f = float('inf')
                    node.parent = None
        
        # Press Space to Run
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            if start_point and end_point:
                # Reset path costs before searching
                for row in grid:
                    for node in row:
                        node.g = float('inf')
                        node.f = float('inf')
                        node.parent = None
                path = astar(start_point, end_point, grid)

    draw_grid()
    
    # Draw Path
    if path:
        for node in path:
            rect = pygame.Rect(node.x * TILE_SIZE, node.y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
            pygame.draw.rect(screen, YELLOW, rect)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()

