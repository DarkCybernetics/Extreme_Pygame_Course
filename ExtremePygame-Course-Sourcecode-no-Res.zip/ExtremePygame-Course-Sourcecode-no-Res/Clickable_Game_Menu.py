import pygame

# --- Game State Manager (Conceptual) ---
class Game:
    def __init__(self):
        self.state = 'menu'
        # Define clickable areas for buttons in the menu state
        self.start_button_rect = pygame.Rect(100, 100, 200, 50)
        self.quit_button_rect = pygame.Rect(100, 200, 200, 50)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = event.pos
            if self.state == 'menu':
                if self.start_button_rect.collidepoint(mouse_pos):
                    print("Starting game...")
                    self.state = 'playing'
                elif self.quit_button_rect.collidepoint(mouse_pos):
                    print("Quitting game...")
                    return False # Signal to end game loop
            elif self.state == 'playing':
                # Handle in-game clicks
                pass
        return True # Continue game loop

    def update(self):
        # State-specific update logic
        pass

    def draw(self, screen):
        # State-specific drawing logic
        if self.state == 'menu':
            pygame.draw.rect(screen, (0, 255, 0), self.start_button_rect)
            pygame.draw.rect(screen, (255, 0, 0), self.quit_button_rect)
            # Add text rendering for buttons
        elif self.state == 'playing':
            # Draw game elements
            pass

# --- Main Game Loop (Conceptual) ---
def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    game = Game()
    running = True

    while running:
        for event in pygame.event.get(): # Single event loop
            if event.type == pygame.QUIT:
                running = False
            else:
                running = game.handle_event(event) # Pass events to the game state manager

        game.update()
        game.draw(screen)
        pygame.display.flip()

    pygame.quit()

if __name__ == '__main__':
    main()

