import pygame
import random

# 1. Initialize and Setup
pygame.init()
screen = pygame.display.set_mode((400, 300))
clock = pygame.time.Clock()

# 2. Load Images (Replace with your file names)
# symbols = [pygame.image.load('cherry.png'), pygame.image.load('seven.png'), pygame.image.load('bar.png')]
# Using colored surfaces for this example:
img1 = pygame.Surface((100, 100)); img1.fill((255, 0, 0)) # Red
img2 = pygame.Surface((100, 100)); img2.fill((0, 255, 0)) # Green
img3 = pygame.Surface((100, 100)); img3.fill((0, 0, 255)) # Blue
symbols = [img1, img2, img3]

current_index = 0
spinning = False
start_ticks = 0

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        # Start spin on Spacebar
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            spinning = True
            start_ticks = pygame.time.get_ticks()

    # 3. Cycling Logic
    if spinning:
        # Rapidly cycle through the list
        current_index = (current_index + 1) % len(symbols)
        
        # Stop after 2000ms (2 seconds)
        if pygame.time.get_ticks() - start_ticks > 2000:
            spinning = False
            current_index = random.randint(0, 2) # Landing on a random result

    # 4. Rendering
    screen.fill((255, 255, 255))
    screen.blit(symbols[current_index], (150, 100)) # Draw current image
    pygame.display.flip()
    clock.tick(30) # Frames per second

pygame.quit()

