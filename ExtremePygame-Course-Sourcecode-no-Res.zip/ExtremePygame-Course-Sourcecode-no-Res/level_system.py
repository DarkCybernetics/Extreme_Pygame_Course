class Character:
    def __init__(self, name):
        self.name = name
        self.level = 1
        self.xp = 0
        self.xp_to_next_level = 100
        self.health = 50
        self.attack_power = 10
        # You can add more stats here

    def get_xp_needed(self):
        # A common formula: XP needed increases with level
        # This example uses a simple multiplier
        return 100 * (self.level ** 2)

    def add_xp(self, amount):
        self.xp += amount
        print(f"{self.name} gained {amount} XP! Current XP: {self.xp}")
        self.check_for_level_up()

    def check_for_level_up(self):
        while self.xp >= self.xp_to_next_level:
            self.level_up()

    def level_up(self):
        self.xp -= self.xp_to_next_level
        self.level += 1
        # Dynamically calculate stats based on new level or a formula
        self.health += 20
        self.attack_power += 5
        self.xp_to_next_level = self.get_xp_needed()
        print(f"*** {self.name} leveled up to Level {self.level}! ***")
        print(f"Health: {self.health}, Attack Power: {self.attack_power}")

# Example Usage:
player = Character("Hero")
print(f"Starting Level: {player.level}, XP needed for next level: {player.xp_to_next_level}")

# Simulate gaining XP from defeating enemies
player.add_xp(40)
player.add_xp(70) # This should trigger a level up
player.add_xp(200) # This should trigger multiple level ups
