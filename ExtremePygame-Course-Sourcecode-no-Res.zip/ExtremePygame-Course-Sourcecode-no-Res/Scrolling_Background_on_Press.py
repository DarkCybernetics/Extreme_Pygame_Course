import pygame
import sys

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
SCROLL_SPEED = 5 # Adjust speed as needed
FPS = 60

# Create the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Scrolling Background")

# Load and prepare the background image
# Ensure your image is at least SCREEN_WIDTH wide for horizontal scrolling
try:
    # Use .convert() for performance optimization
    background_image = pygame.image.load("background.png").convert()
except pygame.error as e:
    print(f"Error loading image: {e}")
    sys.exit()

# Set up clock for frame rate management
clock = pygame.time.Clock()

# Initial background positions
# Use a float for smoother scrolling if needed, though integers are fine for this basic example
bg_x = 0

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Get the state of all keyboard keys
    keys = pygame.key.get_pressed()

    # Update background position based on arrow keys
    if keys[pygame.K_LEFT]:
        bg_x += SCROLL_SPEED
    if keys[pygame.K_RIGHT]:
        bg_x -= SCROLL_SPEED
    
    # Optional: Implement Up/Down scrolling as well
    if keys[pygame.K_UP]:
        bg_y += SCROLL_SPEED
    if keys[pygame.K_DOWN]:
        bg_y -= SCROLL_SPEED

    # Create the looping effect (horizontal example)
    # Reset position when the first image moves fully off-screen
    if bg_x > background_image.get_width():
        bg_x = 0
    if bg_x < -background_image.get_width():
        bg_x = 0

    # Draw the background images
    # Draw first image at current position
    screen.blit(background_image, (bg_x, 0))
    # Draw second image immediately after the first, to the right or left depending on direction
    if bg_x < 0:
        screen.blit(background_image, (bg_x + background_image.get_width(), 0))
    else:
        screen.blit(background_image, (bg_x - background_image.get_width(), 0))
        
    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(FPS)

# Quit Pygame
pygame.quit()
sys.exit()
