import pygame
import sys
import datetime

# --- Initialization ---
pygame.init()
SCREEN_WIDTH, SCREEN_HEIGHT = 600, 400
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Date and Time Example")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Fonts
font_small = pygame.font.SysFont('Consolas', 20)
font_large = pygame.font.SysFont('Consolas', 40)

# Clock object to control frame rate
clock = pygame.time.Clock()
FPS = 60

# --- Timer Setup (Countdown) ---
# 10 seconds (10000 milliseconds) for the initial countdown
countdown_duration = 10000 
countdown_timer = countdown_duration
# Create a custom event that triggers every second (1000ms)
COUNTDOWN_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(COUNTDOWN_EVENT, 1000)

# --- Main Game Loop ---
running = True
while running:
    # Get the time elapsed since the last frame in milliseconds
    delta_time = clock.tick(FPS) 
    
    # --- Event Handling ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            sys.exit()
        
        # Handle the custom countdown event
        if event.type == COUNTDOWN_EVENT:
            if countdown_timer > 0:
                countdown_timer -= 1000 # Subtract 1 second (1000ms)
            else:
                # Optionally stop the timer once it hits zero
                pygame.time.set_timer(COUNTDOWN_EVENT, 0) 

    # --- Game Logic & Drawing ---
    screen.fill(WHITE)

    # 1. Display total elapsed time (since pygame.init())
    # pygame.time.get_ticks() returns time in milliseconds
    total_milliseconds = pygame.time.get_ticks()
    total_seconds = total_milliseconds // 1000
    elapsed_text = font_small.render(f"Elapsed Time: {total_seconds} seconds", True, BLACK)
    screen.blit(elapsed_text, (10, 10))

    # 2. Display current date and time (using Python's built-in datetime)
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    time_text = font_small.render(f"Current Date/Time: {current_time}", True, BLACK)
    screen.blit(time_text, (10, 40))

    # 3. Display the countdown timer
    countdown_seconds = countdown_timer // 1000
    if countdown_seconds > 0:
        timer_display_text = str(countdown_seconds)
    else:
        timer_display_text = "BOOM!"
        
    timer_text = font_large.render(f"Countdown: {timer_display_text}", True, BLACK)
    # Center the countdown text on screen
    text_rect = timer_text.get_rect(center=(SCREEN_WIDTH/2, SCREEN_HEIGHT/2))
    screen.blit(timer_text, text_rect)

    # Update the display
    pygame.display.flip()

# Quit Pygame and Python
pygame.quit()
