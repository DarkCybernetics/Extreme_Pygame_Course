import pygame

# Initialize
pygame.init()
screen = pygame.display.set_mode((400, 600))
clock = pygame.time.Clock()

# Elevator settings
elevator_rect = pygame.Rect(150, 500, 100, 20)
elevator_speed = 5
moving_up = False
moving_down = False

# Player settings
player_rect = pygame.Rect(175, 460, 30, 40)
player_on_elevator = False

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        # Button press to start movement
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                moving_up = True
            elif event.key == pygame.K_DOWN:
                moving_down = True

    # Movement Logic
    if moving_up:
        elevator_rect.y -= elevator_speed
        if elevator_rect.y <= 100: # Top floor
            moving_up = False
    elif moving_down:
        elevator_rect.y += elevator_speed
        if elevator_rect.y >= 500: # Bottom floor
            moving_down = False

    # Player interaction (Parenting)
    if player_rect.colliderect(elevator_rect):
        player_rect.bottom = elevator_rect.top
        # Move player with elevator
        if moving_up: player_rect.y -= elevator_speed
        if moving_down: player_rect.y += elevator_speed

    # Draw everything
    screen.fill((30, 30, 30))
    pygame.draw.rect(screen, (200, 0, 0), elevator_rect) # Elevator
    pygame.draw.rect(screen, (0, 200, 0), player_rect)   # Player
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
