import pygame
import random

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((10, 10))
        self.image.fill((255, 0, 0)) # Red bullet
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 5

    def update(self):
        self.rect.y += self.speed # Move down
        if self.rect.top > 600:
            self.kill() # Remove if off screen

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, left_bound, right_bound):
        super().__init__()
        self.image = pygame.Surface((40, 40))
        self.image.fill((0, 255, 0)) # Green enemy
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
        # Movement
        self.speed = 3
        self.left_bound = left_bound
        self.right_bound = right_bound
        
        # Shooting
        self.last_shot = pygame.time.get_ticks()
        self.shoot_delay = 1000 # 1 second

    def update(self, bullet_group):
        # Move back and forth
        self.rect.x += self.speed
        if self.rect.right >= self.right_bound or self.rect.left <= self.left_bound:
            self.speed *= -1 # Reverse direction

        # Shooting logic
        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            self.shoot(bullet_group)

    def shoot(self, bullet_group):
        bullet = Bullet(self.rect.centerx, self.rect.bottom)
        bullet_group.add(bullet)

# Setup groups
all_sprites = pygame.sprite.Group()
enemies = pygame.sprite.Group()
bullets = pygame.sprite.Group()

# Create enemy with boundaries
enemy = Enemy(200, 50, 100, 700)
all_sprites.add(enemy)
enemies.add(enemy)

# Game Loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update
    enemies.update(bullets)
    bullets.update()
    
    # Draw
    screen.fill((0, 0, 0))
    all_sprites.draw(screen)
    bullets.draw(screen)
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
