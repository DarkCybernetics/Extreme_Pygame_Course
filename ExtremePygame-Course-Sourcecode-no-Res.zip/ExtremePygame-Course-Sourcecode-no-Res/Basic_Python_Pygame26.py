
import pygame
import os
import sys

# --- File Deletion Function ---
def delete_score_file(filename="highscore.txt"):
    """Deletes the specified file if it exists."""
    if os.path.exists(filename):
        try:
            os.remove(filename)
            print(f"[FILE_MANAGER] '{filename}' deleted successfully.")
        except PermissionError:
            print(f"[FILE_MANAGER] Permission denied to delete '{filename}'.")
        except Exception as e:
            print(f"[FILE_MANAGER] Error deleting file: {e}")
    else:
        print(f"[FILE_MANAGER] '{filename}' not found, nothing to delete.")

# --- Pygame Setup ---
pygame.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("File Deletion in Pygame Example")

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

font = pygame.font.Font(None, 36)

# Create a dummy high score file for the example to work
with open("highscore.txt", "w") as f:
    f.write("Player A: 1000 pts")

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            # If the user presses the 'D' key, delete the highscore file
            if event.key == pygame.K_d:
                delete_score_file()

    # --- Pygame Drawing ---
    screen.fill(BLACK) # Clears the screen each frame

    # Display status text
    status_text = "Press 'D' to delete highscore.txt"
    text_surface = font.render(status_text, True, WHITE)
    text_rect = text_surface.get_rect(center=(SCREEN_WIDTH/2, SCREEN_HEIGHT/2))
    screen.blit(text_surface, text_rect)

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()

