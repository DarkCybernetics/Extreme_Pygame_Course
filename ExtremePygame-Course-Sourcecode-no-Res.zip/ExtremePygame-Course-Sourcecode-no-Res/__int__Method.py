class GameCharacter:
    """
    Represents a character in a game.
    """
    def __init__(self, name, health, attack_power):
        """
        Initializes the character's attributes upon creation.
        """
        self.name = name  # Assigns the 'name' parameter to the object's 'name' attribute
        self.health = health # Assigns the 'health' parameter to the object's 'health' attribute
        self.attack_power = attack_power # Assigns the 'attack_power' parameter to the object's 'attack_power' attribute
        print(f"A new character '{self.name}' has been created!")

    def take_damage(self, damage):
        """
        Reduces the character's health.
        """
        self.health -= damage
        print(f"{self.name} took {damage} damage. Health is now {self.health}.")

# Create instances of the GameCharacter class
# The __init__ method is called automatically with the provided arguments
player = GameCharacter("Hero", 100, 20)
enemy = GameCharacter("Goblin", 50, 10)

# You can then use the methods and attributes of the created objects
player.take_damage(enemy.attack_power)
enemy.take_damage(player.attack_power)
