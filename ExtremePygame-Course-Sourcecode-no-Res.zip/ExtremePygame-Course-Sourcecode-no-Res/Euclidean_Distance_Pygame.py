import pygame
import math

# Initialize Pygame
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Player setup
player_pos = pygame.math.Vector2(WIDTH // 2, HEIGHT // 2)
player_speed = 5

# Enemy setup
enemy_pos = pygame.math.Vector2(100, 100)
enemy_speed = 2
# Example of using an image: enemy_image = pygame.image.load('enemy.png')

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 1. Player movement (keyboard input)
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]: player_pos.x -= player_speed
    if keys[pygame.K_d]: player_pos.x += player_speed
    if keys[pygame.K_w]: player_pos.y -= player_speed
    if keys[pygame.K_s]: player_pos.y += player_speed

    # 2. Enemy AI: Follow Player
    # Calculate direction vector (difference in positions)
    direction = player_pos - enemy_pos
    
    # Calculate Euclidean distance using vector length
    distance = direction.length()
    
    # Normalize the vector (make it length 1) to get direction
    if distance > 0:
        direction.normalize_ip()
        
    # Move enemy towards player
    if distance > 10:  # Only move if not already on top of the player
        enemy_pos += direction * enemy_speed

    # 3. Drawing
    screen.fill(WHITE)
    # Draw player
    pygame.draw.circle(screen, BLUE, (int(player_pos.x), int(player_pos.y)), 15)
    # Draw enemy (or screen.blit(enemy_image, enemy_pos))
    pygame.draw.circle(screen, RED, (int(enemy_pos.x), int(enemy_pos.y)), 15)
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
