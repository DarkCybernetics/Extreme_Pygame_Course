import pygame
import math
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface([30, 30])
        self.image.fill(BLUE)
        self.rect = self.image.get_rect(center=pos)
        self.speed = 5
        self.pos = pygame.math.Vector2(pos)

    def update(self):
        # Basic player movement with keys (example)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.pos.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.pos.x += self.speed
        if keys[pygame.K_UP]:
            self.pos.y -= self.speed
        if keys[pygame.K_DOWN]:
            self.pos.y += self.speed
        
        # Keep player on screen (boundaries)
        self.pos.x = max(0, min(self.pos.x, WIDTH))
        self.pos.y = max(0, min(self.pos.y, HEIGHT))
        self.rect.center = self.pos

# Enemy class
class Enemy(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface([20, 20])
        self.image.fill(RED)
        self.rect = self.image.get_rect(center=pos)
        self.speed = 2
        self.pos = pygame.math.Vector2(pos)
        self.detection_radius = 150 # The radius for the enemy to start following
        self.wander_target = None
        self.wander_timer = 0
        self.WANDER_TIME = 120 # frames

    def update(self, player_pos):
        distance = self.pos.distance_to(player_pos)

        if distance < self.detection_radius:
            # Follow the player if in range
            direction_vector = player_pos - self.pos
            # Normalize and scale to speed
            if direction_vector.length_squared() > 0: # Avoid division by zero
                direction_vector.normalize()
                self.pos += direction_vector * self.speed
        else:
            # Wander randomly if not in range
            if self.wander_timer <= 0 or self.pos.distance_to(self.wander_target) < 5:
                # Pick a new random target location within a range
                self.wander_target = pygame.math.Vector2(
                    random.randint(0, WIDTH),
                    random.randint(0, HEIGHT)
                )
                self.wander_timer = self.WANDER_TIME
            else:
                # Move towards the random target
                direction_vector = self.wander_target - self.pos
                if direction_vector.length_squared() > 0:
                    direction_vector.normalize()
                    self.pos += direction_vector * (self.speed * 0.5) # Slower wander speed
                self.wander_timer -= 1
                
        self.rect.center = self.pos

# Create instances
player = Player((WIDTH // 2, HEIGHT // 2))
enemies = pygame.sprite.Group()

# Add a few enemies
for _ in range(3):
    enemy_pos = (random.randint(0, WIDTH), random.randint(0, HEIGHT))
    enemy = Enemy(enemy_pos)
    enemies.add(enemy)

# Game loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update game logic
    player.update()
    for enemy in enemies:
        enemy.update(player.pos) # Pass the player's position to the enemy update method

    # Drawing
    screen.fill(WHITE)
    
    # Draw detection radius (optional, for visualization)
    for enemy in enemies:
        pygame.draw.circle(screen, RED, enemy.rect.center, enemy.detection_radius, 1)

    enemies.draw(screen)
    screen.blit(player.image, player.rect)

    # Refresh screen
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
