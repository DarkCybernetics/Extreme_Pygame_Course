import pygame
from pygame.sprite import Sprite

# --- Configuration ---
WIN_WIDTH = 800
WIN_HEIGHT = 640
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)
# Colors
COLOR_WHITE = (255, 255, 255)
COLOR_BLACK = (0, 0, 0)
COLOR_BLUE = (0, 0, 255)

# --- Base Entity Class (Parent Class) ---
class Entity(Sprite):
    def __init__(self, color, x, y, width, height):
        Sprite.__init__(self) # Initialize parent class
        self.image = pygame.Surface([width, height])
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.dx = 0 # Delta x (horizontal movement)
        self.dy = 0 # Delta y (vertical movement/gravity)

    def update(self):
        # Base update method (can be overridden by child classes)
        self.rect.x += self.dx
        self.rect.y += self.dy

# --- Player Class (Child Class) ---
class Player(Entity):
    def __init__(self, x, y):
        super().__init__(COLOR_BLUE, x, y, 32, 32) # Call parent constructor
        self.gravity = 0.8
        self.jump_speed = -16
        self.on_ground = False

    def update(self, platforms):
        # Handle input and physics for the player
        # In a real game, input handling (key presses) would set self.dx and self.dy

        # Apply gravity
        if not self.on_ground:
            self.dy += self.gravity

        # Move horizontally
        self.rect.x += self.dx
        # Check horizontal collisions (not fully implemented here for brevity)

        # Move vertically
        self.rect.y += self.dy
        self.on_ground = False # Assume off ground until collision check

        # Check vertical collisions
        for platform in platforms:
            if self.rect.colliderect(platform.rect):
                if self.dy > 0: # Falling, hit top of platform
                    self.rect.bottom = platform.rect.top
                    self.dy = 0
                    self.on_ground = True
                elif self.dy < 0: # Jumping up, hit bottom of platform
                    self.rect.top = platform.rect.bottom
                    self.dy = 0

    def jump(self):
        if self.on_ground:
            self.dy = self.jump_speed

# --- Platform Class (Child Class) ---
class Platform(Entity):
    def __init__(self, x, y):
        super().__init__(COLOR_WHITE, x, y, 32, 32) # Simple white block
        # Platforms don't need a complex update, they are static
        pass

# --- Main Game Loop (Simplified) ---
def main():
    pygame.init()
    screen = pygame.display.set_mode(DISPLAY)
    pygame.display.set_caption("Platformer Inheritance Example")
    timer = pygame.time.Clock()

    # Create sprite groups
    all_sprites = pygame.sprite.Group()
    platforms_list = [] # A list for specific collision checking

    # Create player and platforms
    player = Player(50, 50)
    all_sprites.add(player)

    # Example level layout (P for Platform)
    level = [
        "                                ",
        "                                ",
        "                      PPPPPPPPPP",
        "                                ",
        "                                ",
        "PPPPPPPPPPPP                    ",
        "            P                   ",
        "            P                   ",
        "            P                   ",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP"
    ]

    x = y = 0
    for row in level:
        for col in row:
            if col == "P":
                p = Platform(x, y)
                all_sprites.add(p)
                platforms_list.append(p)
            x += 32
        y += 32
        x = 0

    # Game loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    player.jump()
                if event.key == pygame.K_LEFT:
                    player.dx = -5
                if event.key == pygame.K_RIGHT:
                    player.dx = 5
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    player.dx = 0

        # Update
        player.update(platforms_list) # Pass the platforms for collision logic

        # Draw
        screen.fill(COLOR_BLACK)
        all_sprites.draw(screen)

        # Refresh screen
        pygame.display.flip()
        timer.tick(60)

if __name__ == '__main__':
    main()
