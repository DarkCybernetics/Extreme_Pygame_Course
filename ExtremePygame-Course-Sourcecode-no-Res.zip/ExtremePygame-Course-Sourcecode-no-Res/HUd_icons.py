import pygame

# Initialize
pygame.init()
screen = pygame.display.set_mode((800, 600))
font = pygame.font.SysFont("Arial", 30)

# Game Variables
score = 0
health = 100
ammo = 30

# HUD Drawing Function
def draw_hud():
    # 1. Score
    score_text = font.render(f"Score: {score}", True, (255, 255, 255))
    screen.blit(score_text, (10, 10))
    
    # 2. Health Bar
    pygame.draw.rect(screen, (255, 0, 0), (10, 50, 200, 25)) # Background (Red)
    pygame.draw.rect(screen, (0, 255, 0), (10, 50, health * 2, 25)) # Health (Green)
    
    # 3. Ammo
    ammo_text = font.render(f"Ammo: {ammo}", True, (255, 255, 255))
    screen.blit(ammo_text, (650, 10))

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
    screen.fill((0, 0, 0)) # Clear screen
    draw_hud()
    pygame.display.flip() # Update screen

pygame.quit()
