import pygame
import random

# Initialize Pygame
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Colors
RED = (255, 0, 0)

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        # Give random speed
        self.speed_x = random.randint(-5, 5)
        self.speed_y = random.randint(-5, 5)
        # Ensure they don't stay still
        if self.speed_x == 0 and self.speed_y == 0:
            self.speed_x = 1

    def update(self):
        self.rect.x += self.speed_x
        self.rect.y += self.speed_y
        
        # Remove if it goes too far off-screen
        if not screen.get_rect().colliderect(self.rect.inflate(100, 100)):
            self.kill()

# Sprite Groups
all_sprites = pygame.sprite.Group()
enemies = pygame.sprite.Group()

# Spawn Timer
SPAWN_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(SPAWN_EVENT, 1000) # Spawn every 1 second

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == SPAWN_EVENT:
            # 1. Define Corner Spawn Points
            corners = [
                (0, 0),                       # Top-Left
                (WIDTH, 0),                   # Top-Right
                (0, HEIGHT),                  # Bottom-Left
                (WIDTH, HEIGHT)               # Bottom-Right
            ]
            # 2. Pick a random corner
            spawn_pos = random.choice(corners)
            
            # 3. Create and add enemy
            enemy = Enemy(spawn_pos[0], spawn_pos[1])
            all_sprites.add(enemy)
            enemies.add(enemy)

    # Update
    all_sprites.update()

    # Draw
    screen.fill((0, 0, 0))
    all_sprites.draw(screen)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
