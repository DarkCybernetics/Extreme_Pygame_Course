import pygame

# Initialize pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))

# Enemy class inheriting from pygame.sprite.Sprite
class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([30, 30])
        self.image.fill((255, 0, 0)) # Red color for enemies
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.change_x = 2
        self.change_y = 2

    def update(self):
        # Update enemy position (simple movement for demonstration)
        self.rect.x += self.change_x
        self.rect.y += self.change_y
        # Add boundary checks or AI here
        if self.rect.left < 0 or self.rect.right > 800:
            self.change_x *= -1
        if self.rect.top < 0 or self.rect.bottom > 600:
            self.change_y *= -1

# Create enemy group
all_enemies = pygame.sprite.Group()

# Add some enemies
enemy1 = Enemy(50, 50)
enemy2 = Enemy(200, 200)
enemy3 = Enemy(108,120)
enemy4 = Enemy(530,130)
enemy5 = Enemy(50,520)
enemy6 = Enemy(500,50)
#enemy7 = Enemy()
#enemy8 = Enemy()
#enemy9 = Enemy()
#enemy10
#enemy11
#enemy12
#enemy13
#enemy14
#enemy15
#enemy16
#enemy17
#enemy18
#enemy19
#enemy20
#enemy21
#enemy22
#enemy23
#enemy24
all_enemies.add(enemy1, enemy2 ,enemy3,enemy4,enemy5,enemy6)

# Main game loop
running = True
clock = pygame.time.Clock()
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update enemy positions
    all_enemies.update()

    # --- Collision detection between enemies ---
    # We iterate through all enemies and check against the rest of the group.
    # We use a copy of the group to avoid issues while iterating and potentially modifying the original group.
    for enemy in all_enemies:
        # Check for collisions with all other enemies (excluding itself)
        # We can use spritecollide with the 'do_kill' flag set to False
        # The 'collided_enemies' list will contain enemies that hit the current 'enemy'
        collided_enemies = pygame.sprite.spritecollide(enemy, all_enemies, False)
        
        # Filter out the enemy itself from the collision list
        collided_enemies = [e for e in collided_enemies if e != enemy]
        
        if collided_enemies:
            # Handle the collision: e.g., reverse direction, apply physics, etc.
            # For simplicity, just reverse the X direction of the first colliding enemy
            # In a real game, you would need more robust collision resolution
            for other_enemy in collided_enemies:
                # A simple collision response: reverse movement direction
                # This may not work perfectly for all scenarios (e.g., corner collisions)
                # You may want a more advanced method to determine collision direction
                enemy.change_x *= -1 
                enemy.change_y *= -1
                break # Only handle collision once per frame per enemy pair to avoid infinite bouncing

    # Drawing
    screen.fill((255, 255, 255)) # White background
    all_enemies.draw(screen)

    # Update the display
    pygame.display.flip()
    clock.tick(60)

pygame.quit()

