
import pygame

# 1. Import and initialize the Pygame library
pygame.init()

# 2. Set up the drawing window
screen_width = 500
screen_height = 500
screen = pygame.display.set_mode([screen_width, screen_height])
pygame.display.set_caption("Draw a Circle") #

# Define colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 128)

# 3. Run until the user asks to quit
running = True
while running:

    # 4. Handle events (key presses, mouse clicks, window close)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 5. Drawing
    screen.fill(WHITE) # Fill the background with white

    # Draw a solid blue circle in the center of the screen
    pygame.draw.circle(screen, BLUE, (screen_width // 2, screen_height // 2), 75)

    # 6. Flip the display to make the drawing visible
    pygame.display.flip()

# 7. Done! Stop the game engine
pygame.quit()
