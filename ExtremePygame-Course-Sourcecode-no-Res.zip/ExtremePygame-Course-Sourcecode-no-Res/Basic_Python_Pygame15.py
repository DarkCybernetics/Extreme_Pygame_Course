
import pygame
from pygame.locals import *

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

class Player(pygame.sprite.Sprite):
    """
    This class represents the player block.
    It inherits from the pygame.sprite.Sprite class.
    """
    def __init__(self):
        """ Constructor for the Player class. """
        super().__init__()
        self.surf = pygame.Surface((50, 50))
        self.surf.fill(BLUE)
        self.rect = self.surf.get_rect()
        self.rect.center = (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2)
        self.speed = 5

    def update(self, pressed_keys):
        """ Update the player's position based on key presses. """
        if pressed_keys[K_UP]:
            self.rect.move_ip(0, -self.speed)
        if pressed_keys[K_DOWN]:
            self.rect.move_ip(0, self.speed)
        if pressed_keys[K_LEFT]:
            self.rect.move_ip(-self.speed, 0)
        if pressed_keys[K_RIGHT]:
            self.rect.move_ip(self.speed, 0)

        # Keep player on the screen
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top <= 0:
            self.rect.top = 0
        if self.rect.bottom >= SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

class Game:
    """
    Manages the main game loop and environment.
    """
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Class Example")
        self.clock = pygame.time.Clock()
        self.running = True
        self.player = Player()

    def run(self):
        """ The main game loop. """
        while self.running:
            # Event handling
            for event in pygame.event.get():
                if event.type == QUIT:
                    self.running = False
                elif event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        self.running = False

            # Get the set of pressed keys
            pressed_keys = pygame.key.get_pressed()

            # Update game objects
            self.player.update(pressed_keys)

            # Drawing
            self.screen.fill(WHITE)
            self.screen.blit(self.player.surf, self.player.rect)

            # Update the display
            pygame.display.flip()

            # Cap the frame rate
            self.clock.tick(60)

        pygame.quit()
        quit()

if __name__ == '__main__':
    game = Game()
    game.run()

