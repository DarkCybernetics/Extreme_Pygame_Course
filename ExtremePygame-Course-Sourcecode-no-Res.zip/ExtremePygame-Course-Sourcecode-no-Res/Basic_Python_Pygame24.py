
import pygame
import sys

# 1. Read data from the file
def read_file_lines(filename):
    lines = []
    try:
        with open(filename, 'r') as f: # Use 'with open()' for automatic file closing
            lines = f.readlines()
    except IOError as e:
        print(f"Error reading file: {e}")
    return lines

# 2. Pygame Initialization and Setup
pygame.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("File Read Pygame Example")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
FONT_SIZE = 30

# Load a font (use a default font or specify a path to a .ttf file)
try:
    font = pygame.font.Font(None, FONT_SIZE)
except pygame.error as e:
    print(f"Could not load font: {e}")
    pygame.quit()
    sys.exit()

# 3. Main Game Loop
running = True
# Read the file content once before the loop
file_lines = read_file_lines("game_data.txt")

while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Drawing
    screen.fill(BLACK) # Fill the screen with black each frame

    # Display text from file
    y_offset = 50
    for n, line in enumerate(file_lines):
        # Remove newline characters and render the text
        text_surface = font.render(line.strip(), True, WHITE)
        # Position each line using enumerate index 'n'
        text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 2, y_offset + n * FONT_SIZE))
        screen.blit(text_surface, text_rect)

    # Update the display
    pygame.display.flip() # or pygame.display.update()

# 4. Quit Pygame
pygame.quit()
sys.exit()


