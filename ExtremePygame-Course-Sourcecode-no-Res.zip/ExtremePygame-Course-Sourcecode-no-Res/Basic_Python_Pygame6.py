
import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up the display
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Screen-Coordinates x y Pygame Casting Example")

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

# Font for text display
font = pygame.font.Font(None, 36)

# Player position (initially an integer)
player_x = 100
player_y = 100
player_radius = 20

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            # Example of user input that needs casting
            if event.key == pygame.K_SPACE:
                # In a real game, you might use a more complex input box,
                # but this illustrates the point.
                try:
                    # Simulate getting a number from a text input (which would be a string)
                    user_input_str = "450" 
                    # Type casting the string to an integer
                    new_x = int(user_input_str)
                    
                    # Use the new integer value to update game logic
                    player_x = new_x
                    print(f"Player X updated to: {player_x} (type: {type(player_x)})")
                    
                except ValueError:
                    print("Invalid input, not a valid integer.")

    # Drawing
    screen.fill(WHITE) # Fill background

    # Draw the player at the current integer coordinates
    pygame.draw.circle(screen, BLUE, (player_x, player_y), player_radius)

    # Display text showing current coordinates
    coord_text = font.render(f"X: {player_x}, Y: {player_y}", True, (0, 0, 0))
    screen.blit(coord_text, (10, 10))

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()

