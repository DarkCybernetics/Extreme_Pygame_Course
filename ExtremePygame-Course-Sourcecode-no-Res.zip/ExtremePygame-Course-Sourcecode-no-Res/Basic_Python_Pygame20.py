
import pygame
import sys
import os

# Initialize Pygame
pygame.init()

# --- Configuration ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
WHITE = (255, 255, 255)
# Define the path to a placeholder image if needed
# A simple image file named 'ball.png' should be in the same folder for this to work
IMAGE_PATH = 'ball.png' 

# --- Game Object Class ---
class Player(pygame.sprite.Sprite):
    """Represents the player object in the game."""
    def __init__(self):
        super().__init__() # Initialize the parent Sprite class
        # Attempt to load image, create a surface if not found
        try:
            self.image = pygame.image.load(IMAGE_PATH).convert_alpha()
        except pygame.error:
            print(f"Warning: {IMAGE_PATH} not found. Creating a default rectangle instead.")
            self.image = pygame.Surface([50, 50])
            self.image.fill((0, 100, 250)) # Blue color
            
        self.rect = self.image.get_rect() # Get the rectangle that represents the image
        self.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2) # Center position
        self.speed = 5

    def update(self, dx, dy):
        """Update the player's position based on movement deltas."""
        self.rect.x += dx
        self.rect.y += dy
        # Keep player within screen bounds
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

    def draw(self, screen):
        """Draw the player onto the screen."""
        screen.blit(self.image, self.rect) # Blitting copies pixels to the screen

# --- Main Game Loop ---
def main_game():
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Pygame Class Example")
    clock = pygame.time.Clock()

    player = Player() # Create an instance of the Player class

    running = True
    while running:
        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Get key presses for continuous movement
        keys = pygame.key.get_pressed()
        dx, dy = 0, 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            dx = -player.speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            dx = player.speed
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            dy = -player.speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            dy = player.speed

        # Update game objects
        player.update(dx, dy)

        # Drawing
        screen.fill(WHITE) # Fill screen with a solid color to clear previous frame
        player.draw(screen) # Call the instance method to draw the player

        # Update the display
        pygame.display.flip()

        # Cap the frame rate
        clock.tick(FPS)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main_game()

