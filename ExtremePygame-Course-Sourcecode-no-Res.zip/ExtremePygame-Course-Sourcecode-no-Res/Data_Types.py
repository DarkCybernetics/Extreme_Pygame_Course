import pygame
import sys

# 1. Python data types: Integers for screen dimensions and color (tuple)
WIDTH, HEIGHT = 800, 600
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

# 2. Pygame data types: Initialize Pygame and create a Surface object for the window
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pygame Data Types Example")

# 3. Pygame data type: Clock object for frame rate control
clock = pygame.time.Clock()
FPS = 60

# 4. Python data type: Boolean for the main game loop state
running = True

# 5. Pygame data type: Create a Rect object for the player
player_rect = pygame.Rect(50, 50, 50, 50) # x, y, width, height

while running:
    # 6. Pygame data type: Event objects handled in a loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False # Change boolean state to exit loop
    
    # Game logic and drawing
    screen.fill(WHITE) # Fill the background with white
    pygame.draw.rect(screen, BLUE, player_rect) # Draw the player rect in blue

    # Update the display
    pygame.display.update()
    
    # 7. Use Clock to limit FPS (integer)
    clock.tick(FPS)

pygame.quit()
sys.exit()
