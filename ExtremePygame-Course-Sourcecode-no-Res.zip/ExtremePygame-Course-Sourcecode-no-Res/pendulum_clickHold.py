import pygame
import math

# Initialize
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Pendulum constants
ORIGIN = (WIDTH // 2, 100)
LENGTH = 300
angle = math.pi / 4
angle_v = 0.0
angle_a = 0.0
gravity = 0.5
bob_pos = [0, 0]
dragging = False

def update_bob_pos():
    bob_pos[0] = ORIGIN[0] + LENGTH * math.sin(angle)
    bob_pos[1] = ORIGIN[1] + LENGTH * math.cos(angle)

update_bob_pos()

running = True
while running:
    screen.fill((255, 255, 255))
    
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                # Check if clicked near bob
                mouse_pos = pygame.mouse.get_pos()
                if math.hypot(mouse_pos[0]-bob_pos[0], mouse_pos[1]-bob_pos[1]) < 30:
                    dragging = True
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                dragging = False

    if dragging:
        # Dragging mechanics
        mouse_pos = pygame.mouse.get_pos()
        angle = math.atan2(mouse_pos[0] - ORIGIN[0], mouse_pos[1] - ORIGIN[1])
        angle_v = 0 # Reset velocity while dragging
    else:
        # Physics mechanics
        angle_a = (-1 * gravity / LENGTH) * math.sin(angle)
        angle_v += angle_a
        angle += angle_v
        angle_v *= 0.99 # Damping

    update_bob_pos()

    # Drawing
    pygame.draw.line(screen, (0, 0, 0), ORIGIN, bob_pos, 4)
    pygame.draw.circle(screen, (255, 0, 0), (int(bob_pos[0]), int(bob_pos[1])), 20)
    pygame.draw.circle(screen, (0, 0, 0), ORIGIN, 10)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
