import pygame
from collections import deque

# --- Constants ---
TILE_SIZE = 32
MAP_WIDTH = 15
MAP_HEIGHT = 10
SCREEN_WIDTH = TILE_SIZE * MAP_WIDTH
SCREEN_HEIGHT = TILE_SIZE * MAP_HEIGHT
FPS = 60

# Colors
WHITE = (255, 255, 255)
GREEN = (0, 255, 0) # Start
RED = (255, 0, 0)   # Target
BLUE = (10, 230, 255)  # Path Some other Color of blue
BLACK = (0,0,0)

# --- Tilemap Representation ---
# 0 = Floor, 1 = Wall
grid = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,1,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,0,0,0,0,0,0,0,1],
    [1,0,1,1,1,0,1,0,1,1,1,1,1,0,1],
    [1,0,1,0,0,0,0,0,0,0,0,0,1,0,1],
    [1,0,1,0,1,1,1,1,1,1,1,0,1,0,1],
    [1,0,0,0,1,0,0,0,0,0,1,0,0,0,1],
    [1,0,0,0,1,0,0,0,0,0,1,0,0,0,1],
    [1,0,0,0,1,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
]

# --- BFS Algorithm ---
def bfs(start, target):
    queue = deque([start])
    visited = {start}
    parent = {start: None}

    while queue:
        curr = queue.popleft()
        if curr == target:
            break

        # Check neighbors (Up, Down, Left, Right)
        for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            next_node = (curr[0] + dx, curr[1] + dy)
            
            # Check bounds and if it's a floor (0) and not visited
            if (0 <= next_node[0] < MAP_WIDTH and
                0 <= next_node[1] < MAP_HEIGHT and
                grid[next_node[1]][next_node[0]] == 0 and
                next_node not in visited):
                
                queue.append(next_node)
                visited.add(next_node)
                parent[next_node] = curr
                
    # Reconstruct Path
    path = []
    if target in parent:
        curr = target
        while curr:
            path.append(curr)
            curr = parent[curr]
    return path[::-1]

# --- Main Game Setup ---
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

# Load Images
wall_img = pygame.Surface((TILE_SIZE, TILE_SIZE))
wall_img.fill((100, 50, 0)) # Placeholder brown
floor_img = pygame.Surface((TILE_SIZE, TILE_SIZE))
floor_img.fill((200, 200, 200)) # Placeholder gray
# Uncomment to use actual images:
wall_img = pygame.image.load('wall.png').convert()

floor_img = pygame.image.load('floor.png').convert()


start_pos = (1, 1)
target_pos = (13, 8)
path = bfs(start_pos, target_pos)

# --- Game Loop ---
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Draw Map
    for row in range(MAP_HEIGHT):
        for col in range(MAP_WIDTH):
            tile = grid[row][col]
            if tile == 1:
                screen.blit(wall_img, (col * TILE_SIZE, row * TILE_SIZE))
            else:
                screen.blit(floor_img, (col * TILE_SIZE, row * TILE_SIZE))

    # Draw Path
    for node in path:
        rect = pygame.Rect(node[0] * TILE_SIZE, node[1] * TILE_SIZE, TILE_SIZE, TILE_SIZE)
        pygame.draw.rect(screen, BLUE, rect, 4)

    # Draw Start and Target
    pygame.draw.rect(screen, GREEN, (start_pos[0]*TILE_SIZE, start_pos[1]*TILE_SIZE, TILE_SIZE, TILE_SIZE))
    pygame.draw.rect(screen, RED, (target_pos[0]*TILE_SIZE, target_pos[1]*TILE_SIZE, TILE_SIZE, TILE_SIZE))

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
