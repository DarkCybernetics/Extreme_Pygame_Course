import pygame

# Initialize
pygame.init()
screen = pygame.display.set_mode((400, 300))
font = pygame.font.Font(None, 36)

# Potion Object
class Potion(pygame.sprite.Sprite):
    def __init__(self, x, y, type):
        super().__init__()
        self.type = type
        self.image = pygame.Surface((40, 40))
        self.image.fill((255, 0, 0) if type == "red" else (0, 0, 255))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.quantity = 1

    def draw(self, surface):
        surface.blit(self.image, self.rect)
        if self.quantity > 1:
            text = font.render(str(self.quantity), True, (255, 255, 255))
            surface.blit(text, (self.rect.x + 5, self.rect.y + 5))

    # Setup
potions = [Potion(50, 50, "red"), Potion(110, 50, "blue"),Potion(210, 50, "red") ]
# bug here: Stacking Different Color Cubes < fix it for homework?>
dragging_potion = None

# Game Loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            for p in potions:
                if p.rect.collidepoint(event.pos):
                    dragging_potion = p
        elif event.type == pygame.MOUSEBUTTONUP:
            if dragging_potion:
                # Basic Stacking Logic: Snap and combine
                for p in potions:
                    if p != dragging_potion and p.rect.colliderect(dragging_potion.rect):
                        p.quantity += dragging_potion.quantity
                        potions.remove(dragging_potion)
                        break
                dragging_potion = None
        elif event.type == pygame.MOUSEMOTION:
            if dragging_potion:
                dragging_potion.rect.move_ip(event.rel)

    screen.fill((30, 30, 30))
    for p in potions:
        p.draw(screen)
    pygame.display.flip()
# Questions : How do you limit a stack? ,How do you unstack? , Stack based on Color<type>
# For instance : Potions , TownPortalScrolls : HealthPotions: Ammo Boxes, Jewels ,Gems ,Gold?
pygame.quit()

