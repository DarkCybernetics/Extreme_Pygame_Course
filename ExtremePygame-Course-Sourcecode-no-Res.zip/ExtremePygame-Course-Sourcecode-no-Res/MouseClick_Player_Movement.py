import pygame
import sys
from pygame.math import Vector2 # Using vectors simplifies movement calculations

pygame.init()

# Screen setup
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Move player with mouse click")

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)

# Player setup
player_size = 30
player_pos = Vector2(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
player_speed = 5
target_pos = Vector2(player_pos) # Initial target is the starting position

# Game loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        # Detect mouse button down event
        if event.type == pygame.MOUSEBUTTONDOWN:
            # Check if the left button was clicked (button 1)
            if event.button == 1:
                # Set the target position to the mouse click position
                target_pos = Vector2(event.pos)

    # Player movement logic (outside the event loop)
    # Calculate the vector from the current position to the target
    distance_to_target = target_pos - player_pos
    
    # If the player is not at the target position, move towards it
    if distance_to_target.length_squared() > 1: # Use squared length for performance
        # Normalize the vector to get the direction, then multiply by speed
        direction = distance_to_target.normalize()
        player_pos += direction * player_speed
    else:
        # Stop moving if close enough to the target
        player_pos = target_pos

    # Drawing
    screen.fill(BLACK) # Fill the screen with background color
    # Draw the player as a rectangle at the current position
    pygame.draw.rect(screen, BLUE, (int(player_pos.x - player_size // 2), int(player_pos.y - player_size // 2), player_size, player_size))
    
    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

pygame.quit()
sys.exit()
