import pygame

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((600, 500))
# Define path points
path = [(50, 50), (100, 50), (200, 450),(300, 450),(400,42),(600,26)]
target_index = 0
player_pos = list(path[0])
speed = 5

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
    # Target management
    target = path[target_index]
    dx, dy = target[0] - player_pos[0], target[1] - player_pos[1]
    distance = (dx**2 + dy**2)**0.5
    
    if distance < speed:
        target_index = (target_index + 1) % len(path)
    else:
        # Move towards target
        player_pos[0] += speed * dx / distance
        player_pos[1] += speed * dy / distance
        
    screen.fill((0, 0, 0))
    # Draw path (optional)
    pygame.draw.lines(screen, (255, 255, 255), True, path, 2)
    # Draw object Each Car Sprite < need to fix this updating part>
    # RED , Green , Blue Car? maybe
    pygame.draw.circle(screen, (255, 0, 0), (int(player_pos[0]), int(player_pos[1])), 10)
    pygame.draw.circle(screen, (0, 255, 0), (int(player_pos[0]), int(player_pos[1])), 10)
    pygame.draw.circle(screen, (0, 0,255), (int(player_pos[0]), int(player_pos[1])), 10)

    pygame.display.flip()
    pygame.time.Clock().tick(60)

pygame.quit()
