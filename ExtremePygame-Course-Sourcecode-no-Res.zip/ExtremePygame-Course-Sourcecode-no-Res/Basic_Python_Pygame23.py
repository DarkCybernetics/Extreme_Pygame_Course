
import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions and colors
WIDTH, HEIGHT = 800, 600
SKY_BLUE = (135, 206, 235)
RED = (255, 0, 0)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Encapsulated Pygame Object")

# Encapsulation Example Class
class Player:
    def __init__(self, x, y):
        # Public attribute (can be accessed directly)
        self.name = "Hero"
        # Private attribute (name-mangled, access via property methods)
        self.__health = 100
        # Public attributes for game mechanics
        self.rect = pygame.Rect(x, y, 32, 32)
        self.speed = 5

    # Getter method using @property decorator for controlled access
    @property
    def health(self):
        return self.__health

    # Setter method to manage changes to health
    @health.setter
    def health(self, amount):
        if amount > 0:
            self.__health = amount
        else:
            self.__health = 0
            print(f"{self.name} is defeated!")

    def move(self, dx, dy):
        self.rect.x += dx * self.speed
        self.rect.y += dy * self.speed
        # Keep player on the screen
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT

    def draw(self, surface):
        pygame.draw.rect(surface, RED, self.rect)
        # Optionally, display health visually or in a debug text
        font = pygame.font.Font(None, 24)
        health_text = font.render(f"Health: {self.health}", True, (0, 0, 0))
        surface.blit(health_text, (self.rect.x, self.rect.y - 25))

# Game loop
player = Player(WIDTH // 2, HEIGHT // 2)
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Modifying health through the encapsulated setter method
                player.health -= 10
                print(f"Health is now: {player.health}")

    # Movement controls
    keys = pygame.key.get_pressed()
    dx, dy = 0, 0
    if keys[pygame.K_LEFT]:
        dx = -1
    if keys[pygame.K_RIGHT]:
        dx = 1
    if keys[pygame.K_UP]:
        dy = -1
    if keys[pygame.K_DOWN]:
        dy = 1

    player.move(dx, dy)

    # Drawing
    screen.fill(SKY_BLUE)
    player.draw(screen)

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    pygame.time.Clock().tick(60)

pygame.quit()
sys.exit()

