
# Draw and Move A Square in Pygame
import pygame
import sys

# 1. Initialization
pygame.init()

# Screen dimensions
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Moving Square")

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)

# Square properties (using a pygame.Rect object is recommended)
square_size = 50
# The Rect stores position as (x, y) coordinates for the top-left corner
square_rect = pygame.Rect(50, 50, square_size, square_size)
square_speed = 5

# Clock for controlling frame rate
clock = pygame.time.Clock()
FPS = 60

# 2. Game Loop
running = True
while running:
    # 3. Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 4. Update game state (movement logic)
    # Get the state of all keyboard buttons
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        square_rect.x -= square_speed
    if keys[pygame.K_RIGHT]:
        square_rect.x += square_speed
    if keys[pygame.K_UP]:
        # In Pygame, y increases as you go down, so moving up means subtracting from y
        square_rect.y -= square_speed
    if keys[pygame.K_DOWN]:
        square_rect.y += square_speed
    
    # Optional: Keep square within screen bounds
    square_rect.x = max(0, min(square_rect.x, screen_width - square_size))
    square_rect.y = max(0, min(square_rect.y, screen_height - square_size))


    # 5. Drawing (Rendering)
    screen.fill(BLACK)  # Erase the screen by filling it with the background color

    # Draw the square at its current position
    pygame.draw.rect(screen, RED, square_rect)

    # 6. Update the display
    # This makes everything we've drawn visible
    pygame.display.update()

    # 7. Cap the frame rate
    clock.tick(FPS) # Ensures the game runs at a consistent speed

# Quit Pygame
pygame.quit()
sys.exit()
