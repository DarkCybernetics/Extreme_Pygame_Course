import pygame

# Define some colors and screen dimensions as constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

class Player(pygame.sprite.Sprite):
    """
    Represents the player object in the game.
    Inherits from pygame.sprite.Sprite for easier management.
    """
    def __init__(self, x, y, speed):
        """
        Initialize the player with start position (x, y) and speed.
        """
        super().__init__()  # Initialize the parent Sprite class
        self.image = pygame.Surface([20, 20])  # Create a surface for the player
        self.image.fill(BLUE)  # Fill the surface with blue color
        self.rect = self.image.get_rect()  # Get the rectangular area of the surface
        self.rect.center = (x, y)  # Set the initial position
        self.speed = speed  # Store speed as a parameter

    def update(self):
        """
        Update the player's position (here, a simple placeholder for movement logic).
        """
        # Example: simple movement logic can be added here
        pass

class Game:
    """
    Manages the main game loop, display, and game state.
    """
    def __init__(self, width, height):
        """
        Initialize the game with screen dimensions.
        """
        pygame.init()
        self.width = width
        self.height = height
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Class Parameters Example")
        self.clock = pygame.time.Clock()
        self.running = True
        
        # Game objects/parameters
        self.player = Player(self.width // 2, self.height // 2, 5) # Instance of Player class
        self.all_sprites = pygame.sprite.Group() # Sprite group for easy drawing/updating
        self.all_sprites.add(self.player)

    def run(self):
        """
        The main game loop.
        """
        while self.running:
            # 1. Event Handling
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

            # 2. Game Logic Updates
            self.all_sprites.update()

            # 3. Drawing
            self.screen.fill(WHITE) # Fill background with white
            self.all_sprites.draw(self.screen) # Draw all sprites to the screen

            # 4. Update the display
            pygame.display.flip() # Update the full display Surface to the screen

            # 5. Cap the frame rate
            self.clock.tick(60) # Limits game to 60 frames per second

        pygame.quit() # Quit Pygame when the loop finishes

# Entry point for the script
if __name__ == "__main__":
    game_instance = Game(SCREEN_WIDTH, SCREEN_HEIGHT)
    game_instance.run()
