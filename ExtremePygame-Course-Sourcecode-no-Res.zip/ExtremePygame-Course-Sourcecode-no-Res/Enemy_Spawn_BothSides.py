import pygame
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# Set up the display
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Left to Right Enemy Spawning")

# Clock for controlling frame rate
clock = pygame.time.Clock()

# --- Enemy Class ---
class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Create a simple red square surface for the enemy
        self.image = pygame.Surface([40, 40])
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        
        # Set initial position: random y, just off screen to the left
        self.rect.x = -50 # Start off-screen
        self.rect.y = random.randrange(0, SCREEN_HEIGHT - self.rect.height)
        
        # Set a random speed for variation
        self.speed = random.randrange(1, 5)

    def update(self):
        # Move the enemy to the right
        self.rect.x += self.speed
        
        # Remove the enemy if it goes off the right side of the screen
        if self.rect.left > SCREEN_WIDTH:
            self.kill() # Removes sprite from all groups

# --- Game Setup ---
all_sprites_list = pygame.sprite.Group()
enemy_list = pygame.sprite.Group()

def spawn_enemy():
    enemy = Enemy()
    all_sprites_list.add(enemy)
    enemy_list.add(enemy)

# Timer for spawning enemies
SPAWN_EVENT = pygame.USEREVENT + 1
# Spawn a new enemy every 1000 milliseconds (1 second)
pygame.time.set_timer(SPAWN_EVENT, 1000)

# --- Main Game Loop ---
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == SPAWN_EVENT:
            spawn_enemy()

    # Game logic
    all_sprites_list.update()

    # Drawing
    screen.fill(BLACK) # Clear screen

    all_sprites_list.draw(screen) # Draw all sprites

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

# Quit Pygame
pygame.quit()
