import pygame
import sys

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect(center=(400, 300))
        self.pos = pygame.math.Vector2(self.rect.center)

    def update(self):
        # Player follows mouse
        self.pos = pygame.math.Vector2(pygame.mouse.get_pos())
        self.rect.center = self.pos

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((20, 20))
        self.image.fill(RED)
        self.rect = self.image.get_rect(center=(x, y))
        self.pos = pygame.math.Vector2(x, y)
        self.speed = 2

    def update(self, player_pos):
        # 1. Calculate direction vector
        enemy_to_player = player_pos - self.pos
        
        # 2. Check distance to avoid shaking (Euclidean distance > 0)
        if enemy_to_player.length() > 1:
            # 3. Normalize vector (length 1) and multiply by speed
            self.pos += enemy_to_player.normalize() * self.speed
            self.rect.center = self.pos

# Sprite groups
all_sprites = pygame.sprite.Group()
enemies = pygame.sprite.Group()

player = Player()
all_sprites.add(player)

# Create some enemies
for i in range(5):
    enemy = Enemy(i * 100 + 50, 100)
    all_sprites.add(enemy)
    enemies.add(enemy)

# Game Loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Update
    player.update()
    enemies.update(player.pos)

    # Draw
    screen.fill(WHITE)
    all_sprites.draw(screen)
    
    pygame.display.flip()
    clock.tick(60)
