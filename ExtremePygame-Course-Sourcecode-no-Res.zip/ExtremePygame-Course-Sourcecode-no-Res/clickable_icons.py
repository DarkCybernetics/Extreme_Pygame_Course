import pygame

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((600, 200))
# Create dummy surfaces for icons
icon_surf = pygame.Surface((60, 60))
icon_surf.fill((100, 100, 100)) # Gray base

class ClickableIcon:
    def __init__(self, x, y, image, callback):
        self.image = image
        self.rect = self.image.get_rect(topleft=(x, y))
        self.callback = callback
        self.is_clicked = False

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def check_click(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1 and self.rect.collidepoint(event.pos):
                self.callback()

# Define callbacks
def action1(): print("Icon 1 clicked")
def action2(): print("Icon 2 clicked")

# Create 5 icons
icons = []
for i in range(5):
    icons.append(ClickableIcon(50 + i * 100, 70, icon_surf, action1))

# Main Loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        for icon in icons:
            icon.check_click(event)

    screen.fill((30, 30, 30))
    for icon in icons:
        icon.draw(screen)
    pygame.display.flip()

pygame.quit()

