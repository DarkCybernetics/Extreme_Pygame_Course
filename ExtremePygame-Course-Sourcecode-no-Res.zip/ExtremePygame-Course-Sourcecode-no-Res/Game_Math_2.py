import pygame
import sys

# Initialize Pygame
pygame.init()

# --- Game Math Concepts: Vectors ---
# Vectors are used to represent position, velocity, and acceleration in games.
# Pygame provides a built-in Vector2 class.

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
PLAYER_SPEED = 5

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Math Example")

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

# Player setup
player_pos = pygame.math.Vector2(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
player_radius = 20

# Clock to control frame rate
clock = pygame.time.Clock()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # --- Game Math Logic: Movement ---
    # Use key presses to determine the player's movement direction.
    keys = pygame.key.get_pressed()
    velocity = pygame.math.Vector2(0, 0)
    
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        velocity.x = -PLAYER_SPEED
    if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        velocity.x = PLAYER_SPEED
    if keys[pygame.K_UP] or keys[pygame.K_w]:
        velocity.y = -PLAYER_SPEED
    if keys[pygame.K_DOWN] or keys[pygame.K_s]:
        velocity.y = PLAYER_SPEED
        
    # Update player position using vector addition
    player_pos += velocity
    
    # Keep player on screen (simple boundary check)
    player_pos.x = max(player_radius, min(player_pos.x, SCREEN_WIDTH - player_radius))
    player_pos.y = max(player_radius, min(player_pos.y, SCREEN_HEIGHT - player_radius))

    # --- Drawing ---
    screen.fill(WHITE) # Fill the background
    pygame.draw.circle(screen, BLUE, (int(player_pos.x), int(player_pos.y)), player_radius)
    
    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

pygame.quit()
sys.exit()
