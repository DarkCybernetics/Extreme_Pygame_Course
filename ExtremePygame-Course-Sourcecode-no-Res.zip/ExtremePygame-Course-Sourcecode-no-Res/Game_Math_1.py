import random
import operator
import sys

def math_game():
    score = 0
    ops = {
        '+': operator.add,
        '-': operator.sub,
        '*': operator.mul,
        '/': operator.truediv
    }
    
    while True:
        # Generate random numbers and operator
        num1 = random.randint(1, 10)
        num2 = random.randint(1, 10)
        op_symbol = random.choice(list(ops.keys()))
        
        # Calculate the correct answer
        answer = ops[op_symbol](num1, num2)
        
        # Present the question to the user
        print(f"\nWhat is {num1} {op_symbol} {num2}?")
        
        try:
            user_guess = float(input("Your answer: "))
            
            # Check the answer
            if abs(user_guess - answer) < 0.001: # Using a small tolerance for float comparison
                score += 1
                print(f"CORRECT! Current score: {score}")
            else:
                print(f"INCORRECT! The answer was {answer}.")
                break # Game over on a wrong answer
        except ValueError:
            print("Invalid input. Game over.")
            break
            
    print(f"\nGame Over. Final score: {score}")

if __name__ == "__main__":
    math_game()
