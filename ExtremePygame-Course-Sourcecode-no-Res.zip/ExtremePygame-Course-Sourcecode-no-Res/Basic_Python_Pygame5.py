
import pygame
pygame.init()

# 1. Use numbers to define colors and screen size
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
SCREEN_WIDTH = 500
SCREEN_HEIGHT = 400

screen = pygame.display.set_mode([SCREEN_WIDTH, SCREEN_HEIGHT])
pygame.display.set_caption("Pygame Numbers Example (Score Counter)")

# 2. Use a number variable for the score
score = 0
font = pygame.font.Font(None, 74) # None uses default font, size 74

# Game loop variables
running = True
clock = pygame.time.Clock() # Used to control frame rate

# Use numbers to control the score increase rate
score_increment_event = pygame.USEREVENT + 1
pygame.time.set_timer(score_increment_event, 1000) # Event fires every 1000ms (1 second)

while running:
    # 3. Use a number for the frame rate (e.g., 30 FPS)
    clock.tick(30)

    # Event handling loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == score_increment_event:
            # 4. Update the number (score)
            score += 1 # A += 1 works in Python/Pygame

    # Drawing
    screen.fill(WHITE)

    # 5. Render the number as text and blit to the screen
    score_text = font.render(str(score), True, BLACK) # Convert the number to a string to display
    # Use numbers for position coordinates (center the text)
    text_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
    screen.blit(score_text, text_rect)

    # Flip the display to make sure everything we've drawn is visible
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
