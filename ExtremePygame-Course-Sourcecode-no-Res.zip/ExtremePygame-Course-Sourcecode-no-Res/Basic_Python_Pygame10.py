
import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame List Example")

# Colors (using tuples)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
SKY_BLUE = (135, 206, 235)

# Clock for controlling frame rate
clock = pygame.time.Clock()

# --- List Management ---
# A list to store the 'snowflakes' (represented by Rect objects)
snowflake_list = []

# Function to create a new snowflake
def create_snowflake():
    x = random.randint(0, SCREEN_WIDTH)
    y = random.randint(-50, -10) # Start above the screen
    # Store position and size as a Rect object in the list
    # Rects are very useful in Pygame for position and collision
    snowflake_list.append(pygame.Rect(x, y, 10, 10))

# Create initial snowflakes
for _ in range(20):
    create_snowflake()

# Main game loop
while True:
    # 1. Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    
    # 2. Game logic (move snowflakes)
    for snowflake in snowflake_list:
        snowflake.y += 2 # Move down
        # If a snowflake goes off the bottom, move it back to the top
        if snowflake.y > SCREEN_HEIGHT:
            snowflake.y = random.randint(-50, -10)
            snowflake.x = random.randint(0, SCREEN_WIDTH)

    # 3. Drawing
    screen.fill(SKY_BLUE) # Fill the screen with a background color
    
    # Draw all snowflakes from the list
    for snowflake in snowflake_list:
        pygame.draw.rect(screen, WHITE, snowflake)

    # 4. Update the display
    pygame.display.flip()
    
    # Cap the frame rate
    clock.tick(60)

