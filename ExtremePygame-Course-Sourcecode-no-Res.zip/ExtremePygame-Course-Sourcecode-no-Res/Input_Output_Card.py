import pygame
import sys

# Initialize pygame
pygame.init()

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
CARD_WIDTH = 70
CARD_HEIGHT = 100
FPS = 30

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Set up the display
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Card Input/Output Example")

# Load font
font = pygame.font.SysFont(None, 30)

# Load card image (replace 'card_back.png' with your image file)
try:
    card_image = pygame.image.load('card_back.png')
    card_image = pygame.transform.scale(card_image, (CARD_WIDTH, CARD_HEIGHT))
except pygame.error as e:
    print(f"Error loading image: {e}")
    # Create a placeholder surface if image fails to load
    card_image = pygame.Surface((CARD_WIDTH, CARD_HEIGHT))
    card_image.fill((100, 100, 255)) # Blue placeholder
    pygame.draw.rect(card_image, WHITE, card_image.get_rect(), 2)

# Card Class
class Card:
    def __init__(self, x, y, image, value):
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.value = value
        self.is_clicked = False

    def draw(self, surface):
        """Output: Draw the card to the screen."""
        surface.blit(self.image, self.rect)
        if self.is_clicked:
            # Highlight card if clicked
            pygame.draw.rect(surface, (255, 0, 0), self.rect, 3)

    def handle_input(self, event):
        """Input: Check for mouse click on the card."""
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.is_clicked = not self.is_clicked
                print(f"Card {self.value} clicked!") # Output to console

# Create a card instance
my_card = Card(100, 100, card_image, "Ace of Spades")

# Game loop
running = True
while running:
    # Input handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        # Pass the event to the card for processing
        my_card.handle_input(event)

    # Output: Drawing
    screen.fill(WHITE) # Fill the background

    # Draw the card
    my_card.draw(screen)

    # Draw text output
    text_surface = font.render(f"Card clicked status: {my_card.is_clicked}", True, BLACK)
    screen.blit(text_surface, (10, SCREEN_HEIGHT - 40))

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    pygame.time.Clock().tick(FPS)

# Quit pygame
pygame.quit()
sys.exit()
