import pygame

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

# --- Classes ---
class Missile(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((10, 20))
        self.image.fill((255, 0, 0)) # Red missile
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.speed = -10

    def update(self):
        self.rect.y += self.speed
        # Kill sprite if it moves off top of screen
        if self.rect.bottom < 0:
            self.kill()

# --- Game Objects ---
player_x, player_y = 400, 550
missile_group = pygame.sprite.Group()

# --- Main Loop ---
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Shoot 3 missiles at once
                m1 = Missile(player_x - 20, player_y) # Left
                m2 = Missile(player_x, player_y)      # Center
                m3 = Missile(player_x + 20, player_y) # Right
               # m4 = Missile(player_x + 40,player_y)#  ??
                missile_group.add(m1, m2, m3 )

    # Update
    missile_group.update()

    # Draw
    screen.fill((0, 0, 0))
    # Draw player (simple rect for example)
    pygame.draw.rect(screen, (0, 255, 0), (player_x-15, player_y-15, 30, 30))
    missile_group.draw(screen)
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()

