
import pygame
import sys

# 1. Initialize Pygame
pygame.init()

# 2. Setup constants and variables
WIDTH, HEIGHT = 800, 600
FPS = 60
display_surface = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pygame String FPS calculator Example")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
font = pygame.font.Font(None, 32) # Use default font, size 32
clock = pygame.time.Clock()

# 3. Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 4. Game logic: use a string to display FPS
    # The clock.get_fps() returns a float, which we format into a string
    fps_text_string = f"FPS: {clock.get_fps():.1f}"
    
    # Render the string to a surface object
    # Parameters: (text, antialias, color)
    text_surface = font.render(fps_text_string, True, BLACK)
    
    # Get a rectangular object for the text surface and center it
    text_rect = text_surface.get_rect()
    text_rect.center = (WIDTH // 2, HEIGHT // 2)

    # 5. Drawing
    display_surface.fill(WHITE) # Clear screen with white
    display_surface.blit(text_surface, text_rect) # Blit (copy) the text surface to the display

    # 6. Update the display
    pygame.display.update() # Update the full surface
    
    # 7. Cap the frame rate
    clock.tick(FPS)

# Quit Pygame when the loop finishes
pygame.quit()
sys.exit()
