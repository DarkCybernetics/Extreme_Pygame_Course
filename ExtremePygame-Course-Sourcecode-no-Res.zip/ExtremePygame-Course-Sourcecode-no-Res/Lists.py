import pygame
import random

# Initialize the pygame library
pygame.init()

# Set up the drawing window
screen_width = 600
screen_height = 400
screen = pygame.display.set_mode([screen_width, screen_height])
pygame.display.set_caption("Pygame List Example: Moving Balls")

# Define colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

# --- Ball Management ---
# A list to store the ball objects
ball_list = []

# Ball class (simple representation using a dictionary for this example)
def create_ball():
    """Creates a new ball with random attributes and adds it to the list."""
    x = random.randint(20, screen_width - 20)
    y = random.randint(20, screen_height - 20)
    speed_x = random.randint(-3, 3)
    speed_y = random.randint(-3, 3)
    color = (random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))
    radius = 15
    ball = {"x": x, "y": y, "speed_x": speed_x, "speed_y": speed_y, "color": color, "radius": radius}
    ball_list.append(ball)

# Create an initial set of balls
for _ in range(10):
    create_ball()

# --- Main Game Loop ---
running = True
clock = pygame.time.Clock() # Used to manage frame rate

while running:
    # 1. Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 2. Game logic (move the balls)
    for ball in ball_list:
        ball["x"] += ball["speed_x"]
        ball["y"] += ball["speed_y"]

        # Simple boundary checks to bounce
        if ball["x"] <= ball["radius"] or ball["x"] >= screen_width - ball["radius"]:
            ball["speed_x"] *= -1
        if ball["y"] <= ball["radius"] or ball["y"] >= screen_height - ball["radius"]:
            ball["speed_y"] *= -1
            
    # 3. Drawing
    screen.fill(WHITE) # Fill the background

    # Draw all the balls from the list
    for ball in ball_list:
        pygame.draw.circle(screen, ball["color"], (int(ball["x"]), int(ball["y"])), ball["radius"])

    # 4. Flip the display to show the new frame
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

# Done! Time to quit.
pygame.quit()
