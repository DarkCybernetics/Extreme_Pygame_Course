# player.py
    import pygame

class Player(pygame.sprite.Sprite): # You can inherit from pygame.sprite.Sprite for convenience
    def __init__(self, x, y, image_path):
        super().__init__() # Call the parent class (Sprite) constructor
        self.image = pygame.image.load(image_path).convert_alpha() # Load image
        self.rect = self.image.get_rect() # Get the rectangle for positioning
        self.rect.center = (x, y)
        self.speed = 5

    def update(self):
        # Add logic for movement, animation, etc.
        pass

    def draw(self, surface):
        surface.blit(self.image, self.rect)

