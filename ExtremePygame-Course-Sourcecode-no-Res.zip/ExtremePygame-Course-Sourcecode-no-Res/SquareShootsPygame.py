

#Moving Square That Shoots
import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Moving Square That Shoots")

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# Clock for controlling frame rate
clock = pygame.time.Clock()
FPS = 60

# Player properties
player_width = 40
player_height = 40
player_x = SCREEN_WIDTH // 2 - player_width // 2
player_y = SCREEN_HEIGHT - player_height - 10
player_speed = 5
player_rect = pygame.Rect(player_x, player_y, player_width, player_height)

# Bullet properties
bullet_width = 5
bullet_height = 10
bullet_speed = -8 # Negative for moving up
bullets = [] # List to store active bullets

# Game loop
running = True
while running:
    # 1. Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Shoot a bullet
                # Position the bullet at the center top of the player
                bullet_x = player_rect.centerx - bullet_width // 2
                bullet_y = player_rect.top
                new_bullet = pygame.Rect(bullet_x, bullet_y, bullet_width, bullet_height)
                bullets.append(new_bullet)

    # 2. Player movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and player_rect.left > 0:
        player_rect.x -= player_speed
    if keys[pygame.K_RIGHT] and player_rect.right < SCREEN_WIDTH:
        player_rect.x += player_speed
    
    # 3. Bullet movement and removal
    for bullet in bullets[:]: # Iterate over a slice copy to allow modification of the original list
        bullet.y += bullet_speed
        # Remove bullets that go off-screen
        if bullet.bottom < 0:
            bullets.remove(bullet)

    # 4. Drawing
    screen.fill(BLACK) # Clear the screen by filling it with black

    # Draw player
    pygame.draw.rect(screen, WHITE, player_rect)

    # Draw bullets
    for bullet in bullets:
        pygame.draw.rect(screen, RED, bullet)

    # 5. Update the display
    pygame.display.flip() # Update the full display Surface to the screen

    # 6. Cap the frame rate
    clock.tick(FPS)

# Quit Pygame
pygame.quit()
sys.exit()

