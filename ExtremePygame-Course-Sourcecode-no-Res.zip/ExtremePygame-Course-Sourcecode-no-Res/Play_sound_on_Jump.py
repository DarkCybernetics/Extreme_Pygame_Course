import pygame
import os

# 1. Initialize Pygame and the mixer
pygame.init()
pygame.mixer.init() # Explicit initialization for clarity

# Set up the display (required for event loop)
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

# 2. Load the jump sound effect
# It's good practice to create a path to your sound file
# Assumes 'jump.wav' is in a 'sounds' subdirectory
sound_dir = os.path.join(os.getcwd(), 'sounds')
jump_sound = pygame.mixer.Sound(os.path.join(sound_dir, 'jump.wav'))
# You can adjust the volume of the sound if needed
# jump_sound.set_volume(0.5) 

# Variables for jump logic (example)
is_jump = False
jump_count = 10 # Example variable for jump height/velocity

running = True
while running:
    # 3. Handle events and play sound on jump trigger
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not is_jump:
                is_jump = True
                jump_sound.play() # Play the sound when the jump starts

    # ... Your character movement and jump physics logic would go here (e.g., updating y position) ...
    
    # Clear screen and update display
    screen.fill((255, 255, 255))
    # ... Draw your character ...
    pygame.display.flip()

# Quit Pygame
pygame.quit()
