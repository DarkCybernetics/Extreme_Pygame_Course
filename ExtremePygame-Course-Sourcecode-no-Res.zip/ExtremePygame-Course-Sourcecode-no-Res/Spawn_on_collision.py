import pygame
import random

# Initial Setup
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

class MyObject(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill((255, 0, 0)) # Red color
        self.rect = self.image.get_rect(center=(x, y))

# Create Groups
all_sprites = pygame.sprite.Group()
player = MyObject(400, 300)
targets = pygame.sprite.Group()

# Initial target
target = MyObject(random.randint(0, 800), random.randint(0, 600))
targets.add(target)
all_sprites.add(player, target)

running = True
while running:
    # 1. Collision Detection
    # spritecollide(sprite, group, dokill)
    hits = pygame.sprite.spritecollide(player, targets, True)
    
    # 2. Spawn 2 New Objects for every hit
    for hit in hits:
        for _ in range(2):
            new_obj = MyObject(random.randint(0, 800), random.randint(0, 600))
            targets.add(new_obj)
            all_sprites.add(new_obj)

    # Standard loop logic
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Move player with mouse for testing
    player.rect.center = pygame.mouse.get_pos()

    screen.fill((0, 0, 0))
    all_sprites.draw(screen)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
