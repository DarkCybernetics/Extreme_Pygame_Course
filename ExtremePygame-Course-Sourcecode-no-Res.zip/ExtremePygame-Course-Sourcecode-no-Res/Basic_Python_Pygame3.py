
import pygame, sys

# 1. Initialize Pygame
pygame.init()

# 2. Define Variables for Game Setup
size = width, height = 640, 480 # Screen dimensions stored in a tuple and individual variables
speed = [2, 2] # Ball movement speed
BLACK = (0, 0, 0) # Background color (RGB tuple)
WHITE = (255, 255, 255) # Ball color

# 3. Set up the drawing window and Clock
screen = pygame.display.set_mode(size) # Create the display surface object
pygame.display.set_caption("Bouncing Ball Box Example") # Set the window title
clock = pygame.time.Clock() # Variable to control frame rate

# 4. Create the ball object (a Rect variable)
ball_surface = pygame.Surface((30, 30)) # Create a simple square surface
ball_surface.fill(WHITE) # Make it white
ball_rect = ball_surface.get_rect(center=(width / 2, height / 2)) # Get the rectangle boundary, place in center

# 5. The Main Game Loop
running = True # Boolean variable to control the loop
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Check if the user clicked the close button
            running = False # Change the variable to False to exit loop
    
    # Update game logic (change variables)
    ball_rect = ball_rect.move(speed) # Move the ball's rectangle position
    
    # Collision detection: reverse speed if hitting a window edge by modifying variables
    if ball_rect.left < 0 or ball_rect.right > width:
        speed[0] = -speed[0]
    if ball_rect.top < 0 or ball_rect.bottom > height:
        speed[1] = -speed[1]

    # Draw everything
    screen.fill(BLACK) # Fill the screen with the background color
    screen.blit(ball_surface, ball_rect) # Draw the ball at its current rect position

    # Flip the display to make our drawings visible
    pygame.display.flip()
    
    # Cap the frame rate
    clock.tick(60) # Run at 60 frames per second

# Done! Time to quit.
pygame.quit()
sys.exit()

