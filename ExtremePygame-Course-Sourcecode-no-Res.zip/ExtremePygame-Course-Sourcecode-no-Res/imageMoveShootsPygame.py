import pygame

# Initialize Pygame
pygame.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("4-Direction Shooter")

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Load images (make sure 'player.png' and 'bullet.png' exist in the same directory)
# You should add error handling for file loading in a real game
try:
    player_image = pygame.image.load('player.png').convert_alpha()
    bullet_image = pygame.image.load('bullet.png').convert_alpha()
except pygame.error as e:
    print(f"Error loading images: {e}")
    # Create simple surfaces if images aren't available for demonstration
    player_image = pygame.Surface((30, 30))
    player_image.fill(WHITE)
    bullet_image = pygame.Surface((10, 10))
    bullet_image.fill((255, 0, 0))

# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = player_image
        self.rect = self.image.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
        self.speed = 5
        # Store direction as a vector (x, y)
        self.direction = (0, 0) 

    def update(self):
        # Movement logic
        keys = pygame.key.get_pressed()
        self.direction = (0, 0) # Reset direction each frame
        if keys[pygame.K_LEFT]:
            self.direction = (-1, 0)
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.direction = (1, 0)
            self.rect.x += self.speed
        if keys[pygame.K_UP]:
            self.direction = (0, -1)
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN]:
            self.direction = (0, 1)
            self.rect.y += self.speed
        
        # Keep player on screen (basic boundary checks)
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

    def shoot(self, direction):
        # Only shoot if a valid direction is set
        if direction != (0, 0):
            bullet = Bullet(self.rect.center, direction)
            all_sprites.add(bullet)
            bullets.add(bullet)

# Bullet class
class Bullet(pygame.sprite.Sprite):
    def __init__(self, pos, direction):
        super().__init__()
        self.image = bullet_image
        self.rect = self.image.get_rect(center=pos)
        self.speed = 7
        # The bullet's velocity is determined once upon creation
        self.velocity = direction # e.g., (-1, 0) for left, (0, 1) for down

    def update(self):
        # Move the bullet based on its initial velocity
        self.rect.x += self.velocity[0] * self.speed
        self.rect.y += self.velocity[1] * self.speed
        
        # Remove bullet if it goes off screen to save resources
        if self.rect.right < 0 or self.rect.left > SCREEN_WIDTH or \
           self.rect.bottom < 0 or self.rect.top > SCREEN_HEIGHT:
            self.kill()

# Sprite groups
all_sprites = pygame.sprite.Group()
bullets = pygame.sprite.Group()

# Create player instance
player = Player()
all_sprites.add(player)

# Game loop
running = True
clock = pygame.time.Clock()

while running:
    # 1. Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            # Check for space bar to shoot in the current *moving* direction
            if event.key == pygame.K_SPACE:
                player.shoot(player.direction) # Pass the player's current direction

    # 2. Update
    all_sprites.update()

    # 3. Draw
    screen.fill(BLACK) # Clear the screen
    all_sprites.draw(screen)

    # 4. Flip the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

pygame.quit()
