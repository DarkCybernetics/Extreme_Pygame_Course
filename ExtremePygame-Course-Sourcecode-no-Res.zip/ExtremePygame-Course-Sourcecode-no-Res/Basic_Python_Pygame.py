
import pygame
import sys

# 1. Initialize Pygame
pygame.init()

# Define screen dimensions
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("My First Introduction to using Pygame ")

# Define colors (R, G, B)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

# 2. The Game Loop
running = True
while running:
    # 3. Handle events (user input, quitting the window)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 4. Game logic updates would go here (e.g., character movement, collision checks)

    # 5. Drawing to the screen
    screen.fill(WHITE) # Fill the background with white

    # Example: Draw a blue rectangle
    pygame.draw.rect(screen, BLUE, [50, 50, 100, 50])

    # 6. Update the display
    pygame.display.flip() # Makes everything drawn visible

# 7. Quit the game
pygame.quit()
sys.exit()

