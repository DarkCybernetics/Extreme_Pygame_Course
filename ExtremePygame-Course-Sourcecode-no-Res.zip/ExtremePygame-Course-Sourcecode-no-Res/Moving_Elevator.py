import pygame

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

# Elevator setup
elevator_rect = pygame.Rect(300, 500, 150, 20)
elevator_speed = 2
direction = 1 # 1 for up, -1 for down
top_limit = 200
bottom_limit = 500

# Player setup
player_rect = pygame.Rect(350, 450, 40, 40)
player_vel_y = 0
gravity = 0.8
is_on_elevator = False

run = True
while run:
    screen.fill(WHITE)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Move elevator
    elevator_rect.y -= elevator_speed * direction
    if elevator_rect.y <= top_limit or elevator_rect.y >= bottom_limit:
        direction *= -1 # Reverse direction

    # Apply Gravity
    player_vel_y += gravity
    player_rect.y += player_vel_y

    # Collision detection
    is_on_elevator = False
    if player_rect.colliderect(elevator_rect):
        # Check if falling onto the elevator
        if player_vel_y > 0:
            player_rect.bottom = elevator_rect.top
            player_vel_y = 0
            is_on_elevator = True
            # Move player with the elevator
            player_rect.y -= elevator_speed * direction

    # Basic ground constraint
    if player_rect.bottom > 600:
        player_rect.bottom = 600
        player_vel_y = 0

    # Draw elements
    pygame.draw.rect(screen, BLUE, elevator_rect)
    pygame.draw.rect(screen, RED, player_rect)
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
