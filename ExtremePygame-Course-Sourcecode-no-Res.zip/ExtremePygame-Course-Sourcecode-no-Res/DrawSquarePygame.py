

# Draw A Square Using Pygame
import pygame
import sys

# Initialize pygame
pygame.init()

# Set up the display
width, height = 640, 480
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Pygame Draw Square")

# Define colors (RGB values)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

# Define the square parameters (x, y, width, height)
# (50, 50) is the top-left corner position, and 100 is both width and height for a square
square_rect = pygame.Rect(50, 50, 100, 100)

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Drawing
    # 1. Fill the background
    screen.fill(WHITE)

    # 2. Draw the square
    # The last argument '0' means the rectangle will be filled solid
    pygame.draw.rect(screen, BLUE, square_rect, 0)

    # 3. Update the display
    pygame.display.flip()

# Quit pygame
pygame.quit()
sys.exit()

