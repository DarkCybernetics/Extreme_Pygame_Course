import pygame
import csv
import os

# --- Configuration ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
TILE_SIZE = 32
MAP_FILE = 'map.csv'
TILE_IMAGES_DIR = 'assets/tiles'

# --- Pygame Initialization ---
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

# --- Helper Functions ---
def load_tile_images(directory):
    """Loads tile images from a directory and returns a dictionary/list."""
    images = {}
    for filename in os.listdir(directory):
        if filename.endswith('.png'):
            # Assumes filenames are tile_index.png (e.g., 0.png, 1.png)
            tile_index = int(os.path.splitext(filename)[0])
            path = os.path.join(directory, filename)
            image = pygame.image.load(path).convert_alpha()
            images[tile_index] = pygame.transform.scale(image, (TILE_SIZE, TILE_SIZE))
    return images

def convert_csv_to_2d_list(csv_file):
    """Converts a CSV map file to a 2D list of integers."""
    tile_map = []
    with open(csv_file, "r") as f:
        reader = csv.reader(f)
        for map_row in reader:
            # Convert each string value in the row to an integer
            try:
                tile_map.append(list(map(int, map_row)))
            except ValueError:
                print(f"Error reading row: {map_row}. Ensure all values are integers.")
                continue
    return tile_map

# --- Main Game Loop ---
def main():
    tile_images = load_tile_images(TILE_IMAGES_DIR)
    tile_map_data = convert_csv_to_2d_list(MAP_FILE)

    if not tile_images or not tile_map_data:
        print("Failed to load images or map data. Exiting.")
        return

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        screen.fill((0, 0, 0)) # Fill screen with black

        # Render the tilemap
        for row_index, row in enumerate(tile_map_data):
            for col_index, tile_index in enumerate(row):
                if tile_index in tile_images:
                    tile_image = tile_images[tile_index]
                    # Calculate position: col * TILE_SIZE, row * TILE_SIZE
                    screen.blit(tile_image, (col_index * TILE_SIZE, row_index * TILE_SIZE))

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()

if __name__ == "__main__":
    main()
