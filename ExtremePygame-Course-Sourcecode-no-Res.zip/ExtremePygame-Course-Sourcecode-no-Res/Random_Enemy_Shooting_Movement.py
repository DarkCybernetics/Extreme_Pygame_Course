import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
FPS = 60
WHITE = (255, 255, 255)
RED = (255, 0, 0)
ENEMY_SPEED = 2
BULLET_SPEED = 5
SHOOT_EVENT = pygame.USEREVENT + 1

# Setup screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Random Enemy Shooting")
clock = pygame.time.Clock()

# --- Classes ---
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        super().__init__()
        self.image = pygame.Surface((10, 10))
        self.image.fill(RED)
        self.rect = self.image.get_rect(center=(x, y))
        self.direction = direction # (dx, dy)
        self.speed = BULLET_SPEED

    def update(self):
        self.rect.x += self.direction[0] * self.speed
        self.rect.y += self.direction[1] * self.speed
        # Kill bullet if it goes off screen
        if not screen.get_rect().colliderect(self.rect):
            self.kill()

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Load enemy image
        try:
            self.image = pygame.image.load('enemy.png').convert_alpha()
            # Optionally resize: self.image = pygame.transform.scale(self.image, (40, 40))
        except:
            # Fallback if image not found
            self.image = pygame.Surface((40, 40))
            self.image.fill((0, 255, 0))
            
        self.rect = self.image.get_rect()
        self.rect.center = (random.randint(50, WIDTH-50), random.randint(50, HEIGHT-50))
        
        # Movement
        self.direction = random.choice([(1,0), (-1,0), (0,1), (0,-1)])
        self.steps = random.randint(30, 100)

    def update(self):
        # Move
        self.rect.x += self.direction[0] * ENEMY_SPEED
        self.rect.y += self.direction[1] * ENEMY_SPEED
        self.steps -= 1

        # Change direction randomly or if hitting wall
        if self.steps <= 0 or not screen.get_rect().contains(self.rect):
            self.direction = random.choice([(1,0), (-1,0), (0,1), (0,-1)])
            self.steps = random.randint(30, 100)
            
            # Keep inside boundaries
            self.rect.clamp_ip(screen.get_rect())

    def shoot(self):
        # Create 4 bullets in 4 directions
        directions = [(1,0), (-1,0), (0,1), (0,-1)]
        return [Bullet(self.rect.centerx, self.rect.centery, d) for d in directions]

# --- Setup Groups ---
all_sprites = pygame.sprite.Group()
enemies = pygame.sprite.Group()
bullets = pygame.sprite.Group()

# Create enemy
enemy = Enemy()
all_sprites.add(enemy)
enemies.add(enemy)

# Setup shooting timer
pygame.time.set_timer(SHOOT_EVENT, 1500) # Shoot every 1.5 seconds

# --- Main Loop ---
running = True
while running:
    # 1. Event Handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == SHOOT_EVENT:
            for enemy in enemies:
                new_bullets = enemy.shoot()
                all_sprites.add(new_bullets)
                bullets.add(new_bullets)

    # 2. Update
    all_sprites.update()

    # 3. Draw
    screen.fill((30, 30, 30))
    all_sprites.draw(screen)

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
sys.exit()

