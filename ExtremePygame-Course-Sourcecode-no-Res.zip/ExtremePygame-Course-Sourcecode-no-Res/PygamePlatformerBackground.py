import pygame
import sys

# 1. Initialize Pygame
pygame.init()

# Screen dimensions (adjust to your background image size if needed)
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Platformer Images")

# Clock for controlling frame rate
clock = pygame.time.Clock()
FPS = 60

# 2. Load Images (ensure file paths are correct)
try:
    # Load and convert background image
    background_img = pygame.image.load("background_grass.png").convert()
    # Load and convert player image (use convert_alpha() if it has transparent parts)
    player_img = pygame.image.load("player.png").convert_alpha()
except pygame.error as e:
    print(f"Error loading image: {e}")
    sys.exit()

# Set an initial position for the player
player_rect = player_img.get_rect()
player_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)

# Main game loop
running = True
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 3. Blit (draw) images to the screen
    # Draw background first at (0, 0)
    screen.blit(background_img, (0, 0))
   # 4. Scale the image to fit the screen dimensions
# Using smoothscale often provides better quality for scaling
scaled_background_image = pygame.transform.smoothscale(original_background_image, (screen_width, screen_height))

# Get the rectangle of the scaled image for easy positioning
background_rect = scaled_background_image.get_rect()
# The top-left corner is (0, 0) by default, which is perfect for a background
 
    # Draw player image at its current rect position
    screen.blit(player_img, player_rect)

    # 4. Update the display
    pygame.display.flip()

    # 5. Control the frame rate
    clock.tick(FPS)

# Quit Pygame
pygame.quit()
sys.exit()

