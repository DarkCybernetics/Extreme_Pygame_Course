
import pygame
import sys

# Initialize Pygame
pygame.init()

# Define window dimensions and colors
width = 500
height = 500
white = (255, 255, 255)
black = (0, 0, 0)

# Create the display surface (uses assignment operators =)
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Pygame Operators Example")

# Game loop variable (uses assignment operator =)
running = True

# Main game loop (uses comparison operator !=)
while running != False:
    # Event loop
    for event in pygame.event.get():
        # Check for the QUIT event (uses comparison operator ==)
        if event.type == pygame.QUIT:
            running = False # Reassigns running to False
    
    # Fill the screen with white color
    screen.fill(white)
    
    # Update the display
    pygame.display.flip()

# Quit Pygame and exit the program
pygame.quit()
sys.exit()

