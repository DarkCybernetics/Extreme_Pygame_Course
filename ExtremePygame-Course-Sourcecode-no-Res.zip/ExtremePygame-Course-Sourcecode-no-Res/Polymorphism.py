import pygame

# Initialize Pygame
pygame.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Polymorphism Example")

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Base class for all game objects
class GameObject:
    def __init__(self, x, y, color, size):
        self.rect = pygame.Rect(x, y, size, size)
        self.color = color
    
    def update(self):
        # Base update method (can be overridden by subclasses)
        pass
    
    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect)

# Player class inherits from GameObject
class Player(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, BLUE, 30)
        self.speed = 5

    def update(self):
        # Player-specific update logic (movement based on keys)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        if keys[pygame.K_UP]:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN]:
            self.rect.y += self.speed
        
        # Keep player on screen
        self.rect.clamp_ip(screen.get_rect())

# Enemy class inherits from GameObject
class Enemy(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, RED, 20)
        self.speed_x = 2
        self.speed_y = 2

    def update(self):
        # Enemy-specific update logic (bouncing movement)
        self.rect.x += self.speed_x
        self.rect.y += self.speed_y
        
        if self.rect.left < 0 or self.rect.right > SCREEN_WIDTH:
            self.speed_x *= -1
        if self.rect.top < 0 or self.rect.bottom > SCREEN_HEIGHT:
            self.speed_y *= -1

# Game loop
running = True
clock = pygame.time.Clock()

# Create objects and add them to a single list
all_objects = []
all_objects.append(Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
all_objects.append(Enemy(50, 50))
all_objects.append(Enemy(SCREEN_WIDTH - 50, SCREEN_HEIGHT - 50))

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Polymorphic Update: Call update() on every object in the list
    for obj in all_objects:
        obj.update()

    # Drawing
    screen.fill(WHITE)
    
    # Polymorphic Draw: Call draw() on every object in the list
    for obj in all_objects:
        obj.draw(screen)

    # Refresh screen
    pygame.display.flip()
    
    # Cap frame rate
    clock.tick(60)

pygame.quit()

