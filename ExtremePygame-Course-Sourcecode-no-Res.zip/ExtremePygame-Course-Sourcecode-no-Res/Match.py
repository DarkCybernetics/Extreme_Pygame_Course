import pygame
import random
import time

# --- Configuration ---
WIDTH, HEIGHT = 600, 600
ROWS, COLS = 4, 4
CARD_WIDTH, CARD_HEIGHT = 100, 100
GAP = 10
BG_COLOR = (30, 30, 30)
CARD_COLOR = (0, 100, 200)
MATCHED_COLOR = (0, 200, 0)
TEXT_COLOR = (255, 255, 255)
FLIP_DELAY = 1 # Time in seconds to show non-matching cards

# --- Initialize Pygame ---
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Memory Match Game")
font = pygame.font.SysFont("Arial", 40)
clock = pygame.time.Clock()

# --- Game Data ---
# Create pairs of values (e.g., numbers or simple characters)
values = [str(i) for i in range(1, (ROWS * COLS) // 2 + 1)] * 2
random.shuffle(values)
board = [None] * (ROWS * COLS)
for i in range(ROWS * COLS):
    board[i] = {"value": values[i], "flipped": False, "matched": False}

flipped_cards = []
matched_pairs = 0
total_pairs = (ROWS * COLS) // 2

# --- Helper Functions ---
def draw_board():
    screen.fill(BG_COLOR)
    for i in range(ROWS * COLS):
        row = i // COLS
        col = i % COLS
        x = col * (CARD_WIDTH + GAP) + GAP
        y = row * (CARD_HEIGHT + GAP) + GAP
        
        card = board[i]
        color = MATCHED_COLOR if card["matched"] else CARD_COLOR
        
        pygame.draw.rect(screen, color, (x, y, CARD_WIDTH, CARD_HEIGHT))
        
        if card["flipped"] or card["matched"]:
            text_surface = font.render(card["value"], True, TEXT_COLOR)
            text_rect = text_surface.get_rect(center=(x + CARD_WIDTH/2, y + CARD_HEIGHT/2))
            screen.blit(text_surface, text_rect)

def get_card_index(mouse_pos):
    x, y = mouse_pos
    for i in range(ROWS * COLS):
        row = i // COLS
        col = i % COLS
        card_x = col * (CARD_WIDTH + GAP) + GAP
        card_y = row * (CARD_HEIGHT + GAP) + GAP
        if card_x <= x <= card_x + CARD_WIDTH and card_y <= y <= card_y + CARD_HEIGHT:
            return i
    return None

# --- Main Game Loop ---
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and not any(card["matched"] for card in board) and len(flipped_cards) < 2:
            index = get_card_index(event.pos)
            if index is not None and not board[index]["flipped"]:
                board[index]["flipped"] = True
                flipped_cards.append(index)

    # Check for matched pairs
    if len(flipped_cards) == 2:
        # Give a brief delay for the user to see the second card
        draw_board()
        pygame.display.flip()
        time.sleep(FLIP_DELAY) #
        
        card1_index, card2_index = flipped_cards
        if board[card1_index]["value"] == board[card2_index]["value"]:
            board[card1_index]["matched"] = True
            board[card2_index]["matched"] = True
            matched_pairs += 1
        else:
            board[card1_index]["flipped"] = False
            board[card2_index]["flipped"] = False
        flipped_cards = []

    # Check win condition
    if matched_pairs == total_pairs:
        screen.fill(BG_COLOR)
        win_text = font.render("Congratulations! You Win!", True, TEXT_COLOR)
        text_rect = win_text.get_rect(center=(WIDTH/2, HEIGHT/2))
        screen.blit(win_text, text_rect)
        pygame.display.flip()
        time.sleep(3)
        running = False # End the game after win message

    draw_board()
    pygame.display.flip()
    clock.tick(30) # Limit to 30 FPS

pygame.quit()
