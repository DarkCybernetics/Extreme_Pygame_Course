import pygame
from collections import deque

# --- Constants ---
WIDTH, HEIGHT = 600, 600
GRID_SIZE = 20
TILE_SIZE = WIDTH // GRID_SIZE

# --- BFS Algorithm ---
def bfs(start, goal, grid):
    queue = deque([start])
    visited = {start: None} # Node: Parent
    
    while queue:
        current = queue.popleft()
        
        if current == goal:
            break
            
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]: # 4 directions
            neighbor = (current[0] + dx, current[1] + dy)
            
            # Check bounds and if it's a wall (assuming 1 is wall, 0 is empty)
            if (0 <= neighbor[0] < GRID_SIZE and 
                0 <= neighbor[1] < GRID_SIZE and
                grid[neighbor[0]][neighbor[1]] == 0 and
                neighbor not in visited):
                
                queue.append(neighbor)
                visited[neighbor] = current
                # Optional: Pygame draw here for animation
                
    return visited # Return visited nodes to reconstruct path

# --- Pygame Setup and Main Loop ---
# Initialize Pygame, load images, draw grid, run BFS, and display results

