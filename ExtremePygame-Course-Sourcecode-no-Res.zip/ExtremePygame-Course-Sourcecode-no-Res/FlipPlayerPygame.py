import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("4-Direction Movement and Flip")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Load the original image (make sure to have an 'image.png' file)
try:
    original_image = pygame.image.load('player.png').convert_alpha()
    # Scale image down if needed
    original_image = pygame.transform.scale(original_image, (150, 150))
except pygame.error as e:
    print(f"Error loading image: {e}")
    sys.exit()

# Get the image's rectangle for positioning
image_rect = original_image.get_rect()
image_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)

# Movement speed
speed = 5

# Direction tracking for flipping
facing_right = True # Initial direction

# Clock for controlling frame rate
clock = pygame.time.Clock()

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
    # Get all key presses
    keys = pygame.key.get_pressed()

    # Movement logic
    if keys[pygame.K_LEFT]:
        image_rect.x -= speed
        facing_right = False
    if keys[pygame.K_RIGHT]:
        image_rect.x += speed
        facing_right = True
    if keys[pygame.K_UP]:
        image_rect.y -= speed
    if keys[pygame.K_DOWN]:
        image_rect.y += speed

    # Keep the image within screen bounds (optional)
    image_rect.left = max(0, image_rect.left)
    image_rect.right = min(SCREEN_WIDTH, image_rect.right)
    image_rect.top = max(0, image_rect.top)
    image_rect.bottom = min(SCREEN_HEIGHT, image_rect.bottom)

    # Determine the image to blit based on facing direction
    if facing_right:
        current_image = original_image
    else:
        # Flip the image horizontally using pygame.transform.flip(Surface, xbool, ybool)
        current_image = pygame.transform.flip(original_image, True, False)

    # Drawing
    screen.fill(WHITE) # Clear screen with background color
    screen.blit(current_image, image_rect) # Draw the image at the updated position
    
    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

# Quit Pygame
pygame.quit()
sys.exit()
