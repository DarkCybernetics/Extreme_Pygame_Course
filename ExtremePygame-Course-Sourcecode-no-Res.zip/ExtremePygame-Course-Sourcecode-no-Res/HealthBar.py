import pygame

pygame.init()

# Screen dimensions and colors
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Health Bar with Numbers")

# Player health variables
max_health = 2000
current_health = 10

# Font initialization (choose a suitable font and size)
font = pygame.font.SysFont("Arial", 24, True)

def draw_health_bar(surface, x, y, health, max_health_val):
    # Bar dimensions
    BAR_WIDTH = 200
    BAR_HEIGHT = 30
    
    # Calculate health percentage and bar width
    health_ratio = health / max_health_val
    current_bar_width = int(BAR_WIDTH * health_ratio)

    # Draw the background (max health) bar in red
    pygame.draw.rect(surface, RED, (x, y, BAR_WIDTH, BAR_HEIGHT))
    
    # Draw the current health bar in green
    pygame.draw.rect(surface, GREEN, (x, y, current_bar_width, BAR_HEIGHT))
    
    # Draw the health value as text
    health_text = font.render(f"{int(health)}/{max_health_val}", True, WHITE)
    text_rect = health_text.get_rect(center=(x + BAR_WIDTH / 2, y + BAR_HEIGHT / 2))
    surface.blit(health_text, text_rect)

# Game loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Decrease health by 10 on space bar press (for demonstration)
                current_health -= 10
                if current_health < 0:
                    current_health = max_health
            if event.key == pygame.K_UP:
                # Increase health by 5 on up arrow press (for demonstration)
                current_health += 5
                if current_health > max_health:
                    current_health = max_health

    # Clear the screen
    screen.fill(BLACK)

    # Draw the player's health bar and numbers (located at x=50, y=50)
    draw_health_bar(screen, 50, 50, current_health, max_health)

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

pygame.quit()
