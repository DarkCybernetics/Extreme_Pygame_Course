import pygame
import json
import os # The os module is used to check if the file exists

# --- Configuration ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FILE_NAME = 'player_data.json'
IMAGE_PATH = 'gfg.png' # Replace with your image file path

# Initial data values
initial_data = {
    'pos_x': SCREEN_WIDTH // 2,
    'pos_y': SCREEN_HEIGHT // 2,
    'score': 0
}

# --- File Handling Functions ---

def save_data(data_to_save):
    """Saves game data to a JSON file."""
    try:
        with open(FILE_NAME, 'w') as store_file:
            json.dump(data_to_save, store_file, indent=4)
        print(f"Data saved to {FILE_NAME}")
    except IOError as e:
        print(f"Error saving file: {e}")

def load_data():
    """Loads game data from a JSON file, or returns initial data if file not found."""
    if os.path.exists(FILE_NAME):
        try:
            with open(FILE_NAME, 'r') as load_file:
                data = json.load(load_file)
            print(f"Data loaded from {FILE_NAME}")
            return data
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}. Using initial data.")
            return initial_data
        except IOError as e:
            print(f"Error reading file: {e}. Using initial data.")
            return initial_data
    else:
        print(f"Save file {FILE_NAME} not found. Creating new file with initial data.")
        save_data(initial_data)
        return initial_data

# --- Pygame Initialization ---
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame File Handling Example")

# Load data
game_data = load_data()

# Load image and set initial position
# Note: You must have an image file named 'gfg.png' in the same directory
try:
    img = pygame.image.load(IMAGE_PATH).convert_alpha()
    rect = img.get_rect(center=(game_data['pos_x'], game_data['pos_y']))
except pygame.error as e:
    print(f"Cannot load image: {e}. Exiting.")
    pygame.quit()
    exit()

# --- Game Loop ---
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            # Update data with current position before quitting
            game_data['pos_x'] = rect.centerx
            game_data['pos_y'] = rect.centery
            save_data(game_data)
            running = False
        
        # Example interaction: increase score when spacebar is pressed
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                game_data['score'] += 1
                print(f"Score increased to: {game_data['score']}")

    # Game logic (e.g., movement can be added here)

    # Drawing
    screen.fill((255, 255, 255)) # Fill screen with white
    screen.blit(img, rect)

    # Display score (optional)
    font = pygame.font.Font(None, 36)
    score_text = font.render(f"Score: {game_data['score']}", True, (0, 0, 0))
    screen.blit(score_text, (10, 10))

    pygame.display.flip()

pygame.quit()
