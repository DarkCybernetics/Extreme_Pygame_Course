import pygame

# Initialize Pygame
pygame.init()

# --- Configuration ---
WINDOW_WIDTH = 400
WINDOW_HEIGHT = 300
SQUARE_SIZE = 30
# Colors
COLOR_WHITE = (255, 255, 255)
COLOR_BLACK = (0, 0, 0)
COLOR_GREEN = (0, 255, 0)
# Calculate number of rows and columns based on window size and square size
NUM_ROWS = WINDOW_HEIGHT // SQUARE_SIZE
NUM_COLS = WINDOW_WIDTH // SQUARE_SIZE

# --- Game Data Array (2D List) ---
# 0 represents a white square, 1 represents a green square
# This creates a NUM_ROWS x NUM_COLS grid filled with 0s initially
game_map = [[0] * NUM_COLS for _ in range(NUM_ROWS)]

# Example: place a "green" block in the middle
game_map[NUM_ROWS // 2][NUM_COLS // 2] = 1

# --- Set up the display ---
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Array Backed Grid Example")

# --- Function to draw the grid based on the array ---
def draw_grid(map_data):
    for row in range(NUM_ROWS):
        for col in range(NUM_COLS):
            # Determine color based on the value in the array
            color = COLOR_WHITE if map_data[row][col] == 0 else COLOR_GREEN
            
            # Draw the rectangle at the correct screen position
            pygame.draw.rect(screen, color, (col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))
            
            # Optionally, draw a border to show the grid lines
            pygame.draw.rect(screen, COLOR_BLACK, (col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE), 1)

# --- Main game loop ---
running = True
while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            # Example interaction: change a grid cell value on click
            x, y = event.pos
            col = x // SQUARE_SIZE
            row = y // SQUARE_SIZE
            # Toggle the value between 0 and 1
            game_map[row][col] = 1 if game_map[row][col] == 0 else 0


    # Drawing
    screen.fill(COLOR_WHITE) # Fill background
    draw_grid(game_map) # Draw the grid from the array data

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
