import pygame as pg

class Player(pg.sprite.Sprite):
    def __init__(self, pos, sprite_sheet_image):
        super().__init__()
        # 1. Extract frames from the sheet and store them in a list
        self.images = self.extract_frames(sprite_sheet_image)
        self.frame_index = 0
        self.image = self.images[self.frame_index]
        self.rect = self.image.get_rect(center=pos)
        
        # Animation timing variables
        self.animation_speed = 0.1 # Adjust as needed (lower is faster)
        self.animation_timer = 0
        self.moving = False

    def extract_frames(self, sheet):
        # Assuming the 3 images are in a horizontal strip, each 32x32 pixels
        frame_width = 32
        frame_height = 32
        frames = []
        for i in range(3):
            # Create a new surface for each frame
            frame = pg.Surface((frame_width, frame_height), pg.SRCALPHA)
            # Blit the specific portion of the spritesheet onto the new surface
            frame.blit(sheet, (0, 0), (i * frame_width, 0, frame_width, frame_height))
            frames.append(frame)
        return frames

    def update(self, dt, moving):
        self.moving = moving
        if self.moving:
            # Update animation timer using delta time (dt) for smooth animation
            self.animation_timer += dt
            if self.animation_timer >= self.animation_speed:
                self.animation_timer = 0
                # Cycle through frames
                self.frame_index = (self.frame_index + 1) % len(self.images)
                self.image = self.images[self.frame_index]
        else:
            # Optional: Reset to a specific idle frame when not moving
            self.frame_index = 0
            self.image = self.images[self.frame_index]

    def handle_input(self, keys):
        # Example movement logic
        if keys[pg.K_LEFT]:
            self.rect.x -= 5
            # You would also swap animation lists here if you have different directions
        if keys[pg.K_RIGHT]:
            self.rect.x += 5
        # Add other movement logic (up/down/jump) here

