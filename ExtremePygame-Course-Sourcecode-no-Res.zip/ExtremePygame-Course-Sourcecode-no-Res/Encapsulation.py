import pygame
import sys

# 1. Encapsulate game objects (e.g., Player)
class Player:
    def __init__(self, x, y):
        self.image = pygame.Surface((50, 50))
        self.image.fill((0, 128, 255))  # Blue color
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 5

    def update(self):
        # Encapsulate movement logic
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        # Keep player within screen boundaries (simple encapsulation)
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > 800:
            self.rect.right = 800

    def draw(self, surface):
        # Encapsulate drawing logic
        surface.blit(self.image, self.rect)

# 2. Encapsulate the main game logic
class Game:
    def __init__(self):
        pygame.init()
        self.WIDTH, self.HEIGHT = 800, 600
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        pygame.display.set_caption("Encapsulated Pygame Example")
        self.clock = pygame.time.Clock()
        self.running = True
        self.player = Player(self.WIDTH // 2, self.HEIGHT // 2)

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

            # Update game logic
            self.player.update()

            # Drawing
            self.screen.fill((30, 30, 30)) # Dark grey background
            self.player.draw(self.screen)

            # Refresh the display
            pygame.display.flip()

            # Cap the frame rate
            self.clock.tick(60)

        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    my_game = Game()
    my_game.run()
