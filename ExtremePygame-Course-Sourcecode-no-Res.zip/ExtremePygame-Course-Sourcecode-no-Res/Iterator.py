import pygame
import sys

def main():
    # 1. Initialize Pygame
    pygame.init()

    # Set up the display
    screen_width, screen_height = 800, 600
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Pygame Iterator Example")

    # Set up the clock for controlling frame rate
    clock = pygame.time.Clock()
    
    # Define colors
    WHITE = (255, 255, 255)
    BLUE = (0, 0, 255)

    # Game loop condition
    running = True

    # 2. Main Game Loop (The Iterator)
    while running:
        # 3. Event Handling Loop (Inner Iterator)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False # Exit the main loop
            # Add other input handling (keyboard/mouse) here
            # e.g., if event.type == pygame.KEYDOWN: ...

        # 4. Game Logic Update
        # This is where you would update positions, check collisions, etc.
        # Example: iterate through a list of bullets or enemies and update them.
        # for enemy in enemies_list:
        #     enemy.update()

        # 5. Drawing
        screen.fill(WHITE) # Clear screen with background color
        pygame.draw.circle(screen, BLUE, (screen_width // 2, screen_height // 2), 50) # Draw an object
        
        # 6. Update the display
        pygame.display.flip() # Swap buffers to make everything visible
        
        # 7. Cap the frame rate
        clock.tick(60) # Limit to 60 FPS

    # 8. Quit Pygame
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
