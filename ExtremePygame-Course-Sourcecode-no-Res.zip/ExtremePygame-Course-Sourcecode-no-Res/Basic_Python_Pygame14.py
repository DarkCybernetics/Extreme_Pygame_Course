
import pygame
import sys

# Initialize Pygame
pygame.init()

# --- Configuration ---
WIDTH, HEIGHT = 400, 300
WINDOW = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("RED GREEN BLUE If-Else Pygame Example")

# Define Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
current_color = WHITE # Default color

# --- Main Game Loop ---
running = True
while running:
    # 1. Event Handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False # Exit the game loop if the user closes the window
        
        # Check for key presses using if/elif/else
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r:
                current_color = RED # Change color to RED if 'R' key is pressed
            elif event.key == pygame.K_g:
                current_color = GREEN # Change color to GREEN if 'G' key is pressed
            elif event.key == pygame.K_b:
                current_color = BLUE # Change color to BLUE if 'B' key is pressed
            else:
                # Revert to WHITE if any other key is pressed
                current_color = WHITE 

    # 2. Drawing
    # Fill the screen with the current_color, effectively changing the background
    WINDOW.fill(current_color)

    # 3. Update the display
    pygame.display.update()

# Quit Pygame
pygame.quit()
sys.exit()
