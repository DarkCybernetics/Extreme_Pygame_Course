import pygame
import sys

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((400, 300))
font = pygame.font.Font(None, 36)

# Setup Store
sword_rect = pygame.Rect(100, 100, 200, 50)
sword_price = 50
sell_value_sworld = 25 # half the value of the purchase price
shield_price = 40
sell_value_shield = 20 # can you add images for this model
potion_price = 20
sell_value_potion = 10 # what  other data structures can be used to store this?
player_gold = 1000
# Store Layout
# Buy  = full Price
# Sell = Half Price , a broken item has no sell value 
# stackable items in the player inventory <10,4> Grid Player inventory
# Merchant inventory < whole half screen sometimes> <20x20?>
# Leave Store = back to the game world or current map outside the store menu state
# Chat with the Merchance = more store about the game
# Gamble = get a random item from the store < items in the store have unknown attributes>
# Repair Items , Therefore items have durabilities 
# Magical Store : recharge , immue items with magic
# Socket items = certain item with so many holes based on type for gems
inventory = []
# Can you buy and sell items?
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        # Handle Mouse Click
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left click
                if sword_rect.collidepoint(event.pos):
                    if player_gold >= sword_price:
                        player_gold -= sword_price
                        inventory.append("Sword")
                        print("Bought Sword!")
                    else:
                        print("Not enough gold!")

    # Draw store
    screen.fill((255, 255, 255))
    pygame.draw.rect(screen, (0, 0, 255), sword_rect)
    # First Problem : you need to output the same message different data
    text = font.render(f"Buy Sword: {sword_price}g", True, (255, 255, 255))
    # Your store sells more than one item? < can you make a list>
    # should sword_price = item_price?
    # have an array that store the relative pairing of data elements
    # you can make it look way better using other features in Python

    screen.blit(text, (sword_rect.x + 10, sword_rect.y + 10))
#how do you add other system buttons and menus for the game world    
    # Draw player gold
    gold_text = font.render(f"Gold: {player_gold}", True, (0, 0, 0))
    screen.blit(gold_text, (10, 10))
    
    pygame.display.flip()

pygame.quit()
sys.exit()
