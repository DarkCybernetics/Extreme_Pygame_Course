import pygame
import random

# Initialize Pygame
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Colors
RED = (255, 0, 0)

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Load image (replace 'enemy.png' with your file)
        self.image = pygame.Surface((30, 30)) 
        self.image.fill(RED) # Placeholder if no image
        # self.image = pygame.image.load('enemy.png').convert_alpha()
        
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(0, WIDTH - self.rect.width)
        self.rect.y = random.randrange(0, HEIGHT - self.rect.height)
        
        self.speed = 3
        # Directions: UP, DOWN, LEFT, RIGHT
        self.directions = [(0, -self.speed), (0, self.speed), (-self.speed, 0), (self.speed, 0)]
        self.current_direction = random.choice(self.directions)
        self.move_timer = 0

    def update(self):
        # Move the enemy
        self.rect.x += self.current_direction[0]
        self.rect.y += self.current_direction[1]
        
        # Change direction randomly every 60 frames
        self.move_timer += 1
        if self.move_timer > 60:
            self.current_direction = random.choice(self.directions)
            self.move_timer = 0

        # Boundary Check - Keep within screen
        if self.rect.left < 0 or self.rect.right > WIDTH or \
           self.rect.top < 0 or self.rect.bottom > HEIGHT:
            # Change to opposite direction immediately
            self.current_direction = (-self.current_direction[0], -self.current_direction[1])

# Sprite Group
all_sprites = pygame.sprite.Group()
enemy = Enemy()
all_sprites.add(enemy)

# Game Loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
    # Update
    all_sprites.update()
    
    # Draw
    screen.fill((0, 0, 0)) # Clear screen
    all_sprites.draw(screen)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
