import pygame
import math

# Initialize Pygame
pygame.init()
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()

# Player variables
player_x, player_y = screen_width // 2, screen_height // 2
player_speed = 5
target_pos = None

# Bullet management
bullets = []

class Bullet:
    def __init__(self, start_pos, target_pos):
        self.rect = pygame.Rect(start_pos[0], start_pos[1], 10, 10)
        # Calculate direction vector
        distance_x = target_pos[0] - start_pos[0]
        distance_y = target_pos[1] - start_pos[1]
        norm = math.sqrt(distance_x**2 + distance_y**2)
        if norm != 0:
            self.direction_x = distance_x / norm
            self.direction_y = distance_y / norm
        else:
            self.direction_x = 0
            self.direction_y = 0
        self.speed = 10

    def update(self):
        self.rect.x += self.direction_x * self.speed
        self.rect.y += self.direction_y * self.speed

    def draw(self, screen):
        pygame.draw.rect(screen, (255, 0, 0), self.rect)

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button for movement
                target_pos = event.pos
            elif event.button == 3: # Right mouse button for shooting
                mouse_x, mouse_y = event.pos
                new_bullet = Bullet((player_x, player_y), (mouse_x, mouse_y))
                bullets.append(new_bullet)

    # Movement logic (outside the event loop)
    if target_pos:
        # Calculate vector to target
        dx = target_pos[0] - player_x
        dy = target_pos[1] - player_y
        distance = math.sqrt(dx**2 + dy**2)
        if distance > player_speed:
            player_x += (dx / distance) * player_speed
            player_y += (dy / distance) * player_speed
        else:
            player_x, player_y = target_pos
            target_pos = None # Reached target, stop moving

    # Update bullets
    for bullet in bullets[:]:
        bullet.update()
        # Remove bullets that go off screen
        if bullet.rect.right < 0 or bullet.rect.left > screen_width or bullet.rect.bottom < 0 or bullet.rect.top > screen_height:
            bullets.remove(bullet)

    # Drawing
    screen.fill((255, 255, 255)) # White background
    pygame.draw.circle(screen, (0, 0, 0), (int(player_x), int(player_y)), 20) # Draw player
    for bullet in bullets:
        bullet.draw(screen)

    # Update the display
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
