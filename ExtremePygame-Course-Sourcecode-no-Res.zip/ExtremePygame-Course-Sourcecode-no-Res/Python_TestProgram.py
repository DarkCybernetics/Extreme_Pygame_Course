import pygame
import sys
# 1. Initialize Pygame
pygame.init()
# 2. Set up the window dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("My Basic Pygame Window")
# 3. Create a clock object to control frame rate
clock = pygame.time.Clock()
# 4. Main game loop
running = True
while running:
# 5. Handle events (user actions)
for event in pygame.event.get():
if event.type == pygame.QUIT:
running = False
# 6. Game logic and drawing
# Fill the screen with a color (e.g., white) to clear the previous frame
screen.fill((255, 255, 255)) # RGB value for white
# (Add your game rendering code here)
# 7. Update the display
pygame.display.flip() # or pygame.display.update()
# 8. Cap the frame rate
clock.tick(60) # limits FPS to 60
# 9. Quit Pygame when the loop ends
pygame.quit()
sys.exit()
