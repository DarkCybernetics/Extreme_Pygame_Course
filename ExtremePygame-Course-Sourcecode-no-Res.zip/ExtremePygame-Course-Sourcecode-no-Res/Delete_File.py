import pygame
import os
import sys

# --- Pygame Setup (Standard boilerplate) ---
pygame.init()
screen_width, screen_height = 400, 300
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("File Deletion Example")
clock = pygame.time.Clock()

# Define file path for the save file
SAVE_FILE = "gamesave.txt"

# Helper function to create a dummy save file for demonstration
def create_save_file(filename):
    try:
        with open(filename, "w") as f:
            f.write("score: 100\nlevel: 5")
        print(f"Created dummy file: {filename}")
    except IOError as e:
        print(f"Error creating file: {e}")

# Function to delete the file
def delete_save_file(filename):
    # Check if the file exists before attempting deletion to prevent errors
    if os.path.exists(filename):
        try:
            os.remove(filename)
            print(f"Successfully deleted file: {filename}")
        except OSError as e:
            print(f"Error deleting file {filename}: {e}")
    else:
        print(f"File not found: {filename}")

# --- Main Game Loop ---
running = True
create_save_file(SAVE_FILE) # Create the file when the game starts

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            # Press 'd' key to delete the file
            if event.key == pygame.K_d:
                delete_save_file(SAVE_FILE)
            # Press 'c' key to recreate the file
            if event.key == pygame.K_c:
                create_save_file(SAVE_FILE)

    # --- Game logic and drawing (simplified) ---
    screen.fill((255, 255, 255)) # Fill background with white
    # In a real game, you would draw your sprites and game elements here

    pygame.display.flip()
    clock.tick(30)

# --- Cleanup ---
pygame.quit()
sys.exit()
