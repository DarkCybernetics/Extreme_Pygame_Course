import pygame

# Initialize Pygame
pygame.init()
font = pygame.font.Font(None, 36)
screen = pygame.display.set_mode((400, 200))

class Player:
    def __init__(self):
        self.level = 1
        self.exp = 0
        self.next_level_exp = 100

    def gain_exp(self, amount):
        self.exp += amount
        print(f"Gained {amount} XP!")
        self.check_level_up()

    def check_level_up(self):
        # Simple exponential growth formula for levels
        while self.exp >= self.next_level_exp:
            self.exp -= self.next_level_exp
            self.level += 1
            self.next_level_exp = int(self.next_level_exp * 1.5)
            print(f"Level up! Now level {self.level}")
        #        if(level == 10) # if you get to level 10 gain new skill: fireball
         #            print(f"You Learned Fireball")

    def draw_stats(self, surface):
        stats = [
            f"Level: {self.level}",
            f"XP: {self.exp}/{self.next_level_exp}"
        ]
        for i, text in enumerate(stats):
            render = font.render(text, True, (255, 255, 255))
            surface.blit(render, (10, 10 + i * 40))

# Game setup
player = Player()
clock = pygame.time.Clock()
running = True

# Main Loop
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        # Press Space to gain 50 XP
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            player.gain_exp(50)

    screen.fill((0, 0, 0))
    player.draw_stats(screen)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
