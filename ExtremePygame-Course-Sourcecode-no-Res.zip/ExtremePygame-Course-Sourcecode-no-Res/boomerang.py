import pygame
import math

# Constants
WIDTH, HEIGHT = 800, 600
BOOMERANG_SPEED = 10
RETURN_TIME = 500  # Milliseconds before return

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill((0, 255, 0))
        self.rect = self.image.get_rect(center=(WIDTH//2, HEIGHT//2))
        self.direction = pygame.math.Vector2(1, 0) # Facing right

    def shoot(self):
        # Create a boomerang at player position
        return Boomerang(self.rect.center, self.direction)

class Boomerang(pygame.sprite.Sprite):
    def __init__(self, pos, direction):
        super().__init__()
        self.image = pygame.Surface((20, 20))
        self.image.fill((255, 0, 0)) # Red
        self.rect = self.image.get_rect(center=pos)
        self.pos = pygame.math.Vector2(pos)
        self.velocity = direction * BOOMERANG_SPEED
        self.spawn_time = pygame.time.get_ticks()
        self.returning = False

    def update(self):
        # Return mechanism based on time
        if not self.returning and pygame.time.get_ticks() - self.spawn_time > RETURN_TIME:
            self.velocity *= -1
            self.returning = True
        
        # Move
        self.pos += self.velocity
        self.rect.center = self.pos

        # Kill if it returns to player (simple collision or distance check)
        if self.returning and self.rect.colliderect(player.rect):
            self.kill()

# Pygame Setup
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
all_sprites = pygame.sprite.Group()
boomerangs = pygame.sprite.Group()

player = Player()
all_sprites.add(player)

# Main Loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Shoot boomerang
                b = player.shoot()
                all_sprites.add(b)
                boomerangs.add(b)

    all_sprites.update()
    
    screen.fill((0, 0, 0))
    all_sprites.draw(screen)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
