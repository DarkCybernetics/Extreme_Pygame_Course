import pygame

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

# Room Data (0: ground, 1: wall)
room1 = [[1,1,1,1,1],
         [1,0,1,0,1],
         [1,0,0,0,1],
         [1,1,1,1,1]]

room2 = [[0,0,0,0,0],
         [0,1,0,1,0],
         [0,1,0,1,0],
         [1,1,0,0,0]]

current_map = room1
tile_size = 32

def draw_map(map_data):
    for row_idx, row in enumerate(map_data):
        for col_idx, tile in enumerate(row):
            if tile == 1:
                rect = pygame.Rect(col_idx * tile_size, row_idx * tile_size, tile_size, tile_size)
                pygame.draw.rect(screen, (255, 0, 0), rect) # Draw wall
            elif tile == 0:
                rect = pygame.Rect(col_idx * tile_size, row_idx * tile_size, tile_size, tile_size)
                pygame.draw.rect(screen, (0, 255, 0), rect) # Draw ground

# Game Loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        # Room Translation on Key Press (e.g., Spacebar)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Switch to room 2
                current_map = room2

    screen.fill((0, 0, 0))
    draw_map(current_map)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
