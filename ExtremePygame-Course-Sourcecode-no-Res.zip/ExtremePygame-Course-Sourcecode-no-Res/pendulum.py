import pygame
import math

# Initialize Pygame
pygame.init()
width, height = 800, 600
screen = pygame.display.set_mode((width, height))
clock = pygame.time.Clock()

# Pendulum properties
origin = (width // 2, 100)
length = 300

angle = math.pi / 4  # Initial angle (45 degrees)
angle_v = 0.0        # Angular velocity
angle_a = 0.0        # Angular acceleration
gravity = 0.5        # Gravity strength
damping = 0.995      # Simple air resistance

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Physics: Pendulum formula
    angle_a = (-1 * gravity / length) * math.sin(angle)
    angle_v += angle_a
    angle_v *= damping
    angle += angle_v

    # Polar to Cartesian conversion
    x = length * math.sin(angle) + origin[0]
    y = length * math.cos(angle) + origin[1]

    # Draw everything
    screen.fill((255, 255, 255))
    pygame.draw.line(screen, (0, 0, 0), origin, (x, y), 2)
    pygame.draw.circle(screen, (200, 0, 0), (int(x), int(y)), 20)
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
