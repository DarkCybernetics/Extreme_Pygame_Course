import pygame
pygame.init()

SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
font = pygame.font.SysFont('Arial', 24) # Load a system font
# Or load a custom font: pygame.font.Font('path/to/your/font.ttf', 24)

# Load NPC images (ensure image files are in your project folder)
npc_images = {
    'npc1': pygame.image.load('npc1_portrait.png').convert_alpha(),
    'npc2': pygame.image.load('npc2_portrait.png').convert_alpha(),
}

def draw_dialog_box(surface, text_lines, npc_image_key=None):
    # Dialogue box dimensions and position
    box_height = 200
    box_width = SCREEN_WIDTH - 40
    box_x = 20
    box_y = SCREEN_HEIGHT - box_height - 20
    
    # Draw the background rectangle (e.g., light gray with a black border)
    pygame.draw.rect(surface, (200, 200, 200), (box_x, box_y, box_width, box_height))
    pygame.draw.rect(surface, (0, 0, 0), (box_x, box_y, box_width, box_height), 2)

    # Display NPC image if provided
    if npc_image_key and npc_image_key in npc_images:
        image = npc_images[npc_image_key]
        image_rect = image.get_rect()
        image_rect.topleft = (box_x + 10, box_y + 10) # Position in the box
        surface.blit(image, image_rect)
        text_start_x = image_rect.right + 10
    else:
        text_start_x = box_x + 10

    # Render and display text
    text_start_y = box_y + 10
    for i, line in enumerate(text_lines):
        text_surface = font.render(line, True, (0, 0, 0))
        surface.blit(text_surface, (text_start_x, text_start_y + i * 30))
# Example Dialogue Structure
dialogues = {
    'intro': [
        {"speaker": "npc1", "text": "Hello, adventurer! Welcome to Pygame RPG."},
        {"speaker": "npc1", "text": "Are you ready for your journey? [Press Space]"},
    ],
    # Add more dialogue sequences
}

current_dialogue = None
dialogue_index = 0
dialogue_active = False

# Function to start a dialogue
def start_dialogue(key):
    global current_dialogue, dialogue_index, dialogue_active
    current_dialogue = dialogues[key]
    dialogue_index = 0
    dialogue_active = True

# In your main game loop, manage events and drawing
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and dialogue_active:
                dialogue_index += 1
                if dialogue_index >= len(current_dialogue):
                    dialogue_active = False # End dialogue
                    current_dialogue = None

    # Game logic and drawing of world/player goes here
    screen.fill((30, 30, 30)) # Clear screen

    # Check for player collision with NPC to start dialogue (example logic)
    # if player_rect.colliderect(npc_rect) and not dialogue_active:
    #     start_dialogue('intro')

    # Draw dialogue box if active
    if dialogue_active and current_dialogue:
        current_message = current_dialogue[dialogue_index]
        draw_dialog_box(screen, [current_message["text"]], current_message["speaker"])

    pygame.display.flip() # Update the display
