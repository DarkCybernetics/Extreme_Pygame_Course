import pygame

# 1. Configuration
MINI_TILE = 4 # Size of each tile on minimap
MAP_DATA = [
    [1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1],
    [1, 0, 1, 0, 1],
    [1, 0, 0, 0, 1],
    [1, 1, 1, 1, 1]
]

def draw_minimap(surface, player_pos):
    # 2. Create surface
    map_w = len(MAP_DATA[0]) * MINI_TILE
    map_h = len(MAP_DATA) * MINI_TILE
    mini_surf = pygame.Surface((map_w, map_h))
    mini_surf.fill((100, 100, 100)) # Background

    # 3. Draw Tiles
    for row, tiles in enumerate(MAP_DATA):
        for col, tile in enumerate(tiles):
            if tile == 1: # Wall
                pygame.draw.rect(mini_surf, (0, 0, 0), 
                                 (col * MINI_TILE, row * MINI_TILE, MINI_TILE, MINI_TILE))
    
    # 4. Draw Player
    p_x = int(player_pos[0] // 32 * MINI_TILE) # Assuming 32x32 regular tiles
    p_y = int(player_pos[1] // 32 * MINI_TILE)
    pygame.draw.rect(mini_surf, (255, 0, 0), (p_x, p_y, MINI_TILE, MINI_TILE))
    
    # 5. Render to Screen
    surface.blit(mini_surf, (10, 10)) # Top-left corner
