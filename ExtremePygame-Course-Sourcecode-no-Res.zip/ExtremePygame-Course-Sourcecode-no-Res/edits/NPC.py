import pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("RPG NPC Dialogue Example")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)

# Fonts
font = pygame.font.SysFont('Arial', 24) # Use a common font or load a custom one

# Load Assets (replace 'dialog_box.png' and 'npc_image.png' with your own image paths)
# You may need to adjust the paths based on your project structure.
try:
    dialog_box_bg = pygame.image.load('dialog_box_bg.png').convert_alpha() # Use convert_alpha for transparency
    npc_image = pygame.image.load('npc_image.png').convert_alpha()
except pygame.error as e:
    print(f"Error loading assets: {e}")
    # Create placeholder surfaces if images are missing
    dialog_box_bg = pygame.Surface((700, 150))
    dialog_box_bg.fill(BLUE)
    npc_image = pygame.Surface((100, 100))
    npc_image.fill(WHITE)


# Dialogue data
dialogue_text = ["Hello adventurer!", "I have a quest for you.", "Are you up for the challenge?"]
current_dialogue_index = -1
dialogue_active = False

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if dialogue_active:
                    # Advance dialogue
                    current_dialogue_index += 1
                    if current_dialogue_index >= len(dialogue_text):
                        dialogue_active = False # End dialogue
                        current_dialogue_index = -1
                else:
                    # Start dialogue (trigger condition would be here in a real game)
                    dialogue_active = True
                    current_dialogue_index = 0

    screen.fill(BLACK) # Clear screen

    # Draw game elements (player, world, etc. would go here)
    # ...

    # Draw dialogue box and image if active
    if dialogue_active and current_dialogue_index != -1:
        # 1. Draw the dialogue box background
        # Position it at the bottom of the screen
        box_x = (SCREEN_WIDTH - dialog_box_bg.get_width()) // 2
        box_y = SCREEN_HEIGHT - dialog_box_bg.get_height() - 10
        screen.blit(dialog_box_bg, (box_x, box_y))

        # 2. Draw the NPC image inside the dialogue box area
        image_x = box_x + 10 # Offset from the left edge of the box
        image_y = box_y + 10
        screen.blit(npc_image, (image_x, image_y))

        # 3. Render and draw the current dialogue text
        current_text = dialogue_text[current_dialogue_index]
        text_surface = font.render(current_text, True, WHITE)
        # Position the text next to the image
        text_x = image_x + npc_image.get_width() + 20
        text_y = image_y + 20
        screen.blit(text_surface, (text_x, text_y))

    pygame.display.flip() # Update the display

# Quit Pygame
pygame.quit()
