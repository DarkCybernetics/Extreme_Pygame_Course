import pygame
import sys

# Initialize Pygame
pygame.init()

# --- Game Setup ---
WINDOW_WIDTH = 600
WINDOW_HEIGHT = 400
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Pygame Boolean Example")

# Define colors (RGB tuples)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# --- Boolean Variables ---
running = True  # Controls the main game loop
paused = False  # Controls the pause state

# Setup font for displaying text
font = pygame.font.SysFont(None, 50)

def draw_text(text, font, color, surface, x, y):
    textobj = font.render(text, True, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    surface.blit(textobj, textrect)

# --- Main Game Loop ---
while running:
    # 1. Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False  # Set running to False to exit the loop
        if event.type == pygame.KEYUP: # Use KEYUP to toggle only once per press
            if event.key == pygame.K_ESCAPE:
                paused = not paused # Toggle the paused boolean

    # 2. Game logic (only runs if not paused)
    if not paused:
        # Example game logic: screen changes color
        # In a real game, this is where you'd update character positions, check collisions, etc.
        screen.fill(RED)
        draw_text('Game Running', font, BLACK, screen, 200, 180)
    else:
        # Pause logic
        screen.fill(BLACK)
        draw_text('PAUSED', font, WHITE, screen, 240, 180)
        draw_text('Press ESC to resume', font, WHITE, screen, 150, 240)

    # 3. Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()
