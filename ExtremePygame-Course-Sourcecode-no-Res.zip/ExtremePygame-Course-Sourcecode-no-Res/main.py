# main.py
import pygame from player import Player # Import the Player class from the player module


pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pygame Class Import Example")

# Colors
WHITE = (255, 255, 255)

# Create an instance of the Player class
# Ensure 'my_image.png' exists in the correct path for this example to work
my_player = Player(WIDTH // 2, HEIGHT // 2, 'player.png') 


running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update player (if update method had logic)
    my_player.update()

    # Drawing
    screen.fill(WHITE)
    my_player.draw(screen)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
