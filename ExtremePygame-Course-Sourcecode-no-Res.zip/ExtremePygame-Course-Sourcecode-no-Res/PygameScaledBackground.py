import pygame
import sys

# 1. Initialize Pygame
pygame.init()

# 2. Set the screen size
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Scaled Background Example")

# 3. Load the image
# Replace "background.png" with the path to your image file
original_background_image = pygame.image.load("background_grass.png").convert()

# 4. Scale the image to fit the screen dimensions
# Using smoothscale often provides better quality for scaling
scaled_background_image = pygame.transform.smoothscale(original_background_image, (screen_width, screen_height))

# Get the rectangle of the scaled image for easy positioning
background_rect = scaled_background_image.get_rect()
# The top-left corner is (0, 0) by default, which is perfect for a background

# 5. Game loop
running = True
while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Drawing
    # Blit the scaled background image onto the screen Surface
    screen.blit(scaled_background_image, background_rect)

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()

