
import pygame
import sys

# Function to save the final score to a file
def save_score(score, filename="score.txt"):
    try:
        with open(filename, "w") as file:
            file.write(f"Final Score: {score}\n")
        print(f"Score saved to {filename}")
    except IOError as e:
        print(f"Failed to save score: {e}")

# Initialize Pygame
pygame.init()

# Screen settings
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame File Write Example")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Font
font = pygame.font.Font(None, 74) # Use default font, size 74

# Game variables
current_score = 0
running = True

# Main game loop
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Game logic (update score for demonstration)
    current_score += 1 # Score increases every frame

    # Drawing
    screen.fill(BLACK) # Fill the screen with black
    score_text = font.render(f"Score: {current_score}", True, WHITE)
    screen.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, SCREEN_HEIGHT // 2 - score_text.get_height() // 2))

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    pygame.time.Clock().tick(60)

# After the loop ends (when the user quits the game)
save_score(current_score)

# Quit Pygame
pygame.quit()
sys.exit()


