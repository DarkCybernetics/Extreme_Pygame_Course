from collections import deque

def bfs_traversal(graph, start_node):
    """
    Performs a Breadth-First Search traversal on a graph.

    Args:
        graph (dict): The graph represented as an adjacency list.
        start_node: The starting node for the traversal.

    Returns:
        list: The order in which nodes were visited.
    """
    visited = set()  # To keep track of visited nodes to avoid cycles
    queue = deque([start_node])  # Use deque for efficient O(1) append and pop operations
    visited.add(start_node)
    traversal_order = []

    while queue:
        # Dequeue a node from the front of the queue
        current_node = queue.popleft()
        traversal_order.append(current_node)
        
        # Enqueue all unvisited neighbors of the current node
        for neighbor in graph.get(current_node, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
                
    return traversal_order

# Example Usage:
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': ['F'],
    'F': []
}

# The traversal will visit nodes level by level (A -> B -> C -> D -> E -> F)
print(f"BFS Traversal starting from 'A': {bfs_traversal(graph, 'A')}")
