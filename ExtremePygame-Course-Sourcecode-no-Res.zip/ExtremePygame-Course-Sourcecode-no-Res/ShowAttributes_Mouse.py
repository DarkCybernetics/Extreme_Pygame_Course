import pygame

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
font = pygame.font.Font(None, 24)

# Enemy setup
enemy_rect = pygame.Rect(300, 300, 50, 50)
enemy_attrs = "HP: 100 / Atk: 10"

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((0, 0, 0)) # Clear screen
    
    # Draw Enemy
    pygame.draw.rect(screen, (255, 0, 0), enemy_rect)
    
    # 1. Get Mouse Position
    mouse_pos = pygame.mouse.get_pos()
    
    # 2. Check if mouse is over enemy
    if enemy_rect.collidepoint(mouse_pos):
        # 3. Render and draw attributes above the enemy
        text_surf = font.render(enemy_attrs, True, (255, 255, 255))
        text_rect = text_surf.get_rect(center=(enemy_rect.centerx, enemy_rect.top - 20))
        screen.blit(text_surf, text_rect)
    
    pygame.display.flip()

pygame.quit()
