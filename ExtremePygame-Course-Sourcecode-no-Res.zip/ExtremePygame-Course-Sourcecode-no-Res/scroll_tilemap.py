import pygame

# --- Configuration ---
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
TILE_SIZE = 32
MAP_WIDTH, MAP_HEIGHT = 20, 20 # Map size in tiles
SPEED = 5

# Example map data (0 = empty, 1 = wall tile)
# In a real game, this would be much larger and loaded from a file
TILEMAP = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

# --- Initialization ---
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Scrolling Tilemap Example")
clock = pygame.time.Clock()

# Load tile images (use simple colors for this example)
SKY_BLUE = (135, 206, 235)
BROWN = (139, 69, 19)
tile_images = {
    0: pygame.Surface((TILE_SIZE, TILE_SIZE)),
    1: pygame.Surface((TILE_SIZE, TILE_SIZE)),
}
tile_images[0].fill(SKY_BLUE)
tile_images[1].fill(BROWN)

# --- Camera/Offset ---
# This offset represents the top-left corner of what the screen sees
camera_x, camera_y = 0, 0

# --- Game Loop ---
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # --- Input Handling (Move the Camera/Viewpoint) ---
    keys = pygame.key.get_pressed()
    if keys[pygame.K_RIGHT]:
        camera_x += SPEED
    if keys[pygame.K_LEFT]:
        camera_x -= SPEED
    if keys[pygame.K_DOWN]:
        camera_y += SPEED
    if keys[pygame.K_UP]:
        camera_y -= SPEED
        
    # Optional: clamp camera to map boundaries
    camera_x = max(0, min(camera_x, MAP_WIDTH * TILE_SIZE - SCREEN_WIDTH))
    camera_y = max(0, min(camera_y, MAP_HEIGHT * TILE_SIZE - SCREEN_HEIGHT))

    # --- Drawing ---
    screen.fill(SKY_BLUE) # Fill background

    # Iterate through the map data and draw only visible tiles
    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            tile_type = TILEMAP[y][x]
            tile_image = tile_images[tile_type]

            # Calculate the screen position with the camera offset
            screen_x = (x * TILE_SIZE) - camera_x
            screen_y = (y * TILE_SIZE) - camera_y

            # Only draw tiles that are actually on the screen for performance
            if (screen_x + TILE_SIZE > 0 and screen_x < SCREEN_WIDTH and
                screen_y + TILE_SIZE > 0 and screen_y < SCREEN_HEIGHT):
                screen.blit(tile_image, (screen_x, screen_y))

    # --- Update the display ---
    pygame.display.flip()

    # --- Cap the frame rate ---
    clock.tick(60)

pygame.quit()

