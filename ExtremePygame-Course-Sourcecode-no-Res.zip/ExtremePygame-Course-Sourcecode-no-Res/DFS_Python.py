def dfs(graph, start_node, visited_nodes):
    # Mark the current node as visited and print/process it
    visited_nodes.add(start_node)
    print(start_node, end=' ')

    # Recursively visit all unvisited neighbors
    for next_node in graph[start_node]:
        if next_node not in visited_nodes:
            dfs(graph, next_node, visited_nodes)

# Example Usage:
graph = {
    'A': {'B', 'C'},
    'B': {'A', 'D', 'E'},
    'C': {'A'},
    'D': {'B'},
    'E': {'B', 'F'},
    'F': {'E'}
}

visited = set()
print("DFS Traversal (starting from node A):")
dfs(graph, 'A', visited) 
# Expected output might be something like: A B D E F C (order may vary by implementation)


