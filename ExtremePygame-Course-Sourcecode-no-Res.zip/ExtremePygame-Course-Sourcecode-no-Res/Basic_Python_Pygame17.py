
import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

# Create the display surface
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Class Example")

class Player(pygame.sprite.Sprite):
    """Represents a player character in the game."""
    def __init__(self):
        # Call the parent class (Sprite) constructor
        super().__init__()
        # Create a surface and fill it with color (e.g., a blue square)
        self.image = pygame.Surface([50, 50])
        self.image.fill(BLUE)
        # Get the rectangle object that has the dimensions of the image
        self.rect = self.image.get_rect()
        # Set the initial position
        self.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)

    def update(self):
        """Update the player's position."""
        # In a real game, you would add logic for movement based on user input
        # For this example, let's just make it move right slowly
        self.rect.x += 1

# Create an instance of the Player class
player_object = Player()

# Create a group for the player
all_sprites_group = pygame.sprite.Group()
all_sprites_group.add(player_object)

# Main game loop
running = True
clock = pygame.time.Clock()

while running:
    # 1. Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 2. Game logic/updates
    all_sprites_group.update()

    # 3. Drawing
    screen.fill(WHITE) # Clear screen with white
    all_sprites_group.draw(screen) # Draw all sprites in the group

    # 4. Update the display
    pygame.display.flip()

    # Limit frame rate
    clock.tick(60)

# Quit Pygame
pygame.quit()
sys.exit()
