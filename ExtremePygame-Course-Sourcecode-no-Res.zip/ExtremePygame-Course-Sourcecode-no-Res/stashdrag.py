import pygame

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

# Colors and Setup
WHITE = (255, 255, 255)
BLUE = (50, 50, 200)
RED = (200, 50, 50)
GRAY = (100, 100, 100)

# Item setup
item_rect = pygame.Rect(50, 50, 50, 50)
stash_rect = pygame.Rect(600, 200, 150, 150) # The target area

dragging = False
running = True

while running:
    screen.fill(WHITE)
    
    # Draw stash area
    pygame.draw.rect(screen, GRAY, stash_rect)
    
    # Draw Item
    pygame.draw.rect(screen, BLUE if not dragging else RED, item_rect)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1: # Left click
                if item_rect.collidepoint(event.pos):
                    dragging = True
                    
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                dragging = False
                # Check if dropped in stash
                if item_rect.colliderect(stash_rect):
                    print("Item added to stash!")
                    # Snap to center of stash or handle inventory logic
                    item_rect.center = stash_rect.center
                
        elif event.type == pygame.MOUSEMOTION:
            if dragging:
                item_rect.move_ip(event.rel) # Move item with mouse [3]

    pygame.display.flip()
    clock.tick(60)

pygame.quit()

