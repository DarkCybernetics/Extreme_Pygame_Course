import pygame

# --- Constants ---
TILE_SIZE = 32
MAP_WIDTH, MAP_HEIGHT = 10, 10
SCREEN_WIDTH, SCREEN_HEIGHT = MAP_WIDTH * TILE_SIZE, MAP_HEIGHT * TILE_SIZE

# --- TileMap Class with Getters/Setters ---
class TileMap:
    def __init__(self, data):
        self._data = data # _data implies it's "private"

    @property
    def data(self):
        """Getter for the entire map data."""
        return self._data

    def get_tile(self, x, y):
        """Getter for a specific tile type."""
        return self._data[y][x]

    def set_tile(self, x, y, tile_type):
        """Setter to update a tile at a specific position."""
        if 0 <= y < len(self._data) and 0 <= x < len(self._data[0]):
            self._data[y][x] = tile_type

    def draw(self, surface):
        """Iterate through the grid and draw tiles."""
        for y, row in enumerate(self._data):
            for x, col in enumerate(row):
                rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                if col == 1: # Wall
                    pygame.draw.rect(surface, (100, 100, 100), rect)
                elif col == 0: # Floor
                    pygame.draw.rect(surface, (200, 200, 200), rect)
                pygame.draw.rect(surface, (0, 0, 0), rect, 1) # Grid lines

# --- Initialization ---
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

# Example map data: 0 = floor, 1 = wall
map_data = [[1 if x == 0 or x == MAP_WIDTH-1 or y == 0 or y == MAP_HEIGHT-1 else 0 
             for x in range(MAP_WIDTH)] for y in range(MAP_HEIGHT)]

tile_map = TileMap(map_data)

# --- Main Loop ---
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        # Example: Change tile on click
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()
            tile_map.set_tile(mx // TILE_SIZE, my // TILE_SIZE, 1)

    screen.fill((0, 0, 0))
    tile_map.draw(screen)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
