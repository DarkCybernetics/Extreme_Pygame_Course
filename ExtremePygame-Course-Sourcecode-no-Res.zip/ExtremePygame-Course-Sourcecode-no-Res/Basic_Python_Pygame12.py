
import pygame

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 400, 300
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pygame Sets Scancode Button Mapping Example")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Set to store currently pressed keys
pressed_keys = set()

# Game loop
running = True
while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            # Add the pressed key's scancode to the set
            pressed_keys.add(event.key)
            print(f"Keys pressed: {pressed_keys}")
        elif event.type == pygame.KEYUP:
            # Remove the released key's scancode from the set
            if event.key in pressed_keys:
                pressed_keys.remove(event.key)
                print(f"Keys pressed: {pressed_keys}")

    # Game logic (use the 'pressed_keys' set for continuous movement, etc.)
    # Example: if pygame.K_SPACE in pressed_keys: print("Jump!")

    # Drawing
    screen.fill(WHITE) # Fill the screen with white
    # Drawing code goes here

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
