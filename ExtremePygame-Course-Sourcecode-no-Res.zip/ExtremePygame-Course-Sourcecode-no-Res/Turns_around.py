import pygame

# Initialize
pygame.init()
screen = pygame.display.set_mode((800, 400))
clock = pygame.time.Clock()

# Setup
player_x, player_y = 100, 300
player_speed = 5
player_rect = pygame.Rect(player_x, player_y, 50, 50)
ledge_rect = pygame.Rect(50, 350, 900, 50)
direction = 1 # 1 = right, -1 = left

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Move
    player_rect.x += player_speed * direction
    
    # Ledge collision (turn around)
    if player_rect.left < ledge_rect.left or player_rect.right > ledge_rect.right:
        direction *= -1

    # Drawing
    screen.fill((135, 206, 235))
    pygame.draw.rect(screen, (139, 69, 19), ledge_rect) # Ledge
    pygame.draw.rect(screen, (255, 0, 0), player_rect) # Player
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
