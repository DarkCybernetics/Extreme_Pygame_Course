
import pygame
import sys
import os # Import the os module for path joining

# Initialize Pygame
pygame.init()

# --- Game Configuration ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
CAPTION = "OOP Pygame Example"

# Colors (RGB)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Setup the display
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption(CAPTION)

# Clock to control frame rate
clock = pygame.time.Clock()

# --- Player Class Definition ---
# The pygame.sprite.Sprite class provides useful boilerplate methods
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__() # Call the parent class (Sprite) constructor
        # Load image. Ensure 'player.png' exists in the script's directory.
        # Use os.path.join for better compatibility across operating systems.
        image_path = os.path.join(os.path.dirname(__file__), 'player.png')
        try:
            self.image = pygame.image.load(image_path).convert_alpha()
        except pygame.error:
            print(f"Error: player.png not found at {image_path}. Using a placeholder surface.")
            self.image = pygame.Surface([50, 50], pygame.SRCALPHA) # Placeholder if image missing
            self.image.fill(WHITE) # Fill placeholder with white

        self.rect = self.image.get_rect() # Get the rectangle that represents the image
        self.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2) # Center the player initially
        self.speed = 5

    def update(self):
        """Update the player's position based on key presses."""
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        if keys[pygame.K_UP]:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN]:
            self.rect.y += self.speed
        
        # Keep player on screen
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

# --- Main Game Loop Setup ---
all_sprites = pygame.sprite.Group()
player = Player()
all_sprites.add(player)

running = True
while running:
    # 1. Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 2. Update game logic
    all_sprites.update() # Calls the update method of all sprites in the group

    # 3. Draw to screen
    screen.fill(BLACK) # Clear screen with black
    all_sprites.draw(screen) # Draw all sprites to the screen

    # 4. Refresh display and cap frame rate
    pygame.display.flip()
    clock.tick(FPS)

# Quit Pygame
pygame.quit()
sys.exit()
