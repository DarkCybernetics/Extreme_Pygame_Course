class Item:
    def __init__(self, name, description):
        self.name = name
        self.description = description

class Inventory:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)
        print(f"{item.name} added to inventory.")

    def remove_item(self, item_name):
        self.items = [item for item in self.items if item.name != item_name]
        print(f"{item_name} removed.")

    def display(self):
        print("Inventory:")
        for item in self.items:
            print(f"- {item.name}: {item.description}")

# Usage
my_inv = Inventory()
sword = Item("Sword", "A sharp blade")
potion = Item("Potion", "Heals 50 HP")

my_inv.add_item(sword)
my_inv.add_item(potion)
my_inv.display()
