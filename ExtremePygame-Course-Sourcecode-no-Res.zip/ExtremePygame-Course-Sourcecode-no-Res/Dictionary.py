import pygame
from pygame.locals import * # Import key constants for easy access

pygame.init()

# Define colors using RGB tuples
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)

# Create a dictionary to map keys to colors
key_color_dict = {
    K_k: BLACK,
    K_r: RED,
    K_g: GREEN,
    K_b: BLUE,
    K_w: WHITE
}

screen = pygame.display.set_mode((400, 300))
pygame.display.set_caption("Dictionary Key Mapper")

running = True
background_color = WHITE # Default background color

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            # Check if the pressed key is in the dictionary
            if event.key in key_color_dict:
                background_color = key_color_dict[event.key] # Update background color

    screen.fill(background_color) # Fill the screen with the current color
    pygame.display.flip()

pygame.quit()
