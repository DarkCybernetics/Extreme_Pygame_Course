
import pygame
import sys

# Initialize pygame
pygame.init()

# 1. Use a tuple for screen dimensions (width, height)
SCREEN_SIZE = (800, 600)
screen = pygame.display.set_mode(SCREEN_SIZE)
pygame.display.set_caption("Pygame Tuple Example")

# 2. Use tuples for colors (R, G, B values from 0-255)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Game loop
running = True
while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 3. Use a tuple as an argument for screen.fill()
    screen.fill(WHITE)

    # 4. Use tuples as arguments for drawing functions
    # Draw a circle: screen, color, center_coordinates, radius
    pygame.draw.circle(screen, BLUE, (400, 300), 50) # Center is a tuple

    # Update the display to show the new drawings
    pygame.display.flip()

# Quit pygame
pygame.quit()
sys.exit()
