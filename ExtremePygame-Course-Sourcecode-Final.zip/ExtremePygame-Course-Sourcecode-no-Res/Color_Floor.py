import pygame
import math

# --- Configuration ---
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 400
MAP_SIZE = 8
TILE_SIZE = SCREEN_HEIGHT // MAP_SIZE
FOV = math.pi / 3  # 60 degrees
HALF_FOV = FOV / 2
NUM_RAYS = 120
STEP_ANGLE = FOV / NUM_RAYS
MAX_DEPTH = MAP_SIZE * TILE_SIZE

# --- Simple Map (1 = Wall, 0 = Empty) ---
GAME_MAP = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 1, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 1, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1],
]

# --- Player Setup ---
player_x, player_y = TILE_SIZE * 1.5, TILE_SIZE * 1.5
player_angle = 0

pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

def cast_rays():
    start_angle = player_angle - HALF_FOV
    
    for ray in range(NUM_RAYS):
        angle = start_angle + ray * STEP_ANGLE
        sin_a = math.sin(angle)
        cos_a = math.cos(angle)
        
        for depth in range(1, MAX_DEPTH):
            target_x = player_x + depth * cos_a
            target_y = player_y + depth * sin_a
            
            # Convert to map coordinates
            col = int(target_x / TILE_SIZE)
            row = int(target_y / TILE_SIZE)
            
            if GAME_MAP[row][col] == 1:
                # Fix fish-eye effect
                depth *= math.cos(player_angle - angle)
                
                # Calculate wall height
                wall_height = (TILE_SIZE * SCREEN_HEIGHT) / (depth + 0.0001)
                
                # Shading based on distance
                color_val = 255 / (1 + depth * depth * 0.0001)
                color = (color_val, color_val // 2, 0) # Orange-ish walls
                
                # Draw vertical wall slice
                pygame.draw.rect(screen, color, (
                    ray * (SCREEN_WIDTH // NUM_RAYS),
                    (SCREEN_HEIGHT // 2) - (wall_height // 2),
                    (SCREEN_WIDTH // NUM_RAYS),
                    wall_height
                ))
                break

# --- Game Loop ---
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
    # Controls
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]: player_angle -= 0.1
    if keys[pygame.K_RIGHT]: player_angle += 0.1
    if keys[pygame.K_w]:
        player_x += math.cos(player_angle) * 5
        player_y += math.sin(player_angle) * 5
        
    # Draw Background (Ceiling and Floor)
    screen.fill((50, 50, 50)) # Ceiling (Dark Gray)
    pygame.draw.rect(screen, (34, 139, 34), (0, SCREEN_HEIGHT // 2, SCREEN_WIDTH, SCREEN_HEIGHT // 2)) # Floor (Green)
    
    cast_rays()
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
