import pygame
import math

# --- Configuration ---
WIDTH, HEIGHT = 800, 600
HALF_WIDTH, HALF_HEIGHT = WIDTH // 2, HEIGHT // 2
FPS = 60
FOV = math.pi / 3  # 60 degrees
HALF_FOV = FOV / 2
NUM_RAYS = 120  # Lower for performance, higher for resolution
STEP_ANGLE = FOV / NUM_RAYS
SCALE = WIDTH // NUM_RAYS
MAX_DEPTH = 800

# Map: 1 = Wall, 0 = Empty space
MAP = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]
TILE_SIZE = 100

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
pygame.mouse.set_visible(False)
pygame.event.set_grab(True)

# Player setup
px, py = 150, 150
p_angle = 0

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
            running = False

    # --- Mouse Look ---
    rel_x = pygame.mouse.get_rel()[0]
    p_angle += rel_x * 0.002  # Rotation sensitivity

    # --- Drawing ---
    screen.fill((30, 30, 30))  # Ceiling/Floor
    pygame.draw.rect(screen, (50, 50, 50), (0, HALF_HEIGHT, WIDTH, HALF_HEIGHT)) # Floor

    # --- Raycasting ---
    start_angle = p_angle - HALF_FOV
    for r in range(NUM_RAYS):
        angle = start_angle + r * STEP_ANGLE
        sin_a = math.sin(angle)
        cos_a = math.cos(angle)

        # Basic ray step-by-step check
        for depth in range(1, MAX_DEPTH, 2):
            target_x = px + depth * cos_a
            target_y = py + depth * sin_a
            
            # Convert to map coordinates
            col, row = int(target_x // TILE_SIZE), int(target_y // TILE_SIZE)
            
            if MAP[row][col] == 1:
                # Fix fish-eye effect
                depth *= math.cos(p_angle - angle)
                
                # Calculate wall height
                proj_height = (TILE_SIZE * 500) / (depth + 0.0001)
                
                # Color shading based on distance
                color = 255 / (1 + depth * depth * 0.00001)
                
                pygame.draw.rect(screen, (color, color, color), 
                                 (r * SCALE, HALF_HEIGHT - proj_height // 2, SCALE, proj_height))
                break

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
