import pygame
import math

# Settings
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 400
MAP_SIZE = 8
TILE_SIZE = SCREEN_HEIGHT // MAP_SIZE
FOV = math.pi / 3
HALF_FOV = FOV / 2
NUM_RAYS = 120 # Quality of the render
STEP_ANGLE = FOV / NUM_RAYS

# Map: 1=Blue, 2=Green, 3=Red
GAME_MAP = [
    [1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,1],
    [1,0,2,2,0,3,0,1],
    [1,0,2,0,0,3,0,1],
    [1,0,0,0,0,0,0,1],
    [1,0,3,3,3,0,0,1],
    [1,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1],
]

COLORS = {1: (0, 0, 255), 2: (0, 255, 0), 3: (255, 0, 0)}

pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()
player_x, player_y, player_angle = 150, 150, 0

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: exit()
    
    # Movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]: player_angle -= 0.1
    if keys[pygame.K_RIGHT]: player_angle += 0.1
    if keys[pygame.K_w]:
        player_x += math.cos(player_angle) * 3
        player_y += math.sin(player_angle) * 3

    screen.fill((50, 50, 50)) # Sky/Floor

    # Raycasting
    start_angle = player_angle - HALF_FOV
    for r in range(NUM_RAYS):
        for dist in range(1, 400): # Cast ray forward
            rx = player_x + math.cos(start_angle) * dist
            ry = player_y + math.sin(start_angle) * dist
            
            col, row = int(rx / TILE_SIZE), int(ry / TILE_SIZE)
            if GAME_MAP[row][col] > 0:
                # Calculate height and fix fisheye
                fixed_dist = dist * math.cos(start_angle - player_angle)
                wall_height = (TILE_SIZE * SCREEN_HEIGHT) / (fixed_dist + 0.0001)
                
                color = list(COLORS[GAME_MAP[row][col]])
                # Simple Shading: Darken based on distance
                shade = 255 / (1 + fixed_dist * fixed_dist * 0.0001)
                color = [max(0, min(255, c * (shade/255))) for c in color]
                
                pygame.draw.rect(screen, color, (r * (SCREEN_WIDTH/NUM_RAYS), 
                                 (SCREEN_HEIGHT - wall_height)//2, 
                                 SCREEN_WIDTH/NUM_RAYS + 1, wall_height))
                break
        start_angle += STEP_ANGLE

    pygame.display.flip()
    clock.tick(60)
