import pygame
import os

# Initialize Pygame
pygame.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Sprite Sheet Animation Example")

CLOCK = pygame.time.Clock()
FPS = 30

# Define colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Helper class to load and parse sprite sheets
class SpriteSheet:
    def __init__(self, filename):
        # Load the sprite sheet image
        self.sheet = pygame.image.load(filename).convert_alpha()

    def get_image(self, x, y, width, height, scale=1):
        # Create a new blank surface for the individual image
        image = pygame.Surface([width, height], pygame.SRCALPHA).convert_alpha()
        # Blit the specific area from the sprite sheet to the new surface
        image.blit(self.sheet, (0, 0), (x, y, width, height))
        # Scale the image if needed
        image = pygame.transform.scale(image, (width * scale, height * scale))
        return image

# Player class inheriting from pygame.sprite.Sprite
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.sprite_sheet = SpriteSheet('spritesheet.png') # **REPLACE WITH YOUR SPRITE SHEET FILE*
        
        # Load animation frames into a list
        self.animation_frames = []
        # Example: if frames are 32x32 pixels, horizontally arranged
        frame_width = 16
        frame_height =16
        num_frames = 10 # Adjust based on your sprite sheet
        for i in range(num_frames):
            frame = self.sprite_sheet.get_image(i * frame_width, 0, frame_width, frame_height, scale=2)
            self.animation_frames.append(frame)

        self.current_frame = 0
        self.image = self.animation_frames[self.current_frame]
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

        # Animation timing
        self.animation_speed = 0.2 # Adjust to control animation speed
        self.frame_index = 0
        self.last_update = pygame.time.get_ticks()

    def update(self):
        # Animate the sprite by cycling through frames
        now = pygame.time.get_ticks()
        if now - self.last_update >= self.animation_speed * 1000:
            self.last_update = now
            self.frame_index += 1
            if self.frame_index >= len(self.animation_frames):
                self.frame_index = 0
            self.image = self.animation_frames[self.frame_index]
            
        # Add movement logic here if needed

# Create the player and a sprite group
player = Player(50, 50)
all_sprites = pygame.sprite.Group(player)

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update
    all_sprites.update()

    # Draw
    screen.fill(BLACK) # Fill background
    all_sprites.draw(screen) # Draw all sprites in the group

    # Refresh screen
    pygame.display.flip()

    # Cap the frame rate
    CLOCK.tick(FPS)

pygame.quit()
