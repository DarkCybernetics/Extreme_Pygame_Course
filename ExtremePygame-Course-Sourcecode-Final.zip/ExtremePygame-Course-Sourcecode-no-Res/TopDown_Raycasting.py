import pygame
import math

# Constants
WIDTH, HEIGHT = 800, 400
HALF_WIDTH = WIDTH // 2
MAP_SIZE = 8
TILE_SIZE = HALF_WIDTH // MAP_SIZE
FOV = math.pi / 3
HALF_FOV = FOV / 2
NUM_RAYS = 120
STEP_ANGLE = FOV / NUM_RAYS
MAX_DEPTH = MAP_SIZE * TILE_SIZE

# Simple Map (1 = Wall, 0 = Path)
MAP = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 0, 1, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 1, 1, 0, 1],
    [1, 0, 0, 0, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1],
]

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

player_x, player_y = TILE_SIZE * 1.5, TILE_SIZE * 1.5
player_angle = 0

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()

    # Controls
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]: player_angle -= 0.1
    if keys[pygame.K_RIGHT]: player_angle += 0.1
    if keys[pygame.K_UP]:
        player_x += math.cos(player_angle) * 2
        player_y += math.sin(player_angle) * 2

    # Drawing
    screen.fill((0, 0, 0))
    
    # 1. Draw 2D Top-down Map
    for r in range(MAP_SIZE):
        for c in range(MAP_SIZE):
            color = (100, 100, 100) if MAP[r][c] == 1 else (50, 50, 50)
            pygame.draw.rect(screen, color, (c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE - 2, TILE_SIZE - 2))
    pygame.draw.circle(screen, (255, 0, 0), (int(player_x), int(player_y)), 5)

    # 2. Raycasting Logic
    start_angle = player_angle - HALF_FOV
    for i in range(NUM_RAYS):
        angle = start_angle + i * STEP_ANGLE
        for depth in range(MAX_DEPTH):
            target_x = player_x + math.cos(angle) * depth
            target_y = player_y + math.sin(angle) * depth
            
            # Collision check
            col, row = int(target_x / TILE_SIZE), int(target_y / TILE_SIZE)
            if MAP[row][col] == 1:
                # Draw ray on 2D map
                pygame.draw.line(screen, (0, 255, 0), (player_x, player_y), (target_x, target_y))
                
                # 3D Projection
                # Fix fish-eye effect
                dist = depth * math.cos(player_angle - angle)
                wall_height = 21000 / (dist + 0.0001)
                
                color_val = 255 / (1 + dist * dist * 0.0001) # Simple shading
                pygame.draw.rect(screen, (color_val, color_val, color_val), 
                                (HALF_WIDTH + i * (HALF_WIDTH / NUM_RAYS), 
                                 (HEIGHT // 2) - wall_height // 2, 
                                 (HALF_WIDTH / NUM_RAYS) + 1, wall_height))
                break

    pygame.display.flip()
    clock.tick(60)
