import pygame
import math

# Constants
WIDTH, HEIGHT = 800, 600
MAP_SIZE = 8
TILE_SIZE = WIDTH // MAP_SIZE // 2
FOV = math.pi / 3  # 60 degrees
HALF_FOV = FOV / 2
NUM_RAYS = 120
STEP_ANGLE = FOV / NUM_RAYS
MAX_DEPTH = 800

# Simple map: 1 is a wall, 0 is empty space
GAME_MAP = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 1, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 1, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1],
]

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Player setup
player_x, player_y = 150, 150
player_angle = 0

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Movement controls
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]: player_angle -= 0.05
    if keys[pygame.K_RIGHT]: player_angle += 0.05
    if keys[pygame.K_w]:
        player_x += math.cos(player_angle) * 3
        player_y += math.sin(player_angle) * 3
    if keys[pygame.K_s]:
        player_x -= math.cos(player_angle) * 3
        player_y -= math.sin(player_angle) * 3

    # Background (Ceiling and Floor)
    screen.fill((50, 50, 50))  # Ceiling
    pygame.draw.rect(screen, (100, 100, 100), (0, HEIGHT // 2, WIDTH, HEIGHT // 2)) # Floor

    # Raycasting Loop
    start_angle = player_angle - HALF_FOV
    for ray in range(NUM_RAYS):
        for depth in range(MAX_DEPTH):
            target_x = player_x + math.cos(start_angle) * depth
            target_y = player_y + math.sin(start_angle) * depth
            
            # Convert world coords to map coords
            col, row = int(target_x / TILE_SIZE), int(target_y / TILE_SIZE)
            
            if GAME_MAP[row][col] == 1:
                # Wall height depends on distance (corrected for fisheye)
                dist = depth * math.cos(player_angle - start_angle)
                wall_height = 21000 / (dist + 0.0001)
                
                # Draw 3D wall strip
                color = 255 / (1 + depth * depth * 0.0001) # Simple shading
                pygame.draw.rect(screen, (color, color, color), (
                    ray * (WIDTH / NUM_RAYS), (HEIGHT - wall_height) // 2,
                    WIDTH / NUM_RAYS + 1, wall_height
                ))
                break
        start_angle += STEP_ANGLE

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
