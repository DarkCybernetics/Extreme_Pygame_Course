# Top-down shooter
To launch the game, just open `main.exe` file.

If you want to play your own modified version of the game, you need to install dependencies first.
```
pip install -r requirements.txt
```

### Controls
- `WASD` movement
- Shoot with mouse
- After dying, press `R` button to restart
- Change weapons with keys `1`, `2` and `3` for pistol, shotgun and machine gun respectively
