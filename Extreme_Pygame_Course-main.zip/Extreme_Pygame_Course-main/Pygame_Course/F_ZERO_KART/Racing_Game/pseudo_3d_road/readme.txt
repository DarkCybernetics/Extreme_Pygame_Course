how to make a 3d racing game without using any 3d library like opengl ? 

the answer is by using pseudo 3d road technique.

pseudo 3d road was a very used rendering technique in the golden age  of arcade games (80's and 90's) 

when  machines  couldn't render true 3d.

arcade hits such outrun (sega)  used this technique.

it is a mixture between raycasting and floorcasting, 

so I have used my raycasting + floorcasting engine's code to do it, and I have named it "roadcaster".

I have used this tutorials as starting point for developing my own pseudo 3d road engine:

http://www.extentofthejam.com/pseudo/

https://codeincomplete.com/posts/javascript-racer-v1-straight/

enjoy!!



