                   Halloween Horror Game
===================================================================
Warrenties: None.
=====================================
Copyright: Dion Jackson All Rights Reserved 2022.
=====================================
Controls: 
1- Hotkey Stake
2- Hotkey Pistol
3- Hotkey Holy Bible
4- Hotkey Holy Water
5- Hotkey Crossbow
Q - Turn Left
W - Turn Right 
E - Moves Forward
A - Moves Backward
S - Strafs Left
D - Strafs Right
Spacebar - Current Objective
Enter - Pauses the Game
Escape - Exits the Game
Mouse Button 1 - Fires the Weapon
Mouse Button 2 - Opens Doors
=====================================
Story 




=====================================
