CyberNet Shooters
======================================
|| Controls ||
==============

Mouse one Shoots when selecting an enemy otherise moves the player
Mouse two shoots secondary fire of the select weapon
1
2
3
4
5
6
7
8
9
------------------------------------------------------------------
Power ups tempariarrly embrew wepons with a select elemental Force
Collectng a power up adds ammunition to a weapon class
-Melle weapons have no ammunition
-----------------------------------------------
Shield
Grenda
Bow
Pistol
Staff
Axes
Sword
Health Powerup
---------------------------------------------------

Collect : Gold , Jewels  = increase score

---------------------------------------------------

~~~~~~~~~~~~~~~
||  Enemies  ||
~~~~~~~~~~~~~~~
~ each are different colors based on thier point values
~ chance to drop gold or power up

Goos
Ghosts
Monsters
Demons






















==============================================================
